import 'dart:async';
import 'dart:developer' as developer;
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' show FontFeature, ImageFilter, Rect;

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart' show ScrollDirection;
import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:myapp/app_tab_state.dart';
import 'package:myapp/models/video_history.dart';
import 'package:myapp/models/playlist.dart' as app_models;
import 'package:myapp/search_view_state.dart';
import 'package:myapp/services/app_settings_service.dart';
import 'package:myapp/services/download_service.dart';
import 'package:myapp/services/ios_live_lyrics_alignment_service.dart';
import 'package:myapp/services/lyrics_service.dart';
import 'package:myapp/services/playlist_service.dart';
import 'package:myapp/utils/artist_name_utils.dart';
import 'package:myapp/utils/artwork_subject_cutout_service.dart';
import 'package:myapp/utils/thumbnail_quality.dart';
import 'package:myapp/video_player_manager.dart';
import 'package:myapp/widgets/playlist_picker_sheet.dart';
import 'package:myapp/widgets/square_thumbnail.dart';
import 'package:palette_generator/palette_generator.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import 'package:youtube_explode_dart/youtube_explode_dart.dart';

const MethodChannel _systemVolumeChannel = MethodChannel(
  'com.vm.music.beta/system_volume',
);

class MusicPlayerPage extends StatefulWidget {
  const MusicPlayerPage({super.key});

  @override
  State<MusicPlayerPage> createState() => _MusicPlayerPageState();
}

class _MusicPlayerPageState extends State<MusicPlayerPage> {
  bool _isShowingPlaybackErrorDialog = false;

  @override
  Widget build(BuildContext context) {
    final manager = context.read<VideoPlayerManager>();
    return Selector<
      VideoPlayerManager,
      ({String? currentVideoId, bool isMinimized, String? errorMessage})
    >(
      selector: (_, manager) => (
        currentVideoId: manager.currentVideoId,
        isMinimized: manager.isMinimized,
        errorMessage: manager.errorMessage,
      ),
      builder: (context, playerState, child) {
        final error = playerState.errorMessage;
        if (error != null && error.isNotEmpty) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            _showPlaybackErrorDialog(error);
          });
        }

        if (playerState.currentVideoId == null) {
          return const SizedBox.shrink();
        }

        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 620),
          reverseDuration: const Duration(milliseconds: 500),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          layoutBuilder: (currentChild, previousChildren) {
            return Stack(
              fit: StackFit.expand,
              alignment: Alignment.bottomCenter,
              children: [
                ...previousChildren,
                if (currentChild != null) currentChild,
              ],
            );
          },
          transitionBuilder: (child, animation) {
            final isMini = child.key == const ValueKey('mini_player');
            final curved = CurvedAnimation(
              parent: animation,
              curve: Curves.easeOutCubic,
              reverseCurve: Curves.easeInCubic,
            );
            final fade = Tween<double>(begin: 0.0, end: 1.0).animate(curved);
            final slide = Tween<Offset>(
              begin: isMini ? const Offset(0, 0.22) : const Offset(0, 0.08),
              end: Offset.zero,
            ).animate(curved);
            final scale = Tween<double>(
              begin: isMini ? 0.965 : 0.99,
              end: 1.0,
            ).animate(curved);
            return ClipRect(
              child: FadeTransition(
                opacity: fade,
                child: SlideTransition(
                  position: slide,
                  child: ScaleTransition(scale: scale, child: child),
                ),
              ),
            );
          },
          child: playerState.isMinimized
              ? _MiniPlayer(
                  key: const ValueKey('mini_player'),
                  manager: manager,
                )
              : _FullPlayer(
                  key: const ValueKey('full_player'),
                  manager: manager,
                ),
        );
      },
    );
  }

  Future<void> _showPlaybackErrorDialog(String message) async {
    if (!mounted || _isShowingPlaybackErrorDialog) return;
    _isShowingPlaybackErrorDialog = true;
    try {
      await showCupertinoDialog<void>(
        context: context,
        builder: (dialogContext) => CupertinoAlertDialog(
          title: const Text('No se pudo reproducir'),
          content: Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(message),
          ),
          actions: [
            CupertinoDialogAction(
              isDefaultAction: true,
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Entendido'),
            ),
          ],
        ),
      );
    } finally {
      if (mounted) {
        context.read<VideoPlayerManager>().clearErrorMessage();
      }
      _isShowingPlaybackErrorDialog = false;
    }
  }
}

class _PerformanceBackdrop extends StatelessWidget {
  final ImageFilter filter;
  final Widget child;

  const _PerformanceBackdrop({required this.filter, required this.child});

  @override
  Widget build(BuildContext context) {
    final lightweightUi = context.select<VideoPlayerManager, bool>(
      (manager) => manager.shouldUseLightweightPlayerUi,
    );
    if (lightweightUi) return child;
    return BackdropFilter(filter: filter, child: child);
  }
}

class _MiniPlayer extends StatefulWidget {
  final VideoPlayerManager manager;

  const _MiniPlayer({super.key, required this.manager});

  @override
  State<_MiniPlayer> createState() => _MiniPlayerState();
}

class _MiniPlayerState extends State<_MiniPlayer> {
  double _dragLift = 0.0;
  double _horizontalDragDx = 0.0;
  Offset? _videoMiniOffset;
  bool _isDraggingVideoMini = false;
  bool _isOpening = false;
  bool _isSwitchingTrack = false;
  static const double _maxDragLift = 52.0;
  static const double _miniSwipeDistanceThreshold = 36;
  static const double _miniSwipeVelocityThreshold = 320;

  double get _dragProgress => (_dragLift / _maxDragLift).clamp(0.0, 1.0);

  void _setDragLift(double value) {
    if (!mounted) return;
    setState(() {
      _dragLift = value.clamp(0.0, _maxDragLift);
    });
  }

  Future<void> _openWithGestureAnimation() async {
    if (_isOpening) return;
    _isOpening = true;
    _setDragLift(_maxDragLift);
    HapticFeedback.lightImpact();
    await Future<void>.delayed(const Duration(milliseconds: 60));
    if (!mounted) return;
    widget.manager.maximize();
    _isOpening = false;
    _setDragLift(0.0);
  }

  bool _shouldTriggerMiniSwipe(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    return _horizontalDragDx.abs() >= _miniSwipeDistanceThreshold ||
        velocity.abs() >= _miniSwipeVelocityThreshold;
  }

  Future<void> _handleMiniSwipe(bool toNext) async {
    if (_isSwitchingTrack) return;
    _isSwitchingTrack = true;
    unawaited(HapticFeedback.selectionClick());
    try {
      if (toNext) {
        await widget.manager.playNextInQueue();
      } else {
        await widget.manager.playPreviousInQueue();
      }
    } finally {
      _isSwitchingTrack = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    final miniState = context
        .select<
          VideoPlayerManager,
          ({
            String? trackTitle,
            String? trackArtist,
            String? trackThumbnailUrl,
            bool isPlaying,
            bool isVideoFallback,
            VideoPlayerController? foregroundController,
          })
        >(
          (manager) => (
            trackTitle: manager.trackTitle,
            trackArtist: manager.trackArtist,
            trackThumbnailUrl: manager.trackThumbnailUrl,
            isPlaying: manager.isPlaying,
            isVideoFallback: manager.isUsingVideoFallback,
            foregroundController: manager.foregroundVideoController,
          ),
        );
    final bottomInset = MediaQuery.of(context).padding.bottom;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    const miniPlayerHeight = 58.0;
    const miniPlayerBottomNavReserve = 53.0;
    final progress = _dragProgress;
    final dynamicRadius = 24 - (2 * progress);
    final dynamicShadowOpacity = 0.08 + (0.12 * progress);
    final dynamicShadowBlur = 22 + (18 * progress);
    final dynamicShadowYOffset = 8 - (4 * progress);

    // If we're playing a video in foreground (video fallback), show a
    // compact video mini-player in the bottom-right with pause and close.
    if (miniState.isVideoFallback) {
      final ctrl = miniState.foregroundController;
      final thumb = miniState.trackThumbnailUrl;
      const miniVideoWidth = 240.0;
      const miniVideoHeight = 140.0;
      final screenSize = MediaQuery.of(context).size;
      final defaultLeft = screenSize.width - miniVideoWidth - 12;
      final defaultTop =
          screenSize.height -
          miniPlayerBottomNavReserve -
          bottomInset -
          miniVideoHeight;
      final current = _videoMiniOffset ?? Offset(defaultLeft, defaultTop);
      final clampedLeft = current.dx.clamp(12.0, defaultLeft);
      final clampedTop = current.dy.clamp(
        MediaQuery.of(context).padding.top + 12,
        defaultTop,
      );

      return Stack(
        children: [
          AnimatedPositioned(
            duration: _isDraggingVideoMini
                ? Duration.zero
                : const Duration(milliseconds: 240),
            curve: Curves.easeOutCubic,
            left: clampedLeft,
            top: clampedTop,
            child: GestureDetector(
              behavior: HitTestBehavior.translucent,
              onPanStart: (_) {
                _isDraggingVideoMini = true;
              },
              onPanUpdate: (details) {
                final base =
                    _videoMiniOffset ?? Offset(clampedLeft, clampedTop);
                final next = base + details.delta;
                final nextLeft = next.dx.clamp(12.0, defaultLeft);
                final nextTop = next.dy.clamp(
                  MediaQuery.of(context).padding.top + 12,
                  defaultTop,
                );
                setState(() {
                  _videoMiniOffset = Offset(nextLeft, nextTop);
                });
              },
              onPanEnd: (details) {
                final current =
                    _videoMiniOffset ?? Offset(clampedLeft, clampedTop);
                final velocityX = details.velocity.pixelsPerSecond.dx;
                final velocityY = details.velocity.pixelsPerSecond.dy;
                final projectedX = current.dx + (velocityX * 0.12);
                final projectedY = current.dy + (velocityY * 0.12);
                final topLimit = MediaQuery.of(context).padding.top + 12;
                final bottomLimit = defaultTop;
                final targetX = projectedX >= ((12.0 + defaultLeft) / 2)
                    ? defaultLeft
                    : 12.0;
                final targetY = projectedY >= ((topLimit + bottomLimit) / 2)
                    ? bottomLimit
                    : topLimit;
                setState(() {
                  _isDraggingVideoMini = false;
                  _videoMiniOffset = Offset(targetX, targetY);
                });
              },
              onPanCancel: () {
                final current =
                    _videoMiniOffset ?? Offset(clampedLeft, clampedTop);
                final topLimit = MediaQuery.of(context).padding.top + 12;
                final bottomLimit = defaultTop;
                final targetX = current.dx >= ((12.0 + defaultLeft) / 2)
                    ? defaultLeft
                    : 12.0;
                final targetY = current.dy >= ((topLimit + bottomLimit) / 2)
                    ? bottomLimit
                    : topLimit;
                setState(() {
                  _isDraggingVideoMini = false;
                  _videoMiniOffset = Offset(targetX, targetY);
                });
              },
              child: SizedBox(
                width: miniVideoWidth,
                height: miniVideoHeight,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Material(
                    color: Colors.transparent,
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: widget.manager.maximize,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Theme.of(context).brightness == Brightness.dark
                              ? Colors.black.withValues(alpha: 0.22)
                              : Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.14),
                              blurRadius: 10,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Stack(
                          fit: StackFit.expand,
                          children: [
                            // Video or thumbnail as background
                            if (ctrl != null)
                              ValueListenableBuilder<VideoPlayerValue>(
                                valueListenable: ctrl,
                                builder: (_, __, ___) {
                                  if (ctrl.value.isInitialized) {
                                    return FittedBox(
                                      fit: BoxFit.cover,
                                      child: SizedBox(
                                        width: ctrl.value.size?.width ?? 0,
                                        height: ctrl.value.size?.height ?? 0,
                                        child: VideoPlayer(ctrl),
                                      ),
                                    );
                                  }
                                  return thumb != null && thumb.isNotEmpty
                                      ? Image.network(thumb, fit: BoxFit.cover)
                                      : const SizedBox.expand();
                                },
                              )
                            else
                              (thumb != null && thumb.isNotEmpty
                                  ? Image.network(thumb, fit: BoxFit.cover)
                                  : const SizedBox.expand()),

                            // Dark gradient top for better contrast with close button
                            Positioned(
                              top: 0,
                              left: 0,
                              right: 0,
                              height: 44,
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Colors.black.withValues(alpha: 0.36),
                                      Colors.transparent,
                                    ],
                                  ),
                                ),
                              ),
                            ),

                            // Center play/pause button
                            Align(
                              alignment: Alignment.center,
                              child: CupertinoButton(
                                padding: EdgeInsets.zero,
                                onPressed: widget.manager.togglePlayPause,
                                child: Icon(
                                  miniState.isPlaying
                                      ? CupertinoIcons.pause_solid
                                      : CupertinoIcons.play_arrow_solid,
                                  size: 30,
                                  color: isDark
                                      ? const Color(0xFFF5F5F7)
                                      : const Color(0xFFFFFFFF),
                                ),
                              ),
                            ),

                            // Close button top-right
                            Positioned(
                              top: 2,
                              right: 2,
                              child: CupertinoButton(
                                padding: EdgeInsets.zero,
                                onPressed: widget.manager.close,
                                child: Icon(
                                  CupertinoIcons.xmark,
                                  size: 18,
                                  color: isDark
                                      ? const Color(0xFFF2F2F7)
                                      : const Color(0xFFFFFFFF),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    }

    return Align(
      alignment: Alignment.bottomCenter,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          12,
          0,
          12,
          miniPlayerBottomNavReserve + bottomInset,
        ),
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onHorizontalDragStart: (_) {
            _horizontalDragDx = 0;
          },
          onHorizontalDragUpdate: (details) {
            _horizontalDragDx += details.delta.dx;
          },
          onHorizontalDragEnd: (details) {
            if (!_shouldTriggerMiniSwipe(details)) {
              _horizontalDragDx = 0;
              return;
            }
            final velocity = details.primaryVelocity ?? 0;
            final swipeRight =
                velocity > 0 || (velocity == 0 && _horizontalDragDx > 0);
            unawaited(_handleMiniSwipe(!swipeRight));
            _horizontalDragDx = 0;
          },
          onHorizontalDragCancel: () {
            _horizontalDragDx = 0;
          },
          onVerticalDragUpdate: (details) {
            if (_isOpening) return;
            if (details.delta.dy < 0) {
              _setDragLift(_dragLift + ((-details.delta.dy) * 1.15));
            } else if (_dragLift > 0) {
              _setDragLift(_dragLift - (details.delta.dy * 1.25));
            }
          },
          onVerticalDragEnd: (details) {
            if (_isOpening) return;
            final velocity = details.primaryVelocity ?? 0;
            final shouldOpen = velocity < -340 || _dragProgress > 0.36;
            if (shouldOpen) {
              unawaited(_openWithGestureAnimation());
              return;
            }
            _setDragLift(0.0);
          },
          onVerticalDragCancel: () {
            if (_isOpening) return;
            _setDragLift(0.0);
          },
          child: AnimatedSlide(
            duration: const Duration(milliseconds: 220),
            curve: Curves.easeOutBack,
            offset: Offset(0, -(0.32 * progress)),
            child: AnimatedScale(
              duration: const Duration(milliseconds: 220),
              curve: Curves.easeOutBack,
              scale: 1 + (0.03 * progress),
              child: ClipRRect(
                clipBehavior: Clip.antiAlias,
                borderRadius: BorderRadius.circular(dynamicRadius),
                child: _PerformanceBackdrop(
                  filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: CupertinoButton(
                    padding: EdgeInsets.zero,
                    onPressed: widget.manager.maximize,
                    child: Container(
                      height: miniPlayerHeight,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(dynamicRadius),
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: isDark
                              ? [
                                  const Color(0xFF9CA3AF).withValues(alpha: 0.30),
                                  const Color(0xFF6B7280).withValues(alpha: 0.22),
                                ]
                              : [
                                  const Color(0xFFE5E7EB).withValues(alpha: 0.90),
                                  const Color(0xFFD1D5DB).withValues(alpha: 0.74),
                                ],
                        ),
                        border: Border.all(
                          color: isDark
                              ? const Color(0xFF9CA3AF).withValues(alpha: 0.38)
                              : const Color(0xFFCBD5E1).withValues(alpha: 0.94),
                          width: 0.8,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: CupertinoColors.black.withValues(
                              alpha: dynamicShadowOpacity,
                            ),
                            blurRadius: dynamicShadowBlur,
                            offset: Offset(0, dynamicShadowYOffset),
                          ),
                        ],
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 10),
                      child: Row(
                        children: [
                          _ArtworkSwipeNavigator(
                            manager: widget.manager,
                            child: _ArtworkImage(
                              url: miniState.trackThumbnailUrl,
                              size: 44,
                              borderRadius: 10,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _AnimatedTrackMeta(
                              trackKey:
                                  miniState.trackTitle ??
                                  miniState.trackArtist ??
                                  'mini_unknown',
                              title: miniState.trackTitle ?? 'Reproduciendo',
                              artist:
                                  miniState.trackArtist ??
                                  'Artista desconocido',
                              direction:
                                  widget.manager.trackTransitionDirection,
                              titleStyle: CupertinoTheme.of(context)
                                  .textTheme
                                  .textStyle
                                  .copyWith(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                              artistStyle: CupertinoTheme.of(context)
                                  .textTheme
                                  .textStyle
                                  .copyWith(
                                    fontSize: 12,
                                    color: CupertinoColors.secondaryLabel
                                        .resolveFrom(context),
                                  ),
                              titleMaxLines: 1,
                              artistMaxLines: 1,
                              verticalPadding: 0,
                            ),
                          ),
                          CupertinoButton(
                            padding: EdgeInsets.zero,
                            onPressed: widget.manager.togglePlayPause,
                            child: Icon(
                              miniState.isPlaying
                                  ? CupertinoIcons.pause_fill
                                  : CupertinoIcons.play_fill,
                              size: 27,
                              color: CupertinoColors.label.resolveFrom(context),
                            ),
                          ),
                          const SizedBox(width: 6),
                          CupertinoButton(
                            padding: EdgeInsets.zero,
                            onPressed: widget.manager.playNextInQueue,
                            child: Icon(
                              CupertinoIcons.forward_fill,
                              size: 22,
                              color: CupertinoColors.secondaryLabel.resolveFrom(
                                context,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _AnimatedTrackMeta extends StatelessWidget {
  final String trackKey;
  final String title;
  final String artist;
  final int direction;
  final TextStyle titleStyle;
  final TextStyle artistStyle;
  final int titleMaxLines;
  final int artistMaxLines;
  final double verticalPadding;

  const _AnimatedTrackMeta({
    required this.trackKey,
    required this.title,
    required this.artist,
    this.direction = 0,
    required this.titleStyle,
    required this.artistStyle,
    this.titleMaxLines = 2,
    this.artistMaxLines = 1,
    this.verticalPadding = 2,
  });

  @override
  Widget build(BuildContext context) {
    final dx = direction < 0 ? -0.06 : 0.06;
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 280),
      reverseDuration: const Duration(milliseconds: 220),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      layoutBuilder: (currentChild, previousChildren) {
        return Stack(
          alignment: Alignment.centerLeft,
          children: <Widget>[
            ...previousChildren,
            if (currentChild != null) currentChild,
          ],
        );
      },
      transitionBuilder: (child, animation) {
        final slide = Tween<Offset>(
          begin: Offset(dx, 0),
          end: Offset.zero,
        ).animate(animation);
        return FadeTransition(
          opacity: animation,
          child: SlideTransition(position: slide, child: child),
        );
      },
      child: Padding(
        key: ValueKey('track_meta_$trackKey'),
        padding: EdgeInsets.symmetric(vertical: verticalPadding),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              maxLines: titleMaxLines,
              overflow: TextOverflow.ellipsis,
              style: titleStyle,
            ),
            Text(
              artist,
              maxLines: artistMaxLines,
              overflow: TextOverflow.ellipsis,
              style: artistStyle,
            ),
          ],
        ),
      ),
    );
  }
}

class _FullPlayer extends StatefulWidget {
  final VideoPlayerManager manager;

  const _FullPlayer({super.key, required this.manager});

  @override
  State<_FullPlayer> createState() => _FullPlayerState();
}

class _FullPlayerState extends State<_FullPlayer> {
  bool _isOpeningArtistProfile = false;
  static const double _pullToMinimizeThreshold = 76;
  static const Duration _lyricsUiInactivityDelay = Duration(seconds: 4);
  static final bool _dynamicAlbumBackgroundEnabled = false;
  static const int _maxPaletteCacheEntries = 120;
  static final Map<String, Color> _backgroundPaletteCache = <String, Color>{};
  static final Map<String, Future<Color?>> _backgroundPaletteRequests =
      <String, Future<Color?>>{};
  final ScrollController _contentScrollController = ScrollController();
  double _pullDownAccumulated = 0;
  bool _didTriggerMinimizeInGesture = false;
  Timer? _lyricsUiHideTimer;
  bool _lyricsChromeVisible = true;
  bool _wasLyricsLayout = false;
  Color _albumBackgroundTint = const Color(0xFF1A2030);
  String? _lastPaletteArtworkUrl;

  VideoPlayerManager get manager => widget.manager;

  @override
  void dispose() {
    _lyricsUiHideTimer?.cancel();
    _contentScrollController.dispose();
    super.dispose();
  }

  void _maybeResolveAlbumBackgroundTint() {
    if (!_dynamicAlbumBackgroundEnabled) return;
    final raw = manager.trackThumbnailUrl?.trim() ?? '';
    if (raw.isEmpty || raw == _lastPaletteArtworkUrl) return;
    _lastPaletteArtworkUrl = raw;

    final cached = _backgroundPaletteCache[raw];
    if (cached != null) {
      // Este método se invoca desde build; aquí actualizamos de forma directa
      // para evitar setState() durante la fase de construcción.
      _albumBackgroundTint = cached;
      return;
    }

    final request =
        _backgroundPaletteRequests[raw] ??
        () async {
          try {
            final ImageProvider provider = raw.startsWith('/')
                ? FileImage(File(raw))
                : NetworkImage(raw);
            final palette = await PaletteGenerator.fromImageProvider(
              provider,
              size: const Size(96, 96),
              maximumColorCount: 16,
            );
            return palette.vibrantColor?.color ??
                palette.lightVibrantColor?.color ??
                palette.dominantColor?.color ??
                palette.mutedColor?.color;
          } catch (_) {
            return null;
          }
        }();
    _backgroundPaletteRequests[raw] = request;

    unawaited(
      request
          .then((color) {
            if (!mounted || _lastPaletteArtworkUrl != raw || color == null) {
              return;
            }
            _rememberBackgroundPalette(raw, color);
            setState(() {
              _albumBackgroundTint = color;
            });
          })
          .whenComplete(() {
            if (identical(_backgroundPaletteRequests[raw], request)) {
              _backgroundPaletteRequests.remove(raw);
            }
          }),
    );
  }

  void _rememberBackgroundPalette(String key, Color value) {
    _backgroundPaletteCache[key] = value;
    while (_backgroundPaletteCache.length > _maxPaletteCacheEntries) {
      _backgroundPaletteCache.remove(_backgroundPaletteCache.keys.first);
    }
  }

  Widget _buildAlbumBlurBackground(
    BuildContext context, {
    required bool thermalSaver,
  }) {
    final artwork = manager.trackThumbnailUrl?.trim() ?? '';
    final tint = _albumBackgroundTint;
    final darkTop = Color.lerp(tint, Colors.black, 0.55)!;
    final deepBottom = Color.lerp(tint, Colors.black, 0.80)!;

    Widget? artworkLayer;
    if (artwork.isNotEmpty) {
      artworkLayer = Transform.scale(
        scale: thermalSaver ? 1.12 : 1.32,
        child: thermalSaver
            ? (artwork.startsWith('/')
                  ? Image.file(
                      File(artwork),
                      fit: BoxFit.cover,
                      filterQuality: FilterQuality.low,
                    )
                  : Image.network(
                      artwork,
                      fit: BoxFit.cover,
                      filterQuality: FilterQuality.low,
                      errorBuilder: (_, _, _) => const SizedBox.expand(),
                    ))
            : (artwork.startsWith('/')
                  ? Image.file(File(artwork), fit: BoxFit.cover)
                  : Image.network(
                      artwork,
                      fit: BoxFit.cover,
                      errorBuilder: (_, _, _) => const SizedBox.expand(),
                    )),
      );
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [darkTop, tint, deepBottom],
            ),
          ),
        ),
        if (artworkLayer != null)
          Opacity(opacity: thermalSaver ? 0.18 : 0.20, child: artworkLayer),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: const Alignment(-0.25, -0.85),
              radius: 1.20,
              colors: [
                tint.withValues(alpha: 0.42),
                tint.withValues(alpha: 0.14),
                Colors.black.withValues(alpha: 0.62),
              ],
              stops: const [0.0, 0.52, 1.0],
            ),
          ),
        ),
        DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.black.withValues(alpha: 0.10),
                Colors.transparent,
                Colors.black.withValues(alpha: 0.50),
              ],
            ),
          ),
        ),
      ],
    );
  }

  void _syncLyricsImmersiveMode(bool isLyricsLayout) {
    if (_wasLyricsLayout == isLyricsLayout) return;
    _wasLyricsLayout = isLyricsLayout;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _lyricsUiHideTimer?.cancel();
      if (!isLyricsLayout) {
        if (!_lyricsChromeVisible) {
          setState(() {
            _lyricsChromeVisible = true;
          });
        }
        return;
      }
      if (!_lyricsChromeVisible) {
        setState(() {
          _lyricsChromeVisible = true;
        });
      }
      _scheduleLyricsChromeAutoHide();
    });
  }

  void _scheduleLyricsChromeAutoHide() {
    _lyricsUiHideTimer?.cancel();
    _lyricsUiHideTimer = Timer(_lyricsUiInactivityDelay, () {
      if (!mounted || !manager.isLyricsLayout) return;
      if (_lyricsChromeVisible) {
        setState(() {
          _lyricsChromeVisible = false;
        });
      }
    });
  }

  void _onLyricsPanelInteraction() {
    if (!manager.isLyricsLayout) return;
    if (_lyricsChromeVisible) {
      _scheduleLyricsChromeAutoHide();
    }
  }

  void _onLyricsPanelRevealRequest() {
    if (!manager.isLyricsLayout) return;
    if (!_lyricsChromeVisible) {
      unawaited(HapticFeedback.selectionClick());
      setState(() {
        _lyricsChromeVisible = true;
      });
    }
    _scheduleLyricsChromeAutoHide();
  }

  void _onLyricsPanelImmersiveRequest() {
    if (!manager.isLyricsLayout) return;
    _lyricsUiHideTimer?.cancel();
    if (_lyricsChromeVisible) {
      unawaited(HapticFeedback.selectionClick());
      setState(() {
        _lyricsChromeVisible = false;
      });
    }
  }

  bool _isAtTop(ScrollMetrics metrics) {
    return metrics.pixels <= (metrics.minScrollExtent + 0.5);
  }

  void _accumulatePullToMinimize(double pullDelta) {
    if (pullDelta <= 0 || _didTriggerMinimizeInGesture) return;
    _pullDownAccumulated += pullDelta;
    if (_pullDownAccumulated < _pullToMinimizeThreshold) return;
    _didTriggerMinimizeInGesture = true;
    _pullDownAccumulated = 0;
    unawaited(HapticFeedback.mediumImpact());
    manager.minimize();
  }

  bool _handleContentScrollNotification(ScrollNotification notification) {
    if (manager.isLyricsLayout && !_lyricsChromeVisible) {
      return false;
    }
    if (notification is ScrollStartNotification) {
      _pullDownAccumulated = 0;
      _didTriggerMinimizeInGesture = false;
      return false;
    }

    if (notification is ScrollUpdateNotification) {
      final dragDy = notification.dragDetails?.delta.dy;
      if (dragDy == null) return false;
      if (_isAtTop(notification.metrics) && dragDy > 0) {
        _accumulatePullToMinimize(dragDy);
      } else if (dragDy < 0) {
        _pullDownAccumulated = 0;
      }
      return false;
    }

    if (notification is OverscrollNotification) {
      final dragDy = notification.dragDetails?.delta.dy;
      if (dragDy == null) return false;
      if (_isAtTop(notification.metrics) && dragDy > 0) {
        _accumulatePullToMinimize(dragDy);
      } else if (dragDy < 0) {
        _pullDownAccumulated = 0;
      }
      return false;
    }

    if (notification is ScrollEndNotification) {
      _pullDownAccumulated = 0;
      _didTriggerMinimizeInGesture = false;
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Selector<
      VideoPlayerManager,
      ({
        String? currentVideoId,
        String? trackTitle,
        String? trackArtist,
        String? trackThumbnailUrl,
        bool isLocal,
        bool isLowPowerModeEnabled,
        bool isAppInForeground,
        bool isLyricsLayout,
        bool isLyricsLoading,
        String? lyricsError,
        String? lyricsText,
        int syncedLyricsCount,
        bool isLoading,
        bool isPlaying,
        bool autoplayEnabled,
        String? currentStreamUrl,
        bool isUsingVideoFallback,
        bool preferForegroundVideoPlayback,
        bool isFullScreen,
      })
    >(
      selector: (_, manager) => (
        currentVideoId: manager.currentVideoId,
        trackTitle: manager.trackTitle,
        trackArtist: manager.trackArtist,
        trackThumbnailUrl: manager.trackThumbnailUrl,
        isLocal: manager.isLocal,
        isLowPowerModeEnabled: manager.isLowPowerModeEnabled,
        isAppInForeground: manager.isAppInForeground,
        isLyricsLayout: manager.isLyricsLayout,
        isLyricsLoading: manager.isLyricsLoading,
        lyricsError: manager.lyricsError,
        lyricsText: manager.lyricsText,
        syncedLyricsCount: manager.syncedLyrics.length,
        isLoading: manager.isLoading,
        isPlaying: manager.isPlaying,
        autoplayEnabled: manager.autoplayEnabled,
        currentStreamUrl: manager.currentStreamUrl,
        isUsingVideoFallback: manager.isUsingVideoFallback,
        preferForegroundVideoPlayback: manager.preferForegroundVideoPlayback,
        isFullScreen: manager.isFullScreen,
      ),
      builder: (context, _, child) {
        final embeddedVideoController = manager.foregroundVideoController;
        final canShowEmbeddedVideo =
            manager.preferForegroundVideoPlayback &&
            embeddedVideoController != null &&
            embeddedVideoController.value.isInitialized;
        final isVideoFullScreen = manager.isFullScreen && canShowEmbeddedVideo;

        if (manager.isFullScreen && !canShowEmbeddedVideo) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            manager.setFullScreen(false);
          });
        }

        if (isVideoFullScreen) {
          return _FullscreenVideoStage(
            controller: embeddedVideoController,
            onExitFullscreen: () => manager.setFullScreen(false),
          );
        }

        final downloadService = context.watch<DownloadService>();
        final settings = context.watch<AppSettingsService?>();
        final playlistService = context.read<PlaylistService>();
        final videoId = manager.currentVideoId;
        final canDownload = videoId != null && !manager.isLocal;
        final canAddToPlaylist = videoId != null;
        final thermalSaverMode = manager.isLowPowerModeEnabled;
        final animatedCoverEnabled =
            (settings?.animatedCutoutCovers ?? true) && !thermalSaverMode;
        _maybeResolveAlbumBackgroundTint();
        _syncLyricsImmersiveMode(manager.isLyricsLayout);
        final lyricsImmersive = manager.isLyricsLayout && !_lyricsChromeVisible;
        final showLyricsControls =
            !manager.isLyricsLayout || _lyricsChromeVisible;
        final avoidVideoHeroOverlap = canShowEmbeddedVideo;

        return SizedBox.expand(
          child: Material(
            color: Colors.transparent,
            child: Stack(
              fit: StackFit.expand,
              children: [
                _buildAlbumBlurBackground(
                  context,
                  thermalSaver: thermalSaverMode,
                ),
                SafeArea(
                  child: Listener(
                    onPointerDown: (_) => _onLyricsPanelInteraction(),
                    child: Column(
                      children: [
                        Center(
                          child: Container(
                            width: 36,
                            height: 4,
                            margin: const EdgeInsets.only(top: 2, bottom: 6),
                            decoration: BoxDecoration(
                              color: CupertinoColors.systemGrey3
                                  .resolveFrom(context)
                                  .withValues(alpha: 0.7),
                              borderRadius: BorderRadius.circular(999),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 22),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              if (canShowEmbeddedVideo)
                                _TopGlassIconButton(
                                  icon: CupertinoIcons.rectangle_on_rectangle,
                                  onPressed: () => unawaited(
                                    manager.enterPictureInPictureNow(),
                                  ),
                                ),
                              _TopGlassIconButton(
                                icon: CupertinoIcons.square_arrow_up,
                                onPressed: () =>
                                    unawaited(_shareCurrentSongLink(context)),
                              ),
                              if (canDownload)
                                _DownloadButton(
                                  videoId: videoId,
                                  title: manager.trackTitle ?? 'Sin título',
                                  thumbnailUrl: manager.trackThumbnailUrl ?? '',
                                  channelTitle: manager.trackArtist ?? '',
                                  sourceUrl: manager.currentStreamUrl,
                                  isVideoSource: manager.isUsingVideoFallback,
                                  downloadService: downloadService,
                                ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: LayoutBuilder(
                            builder: (context, constraints) {
                              final screenWidth = MediaQuery.sizeOf(
                                context,
                              ).width;
                              final maxArtworkWidth = math.max(
                                220.0,
                                screenWidth - 48,
                              );
                              final halfViewportSize =
                                  constraints.maxHeight * 0.5;
                              final animatedArtworkSize = math
                                  .min(halfViewportSize, maxArtworkWidth)
                                  .clamp(220.0, 560.0)
                                  .toDouble();
                              final defaultArtworkSize = animatedCoverEnabled
                                  ? animatedArtworkSize
                                  : 310.0;
                              final collapsedLyricsHeight = math.max(
                                300.0,
                                math.min(339.0, constraints.maxHeight * 0.52),
                              );
                              final expandedLyricsHeight = math.max(
                                collapsedLyricsHeight + 120,
                                constraints.maxHeight * 0.90,
                              );
                              return NotificationListener<ScrollNotification>(
                                onNotification:
                                    _handleContentScrollNotification,
                                child: SingleChildScrollView(
                                  controller: _contentScrollController,
                                  physics: const ClampingScrollPhysics(
                                    parent: AlwaysScrollableScrollPhysics(),
                                  ),
                                  clipBehavior: Clip.none,
                                  padding: const EdgeInsets.fromLTRB(
                                    24,
                                    8,
                                    24,
                                    32,
                                  ),
                                  child: ConstrainedBox(
                                    constraints: BoxConstraints(
                                      minHeight: constraints.maxHeight - 40,
                                    ),
                                    child: Column(
                                      children: [
                                        TweenAnimationBuilder<double>(
                                          key: ValueKey(
                                            'full-hero-entry-${manager.currentVideoId}-${manager.isLyricsLayout}',
                                          ),
                                          tween: Tween<double>(
                                            begin: 0,
                                            end: 1,
                                          ),
                                          duration: const Duration(
                                            milliseconds: 440,
                                          ),
                                          curve: Curves.easeOutCubic,
                                          builder: (context, value, child) {
                                            final lift = (1 - value) * 40;
                                            final scale = 0.90 + (0.10 * value);
                                            return Opacity(
                                              opacity: value,
                                              child: Transform.translate(
                                                offset: Offset(0, lift),
                                                child: Transform.scale(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  scale: scale,
                                                  child: child,
                                                ),
                                              ),
                                            );
                                          },
                                          child: AnimatedSwitcher(
                                            duration: avoidVideoHeroOverlap
                                                ? Duration.zero
                                                : const Duration(
                                                    milliseconds: 420,
                                                  ),
                                            switchInCurve: Curves.easeOutCubic,
                                            switchOutCurve: Curves.easeInCubic,
                                            layoutBuilder:
                                                (
                                                  currentChild,
                                                  previousChildren,
                                                ) {
                                                  if (avoidVideoHeroOverlap) {
                                                    return currentChild ??
                                                        const SizedBox.shrink();
                                                  }
                                                  return Stack(
                                                    clipBehavior: Clip.none,
                                                    alignment:
                                                        Alignment.topCenter,
                                                    children: <Widget>[
                                                      ...previousChildren,
                                                      if (currentChild != null)
                                                        currentChild,
                                                    ],
                                                  );
                                                },
                                            transitionBuilder:
                                                (child, animation) {
                                                  final slide =
                                                      Tween<Offset>(
                                                        begin: const Offset(
                                                          0,
                                                          0.06,
                                                        ),
                                                        end: Offset.zero,
                                                      ).animate(
                                                        CurvedAnimation(
                                                          parent: animation,
                                                          curve: Curves
                                                              .easeOutCubic,
                                                        ),
                                                      );
                                                  return FadeTransition(
                                                    opacity: animation,
                                                    child: SlideTransition(
                                                      position: slide,
                                                      child: child,
                                                    ),
                                                  );
                                                },
                                            child: manager.isLyricsLayout
                                                ? _CompactNowPlayingHeader(
                                                    key: const ValueKey(
                                                      'compact_now_playing_header',
                                                    ),
                                                    manager: manager,
                                                    preferStaticArtwork:
                                                        thermalSaverMode,
                                                    onArtworkTap: manager
                                                        .toggleLyricsLayout,
                                                    onArtistTap: () =>
                                                        _openArtistProfile(
                                                          context,
                                                        ),
                                                    canAddToPlaylist:
                                                        canAddToPlaylist,
                                                    onAddToPlaylist: () =>
                                                        _showAddToPlaylistSheet(
                                                          context: context,
                                                          playlistService:
                                                              playlistService,
                                                          downloadService:
                                                              downloadService,
                                                          manager: manager,
                                                        ),
                                                    onAddToFavorites: () =>
                                                        _addCurrentTrackToFavorites(
                                                          context: context,
                                                          playlistService:
                                                              playlistService,
                                                          downloadService:
                                                              downloadService,
                                                          manager: manager,
                                                        ),
                                                  )
                                                : canShowEmbeddedVideo
                                                ? _EmbeddedNowPlayingVideoHero(
                                                    key: const ValueKey(
                                                      'embedded_now_playing_video_hero',
                                                    ),
                                                    manager: manager,
                                                    controller:
                                                        embeddedVideoController,
                                                    artworkSize:
                                                        defaultArtworkSize,
                                                    onToggleFullscreen: () =>
                                                        manager.setFullScreen(
                                                          true,
                                                        ),
                                                    onArtistTap: () =>
                                                        _openArtistProfile(
                                                          context,
                                                        ),
                                                    canAddToPlaylist:
                                                        canAddToPlaylist,
                                                    onAddToPlaylist: () =>
                                                        _showAddToPlaylistSheet(
                                                          context: context,
                                                          playlistService:
                                                              playlistService,
                                                          downloadService:
                                                              downloadService,
                                                          manager: manager,
                                                        ),
                                                    onAddToFavorites: () =>
                                                        _addCurrentTrackToFavorites(
                                                          context: context,
                                                          playlistService:
                                                              playlistService,
                                                          downloadService:
                                                              downloadService,
                                                          manager: manager,
                                                        ),
                                                  )
                                                : _DefaultNowPlayingHero(
                                                    key: const ValueKey(
                                                      'default_now_playing_hero',
                                                    ),
                                                    manager: manager,
                                                    artworkSize:
                                                        defaultArtworkSize,
                                                    preferStaticArtwork:
                                                        thermalSaverMode,
                                                    onArtistTap: () =>
                                                        _openArtistProfile(
                                                          context,
                                                        ),
                                                    canAddToPlaylist:
                                                        canAddToPlaylist,
                                                    onAddToPlaylist: () =>
                                                        _showAddToPlaylistSheet(
                                                          context: context,
                                                          playlistService:
                                                              playlistService,
                                                          downloadService:
                                                              downloadService,
                                                          manager: manager,
                                                        ),
                                                    onAddToFavorites: () =>
                                                        _addCurrentTrackToFavorites(
                                                          context: context,
                                                          playlistService:
                                                              playlistService,
                                                          downloadService:
                                                              downloadService,
                                                          manager: manager,
                                                        ),
                                                  ),
                                          ),
                                        ),
                                        if (manager.isLyricsLayout) ...[
                                          const SizedBox(height: 14),
                                          AnimatedContainer(
                                            duration: const Duration(
                                              milliseconds: 420,
                                            ),
                                            curve:
                                                Curves.easeInOutCubicEmphasized,
                                            height: lyricsImmersive
                                                ? expandedLyricsHeight
                                                : collapsedLyricsHeight,
                                            child: _LyricsPanel(
                                              manager: manager,
                                              immersiveMode: lyricsImmersive,
                                              onInteraction:
                                                  _onLyricsPanelInteraction,
                                              onRevealRequest:
                                                  _onLyricsPanelRevealRequest,
                                              onImmersiveRequest:
                                                  _onLyricsPanelImmersiveRequest,
                                            ),
                                          ),
                                        ],
                                        ClipRect(
                                          child: AnimatedAlign(
                                            duration: const Duration(
                                              milliseconds: 420,
                                            ),
                                            curve:
                                                Curves.easeInOutCubicEmphasized,
                                            alignment: Alignment.topCenter,
                                            heightFactor: showLyricsControls
                                                ? 1
                                                : 0,
                                            child: AnimatedOpacity(
                                              duration: const Duration(
                                                milliseconds: 260,
                                              ),
                                              curve: Curves.easeInOutCubic,
                                              opacity: showLyricsControls
                                                  ? 1
                                                  : 0,
                                              child: IgnorePointer(
                                                ignoring: !showLyricsControls,
                                                child: AnimatedSlide(
                                                  duration: const Duration(
                                                    milliseconds: 420,
                                                  ),
                                                  curve: Curves
                                                      .easeInOutCubicEmphasized,
                                                  offset: Offset.zero,
                                                  child: Column(
                                                    children: [
                                                      const SizedBox(
                                                        height: 10,
                                                      ),
                                                      if (manager.isLoading &&
                                                          !manager.isPlaying)
                                                        const Padding(
                                                          padding:
                                                              EdgeInsets.symmetric(
                                                                vertical: 20,
                                                              ),
                                                          child:
                                                              _IosLoadingControls(),
                                                        )
                                                      else ...[
                                                        const _ProgressSection(),
                                                        const SizedBox(
                                                          height: 10,
                                                        ),
                                                        Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .spaceEvenly,
                                                          children: [
                                                            _NativeControlButton(
                                                              icon: CupertinoIcons
                                                                  .backward_fill,
                                                              onPressed: manager
                                                                  .playPreviousInQueue,
                                                            ),
                                                            _NativePrimaryPlayButton(
                                                              isPlaying: manager
                                                                  .isPlaying,
                                                              onPressed: manager
                                                                  .togglePlayPause,
                                                            ),
                                                            _NativeControlButton(
                                                              icon: CupertinoIcons
                                                                  .forward_fill,
                                                              onPressed: manager
                                                                  .playNextInQueue,
                                                            ),
                                                          ],
                                                        ),
                                                        const SizedBox(
                                                          height: 6,
                                                        ),
                                                        SizedBox(height: 28),
                                                        if (Platform.isIOS) ...[
                                                          const _SystemVolumeSlider(),
                                                          const SizedBox(
                                                            height: 14,
                                                          ),
                                                        ],

                                                        Row(
                                                          children: [
                                                            const SizedBox(
                                                              width: 34,
                                                            ),
                                                            _InlineLyricsButton(
                                                              isActive: manager
                                                                  .isLyricsLayout,
                                                              onPressed: manager
                                                                  .toggleLyricsLayout,
                                                            ),
                                                            const Spacer(),
                                                            const _InlineAudioRouteButton(),
                                                            const Spacer(),
                                                            _InlineAutoplayButton(
                                                              isActive: manager
                                                                  .autoplayEnabled,
                                                              onPressed: manager
                                                                  .toggleAutoplay,
                                                            ),
                                                          ],
                                                        ),

                                                        SizedBox(
                                                          height:
                                                              MediaQuery.of(
                                                                context,
                                                              ).padding.bottom +
                                                              50,
                                                        ),
                                                      ],
                                                      // Removed SizedBox(height: 26),
                                                      const _QueueSection(),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _showAddToPlaylistSheet({
    required BuildContext context,
    required PlaylistService playlistService,
    required DownloadService downloadService,
    required VideoPlayerManager manager,
  }) async {
    final playlists = await playlistService.getPlaylists();
    if (!context.mounted) return;

    if (playlists.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No hay playlists disponibles.')),
      );
      return;
    }

    final selectedName = await showGlassPlaylistPickerSheet(
      context: context,
      playlists: playlists,
      subtitle: manager.trackTitle,
    );
    if (!context.mounted || selectedName == null || selectedName.isEmpty) {
      return;
    }
    final selected = playlists.firstWhere(
      (playlist) => playlist.name == selectedName,
      orElse: () => app_models.Playlist(name: selectedName),
    );
    await _addCurrentTrackToPlaylist(
      context: context,
      playlistService: playlistService,
      downloadService: downloadService,
      manager: manager,
      playlist: selected,
    );
  }

  Future<void> _addCurrentTrackToPlaylist({
    required BuildContext context,
    required PlaylistService playlistService,
    required DownloadService downloadService,
    required VideoPlayerManager manager,
    required app_models.Playlist playlist,
  }) async {
    final videoId = manager.currentVideoId;
    if (videoId == null) return;

    final track = VideoHistory(
      videoId: videoId,
      title: manager.trackTitle ?? 'Sin título',
      thumbnailUrl: manager.trackThumbnailUrl ?? '',
      channelTitle: manager.trackArtist ?? '',
      watchedAt: DateTime.now(),
    );

    await playlistService.addVideoToPlaylist(playlist.name, track);
    await downloadService.autoDownloadIfEnabledUsingClone(
      playlist.name,
      track,
      videoManager: manager,
    );
    if (!context.mounted) return;
    _showIosTopToast(
      context,
      message: 'Añadida a ${playlist.name}',
      icon: CupertinoIcons.check_mark_circled_solid,
    );
  }

  Future<void> _addCurrentTrackToFavorites({
    required BuildContext context,
    required PlaylistService playlistService,
    required DownloadService downloadService,
    required VideoPlayerManager manager,
  }) async {
    final playlists = await playlistService.getPlaylists();
    final favorites = playlists.firstWhere(
      (playlist) => PlaylistService.isFavoritesPlaylistName(playlist.name),
      orElse: () =>
          app_models.Playlist(name: PlaylistService.favoritesPlaylistName),
    );

    final videoId = manager.currentVideoId;
    if (videoId == null) return;

    final track = VideoHistory(
      videoId: videoId,
      title: manager.trackTitle ?? 'Sin título',
      thumbnailUrl: manager.trackThumbnailUrl ?? '',
      channelTitle: manager.trackArtist ?? '',
      watchedAt: DateTime.now(),
    );

    await playlistService.addVideoToPlaylist(favorites.name, track);
    await downloadService.autoDownloadIfEnabledUsingClone(
      favorites.name,
      track,
      videoManager: manager,
    );
    if (!context.mounted) return;
    _showIosTopToast(
      context,
      message: 'Añadida a Favoritos',
      icon: CupertinoIcons.star_fill,
    );
  }

  void _showIosTopToast(
    BuildContext context, {
    required String message,
    required IconData icon,
  }) {
    final overlay = Overlay.of(context, rootOverlay: true);
    final isDark = Theme.of(context).brightness == Brightness.dark;

    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (overlayContext) {
        final bottomInset = MediaQuery.of(overlayContext).padding.bottom;
        return IgnorePointer(
          ignoring: true,
          child: SizedBox.expand(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: EdgeInsets.only(bottom: bottomInset + 130),
                child: _IosTopToast(
                  message: message,
                  icon: icon,
                  isDark: isDark,
                ),
              ),
            ),
          ),
        );
      },
    );
    overlay.insert(entry);
    Timer(const Duration(milliseconds: 1900), () {
      entry.remove();
    });
  }

  Future<void> _shareCurrentSongLink(BuildContext context) async {
    final renderBox = context.findRenderObject() as RenderBox?;
    final shareOrigin = renderBox != null && renderBox.hasSize
        ? renderBox.localToGlobal(Offset.zero) & renderBox.size
        : const Rect.fromLTWH(1, 1, 1, 1);

    final videoId = manager.currentVideoId?.trim() ?? '';
    if (videoId.isEmpty) {
      _showIosTopToast(
        context,
        message: 'No hay canción para compartir',
        icon: CupertinoIcons.info_circle_fill,
      );
      return;
    }

    final title = (manager.trackTitle ?? 'Sin título').trim();
    final artist = (manager.trackArtist ?? '').trim();
    final thumbnailUrl = _shareThumbnailUrlForVideo(
      videoId: videoId,
      fallback: manager.trackThumbnailUrl,
    );
    final durationMs = manager.trackDuration.inMilliseconds;
    final deepLink = Uri(
      scheme: 'vmmusic',
      host: 'song',
      queryParameters: <String, String>{
        'videoId': videoId,
        if (title.isNotEmpty) 'title': title,
        if (artist.isNotEmpty) 'artist': artist,
        if (thumbnailUrl.isNotEmpty) 'thumbnailUrl': thumbnailUrl,
        if (durationMs > 0) 'durationMs': '$durationMs',
      },
    ).toString();

    final tempDir = await getTemporaryDirectory();
    final safeId = videoId.replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '_');
    final safeTitle = title
        .replaceAll(RegExp(r'\s+'), '_')
        .replaceAll(RegExp(r'[^a-zA-Z0-9_-]'), '')
        .trim();
    final baseName = safeTitle.isEmpty ? safeId : '${safeTitle}_$safeId';
    XFile? artworkFile;
    try {
      final imageBytes = await _loadShareImageBytes(
        thumbnailUrl,
        videoId: videoId,
      );
      if (imageBytes != null && imageBytes.isNotEmpty) {
        final isPng = _isPngBytes(imageBytes);
        final ext = isPng ? 'png' : 'jpg';
        final mimeType = isPng ? 'image/png' : 'image/jpeg';
        final imageFile = File('${tempDir.path}/${baseName}_cover.$ext');
        await imageFile.writeAsBytes(imageBytes, flush: true);
        artworkFile = XFile(
          imageFile.path,
          mimeType: mimeType,
          name: '${baseName}_cover.$ext',
        );
      }
    } catch (_) {}

    await SharePlus.instance.share(
      ShareParams(
        files: artworkFile != null ? <XFile>[artworkFile] : null,
        subject: 'VM Music',
        text: '${artist.isEmpty ? title : '$title · $artist'}\n$deepLink',
        sharePositionOrigin: shareOrigin,
      ),
    );
  }

  Future<Uint8List?> _loadShareImageBytes(
    String raw, {
    required String videoId,
  }) async {
    final source = raw.trim();
    final remoteSource = source.startsWith('/') ? '' : source;

    final candidates = buildThumbnailCandidates(
      videoId: videoId,
      thumbnailUrl: remoteSource.isEmpty ? null : remoteSource,
      preferLowResolution: false,
    );
    if (candidates.isEmpty && remoteSource.isNotEmpty) {
      final uri = Uri.tryParse(remoteSource);
      if (uri != null) candidates.add(source);
    }

    final client = HttpClient()
      ..connectionTimeout = const Duration(seconds: 12);
    try {
      for (final candidate in candidates) {
        final uri = Uri.tryParse(candidate);
        if (uri == null) continue;
        try {
          final req = await client
              .getUrl(uri)
              .timeout(const Duration(seconds: 12));
          req.headers.set(
            HttpHeaders.userAgentHeader,
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)',
          );
          req.headers.set(HttpHeaders.acceptHeader, 'image/*,*/*;q=0.8');
          final res = await req.close().timeout(const Duration(seconds: 16));
          if (res.statusCode < 200 || res.statusCode >= 300) continue;
          final bytes = await consolidateHttpClientResponseBytes(res);
          if (bytes.isEmpty) continue;
          final preparedArtwork = await compute<Uint8List, Uint8List?>(
            _prepareArtworkForCutoutWorker,
            bytes,
          );
          if (preparedArtwork != null && preparedArtwork.isNotEmpty) {
            // Compartimos la carátula cuadrada como la muestra el reproductor,
            // no el recorte de sujeto.
            return preparedArtwork;
          }
          return bytes;
        } catch (_) {
          continue;
        }
      }
      return null;
    } finally {
      client.close(force: true);
    }
  }

  String _shareThumbnailUrlForVideo({
    required String videoId,
    String? fallback,
  }) {
    final cleanId = videoId.trim();
    if (cleanId.isNotEmpty) {
      return 'https://i.ytimg.com/vi/$cleanId/hqdefault.jpg';
    }
    final rawFallback = (fallback ?? '').trim();
    if (rawFallback.startsWith('/')) return '';
    return rawFallback;
  }

  bool _isPngBytes(Uint8List bytes) {
    if (bytes.length < 8) return false;
    return bytes[0] == 0x89 &&
        bytes[1] == 0x50 &&
        bytes[2] == 0x4E &&
        bytes[3] == 0x47 &&
        bytes[4] == 0x0D &&
        bytes[5] == 0x0A &&
        bytes[6] == 0x1A &&
        bytes[7] == 0x0A;
  }

  Future<void> _openArtistProfile(BuildContext context) async {
    if (_isOpeningArtistProfile) return;
    _isOpeningArtistProfile = true;
    final currentVideoId = (manager.currentVideoId ?? '').trim();
    final rawArtist = manager.trackArtist?.trim();
    if (currentVideoId.isEmpty && (rawArtist == null || rawArtist.isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se encontró el nombre del artista.')),
      );
      _isOpeningArtistProfile = false;
      return;
    }

    final yt = YoutubeExplode();
    try {
      String? channelId;
      String? channelName;
      String thumb = manager.trackThumbnailUrl ?? '';

      if (currentVideoId.isNotEmpty) {
        // Igual que en Buscar: el canal sale del video actual para evitar mismatches.
        final details = await yt.channels.getByVideo(currentVideoId);
        channelId = details.id.value;
        channelName = details.title;
        thumb = details.logoUrl.isNotEmpty ? details.logoUrl : thumb;
      } else if (rawArtist != null && rawArtist.isNotEmpty) {
        final raw = await yt.search.searchContent(
          rawArtist,
          filter: TypeFilters.channel,
        );
        final channels = raw.whereType<SearchChannel>().take(1).toList();
        if (channels.isNotEmpty) {
          final best = channels.first;
          channelId = best.id.value;
          channelName = best.name;
          thumb = best.thumbnails.isNotEmpty
              ? best.thumbnails.first.url.toString()
              : thumb;
        }
      }

      if (channelId == null ||
          channelId.trim().isEmpty ||
          channelName == null ||
          channelName.trim().isEmpty) {
        if (!context.mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('No se encontró un perfil para este artista.'),
          ),
        );
        return;
      }

      if (!context.mounted) return;
      context.read<SearchViewState>().requestOpenArtistProfile(
        PendingArtistProfile(
          channelId: channelId,
          channelName: channelName,
          channelThumbnailUrl: thumb,
        ),
      );
      context.read<AppTabState?>()?.setIndex(1);
      manager.minimize();
    } catch (e, s) {
      developer.log(
        'Error al abrir perfil del artista',
        error: e,
        stackTrace: s,
      );
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('No se pudo abrir el perfil del artista.'),
        ),
      );
    } finally {
      yt.close();
      _isOpeningArtistProfile = false;
    }
  }
}

class _InlineLyricsButton extends StatelessWidget {
  final bool isActive;
  final VoidCallback onPressed;

  const _InlineLyricsButton({required this.isActive, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    final borderRadius = BorderRadius.circular(14);
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size.zero,
      onPressed: onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
          color: isActive ? Colors.white : Colors.transparent,
          borderRadius: borderRadius,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              isActive
                  ? CupertinoIcons.quote_bubble_fill
                  : CupertinoIcons.quote_bubble,
              size: 26,
              color: isActive
                  ? Colors.black
                  : CupertinoColors.white,
            ),
          ],
        ),
      ),
    );
  }
}

class _InlineAudioRouteButton extends StatefulWidget {
  const _InlineAudioRouteButton();

  @override
  State<_InlineAudioRouteButton> createState() =>
      _InlineAudioRouteButtonState();
}

class _InlineAudioRouteButtonState extends State<_InlineAudioRouteButton> {
  String _routeName = 'iPhone Speaker';
  bool _isBluetooth = false;
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();
    unawaited(_loadRouteInfo());
    _pollTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      unawaited(_loadRouteInfo());
    });
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    super.dispose();
  }

  Future<void> _loadRouteInfo() async {
    if (!Platform.isIOS) return;
    try {
      final raw = await _systemVolumeChannel
          .invokeMethod<Map<dynamic, dynamic>>('getCurrentAudioOutputInfo');
      if (!mounted || raw == null) return;
      final nextName = (raw['name'] as String?)?.trim();
      final nextIsBluetooth = raw['isBluetooth'] == true;
      final resolvedName = (nextName == null || nextName.isEmpty)
          ? 'Salida de audio'
          : nextName;
      if (resolvedName == _routeName && nextIsBluetooth == _isBluetooth) {
        return;
      }
      setState(() {
        _routeName = resolvedName;
        _isBluetooth = nextIsBluetooth;
      });
    } catch (_) {}
  }

  Future<void> _openRoutePicker() async {
    if (!Platform.isIOS) return;
    try {
      await _systemVolumeChannel.invokeMethod<void>('showAudioRoutePicker');
    } catch (_) {}
    unawaited(_loadRouteInfo());
  }

  _AudioRouteVisual _resolveRouteVisual() {
    final raw = _routeName.trim().toLowerCase();
    if (raw.isEmpty) {
      return _isBluetooth
          ? _AudioRouteVisual.bluetooth
          : _AudioRouteVisual.airplay;
    }
    if (raw == 'iphone speaker' || raw == 'iphone') {
      return _AudioRouteVisual.iphone;
    }
    if (raw.contains('reniiii')) {
      return _AudioRouteVisual.airpods;
    }

    final compact = raw.replaceAll(RegExp(r'[\s\-_]+'), '');
    final hasAirpodsWord = raw.contains('airpods') || raw.contains('airpod');

    if (hasAirpodsWord) {
      if (compact.contains('airpodsmax') || compact.contains('airpodmax')) {
        return _AudioRouteVisual.airpodsMax;
      }
      if (compact.contains('airpodspro2') || compact.contains('airpodpro2')) {
        return _AudioRouteVisual.airpods;
      }
      if (compact.contains('airpodspro') || compact.contains('airpodpro')) {
        return _AudioRouteVisual.airpods;
      }
      if (compact.contains('airpods3') || compact.contains('airpod3')) {
        return _AudioRouteVisual.airpods;
      }
      if (compact.contains('airpods2') || compact.contains('airpod2')) {
        return _AudioRouteVisual.airpods;
      }
      return _AudioRouteVisual.airpods;
    }

    return _isBluetooth
        ? _AudioRouteVisual.bluetooth
        : _AudioRouteVisual.airplay;
  }

  Widget _buildRouteIcon(Color color) {
    final visual = _resolveRouteVisual();
    switch (visual) {
      case _AudioRouteVisual.airpods:
        return _AirPodsIcon(color: color, size: 21);
      case _AudioRouteVisual.airpodsMax:
        return Icon(CupertinoIcons.headphones, size: 21, color: color);
      case _AudioRouteVisual.bluetooth:
        return Icon(Icons.bluetooth, size: 21, color: color);
      case _AudioRouteVisual.iphone:
        return Icon(
          CupertinoIcons.device_phone_portrait,
          size: 21,
          color: color,
        );
      case _AudioRouteVisual.airplay:
        return Icon(Icons.airplay, size: 21, color: color);
    }
  }

  @override
  Widget build(BuildContext context) {
    final labelColor = CupertinoColors.white.withValues(alpha: 0.86);
    final iconColor = CupertinoColors.white;
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size.zero,
      onPressed: _openRoutePicker,
      child: ConstrainedBox(
        constraints: const BoxConstraints(minWidth: 94, maxWidth: 146),
        child: Transform.translate(
          offset: const Offset(0, 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildRouteIcon(iconColor),
              const SizedBox(height: 2),
              Text(
                _routeName,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: CupertinoTheme.of(context).textTheme.textStyle.copyWith(
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  color: labelColor,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

enum _AudioRouteVisual { airplay, bluetooth, iphone, airpods, airpodsMax }

class _AirPodsIcon extends StatelessWidget {
  final Color color;
  final double size;

  const _AirPodsIcon({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _AirPodsPainter(color)),
    );
  }
}

class _AirPodsPainter extends CustomPainter {
  final Color color;
  const _AirPodsPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = size.width * 0.11;

    final fill = Paint()
      ..color = color.withValues(alpha: 0.18)
      ..style = PaintingStyle.fill;

    final leftBud = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        size.width * 0.12,
        size.height * 0.16,
        size.width * 0.27,
        size.height * 0.36,
      ),
      Radius.circular(size.width * 0.12),
    );
    canvas.drawRRect(leftBud, fill);
    canvas.drawRRect(leftBud, paint);
    canvas.drawLine(
      Offset(size.width * 0.26, size.height * 0.50),
      Offset(size.width * 0.22, size.height * 0.89),
      paint,
    );

    final rightBud = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        size.width * 0.61,
        size.height * 0.16,
        size.width * 0.27,
        size.height * 0.36,
      ),
      Radius.circular(size.width * 0.12),
    );
    canvas.drawRRect(rightBud, fill);
    canvas.drawRRect(rightBud, paint);
    canvas.drawLine(
      Offset(size.width * 0.74, size.height * 0.50),
      Offset(size.width * 0.78, size.height * 0.89),
      paint,
    );
  }

  @override
  bool shouldRepaint(covariant _AirPodsPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

class _InlineAutoplayButton extends StatelessWidget {
  final bool isActive;
  final VoidCallback onPressed;

  const _InlineAutoplayButton({
    required this.isActive,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    final borderRadius = BorderRadius.circular(14);
    const activeColor = Color(0xFF1FBF64);
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size.zero,
      onPressed: onPressed,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        curve: Curves.easeOutCubic,
        height: 30,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          borderRadius: borderRadius,
          gradient: isActive
              ? LinearGradient(
                  colors: [
                    activeColor.withValues(alpha: 0.28),
                    activeColor.withValues(alpha: 0.16),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [
                    CupertinoColors.systemGrey6
                        .resolveFrom(context)
                        .withValues(alpha: 0.56),
                    CupertinoColors.systemGrey5
                        .resolveFrom(context)
                        .withValues(alpha: 0.44),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          border: Border.all(
            color: isActive
                ? activeColor.withValues(alpha: 0.40)
                : CupertinoColors.white.withValues(alpha: 0.22),
            width: 0.8,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              CupertinoIcons.dot_radiowaves_left_right,
              size: 14,
              color: isActive
                  ? activeColor
                  : CupertinoColors.white,
            ),
            const SizedBox(width: 6),
            Text(
              'Autoplay',
              style: CupertinoTheme.of(context).textTheme.textStyle.copyWith(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: isActive ? activeColor : CupertinoColors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ArtworkSwipeNavigator extends StatefulWidget {
  final VideoPlayerManager manager;
  final Widget child;
  final VoidCallback? onTap;

  const _ArtworkSwipeNavigator({
    required this.manager,
    required this.child,
    this.onTap,
  });

  @override
  State<_ArtworkSwipeNavigator> createState() => _ArtworkSwipeNavigatorState();
}

class _ArtworkSwipeNavigatorState extends State<_ArtworkSwipeNavigator> {
  static const double _swipeDistanceThreshold = 36;
  static const double _swipeVelocityThreshold = 320;
  bool _isSwitchingTrack = false;
  double _dragDx = 0;

  bool _shouldTriggerSwipe(DragEndDetails details) {
    final velocity = details.primaryVelocity ?? 0;
    return _dragDx.abs() >= _swipeDistanceThreshold ||
        velocity.abs() >= _swipeVelocityThreshold;
  }

  Future<void> _handleSwipe(bool toNext) async {
    if (_isSwitchingTrack) return;
    _isSwitchingTrack = true;
    unawaited(HapticFeedback.selectionClick());
    try {
      if (toNext) {
        await widget.manager.playNextInQueue();
      } else {
        await widget.manager.playPreviousInQueue();
      }
    } finally {
      _isSwitchingTrack = false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      onHorizontalDragStart: (_) {
        _dragDx = 0;
      },
      onHorizontalDragUpdate: (details) {
        _dragDx += details.delta.dx;
      },
      onHorizontalDragEnd: (details) {
        if (!_shouldTriggerSwipe(details)) {
          _dragDx = 0;
          return;
        }
        final velocity = details.primaryVelocity ?? 0;
        final swipeRight = velocity > 0 || (velocity == 0 && _dragDx > 0);
        unawaited(_handleSwipe(!swipeRight));
        _dragDx = 0;
      },
      onHorizontalDragCancel: () {
        _dragDx = 0;
      },
      child: widget.child,
    );
  }
}

class _DefaultNowPlayingHero extends StatelessWidget {
  final VideoPlayerManager manager;
  final double artworkSize;
  final bool preferStaticArtwork;
  final VoidCallback onArtistTap;
  final bool canAddToPlaylist;
  final VoidCallback onAddToPlaylist;
  final VoidCallback onAddToFavorites;

  const _DefaultNowPlayingHero({
    super.key,
    required this.manager,
    required this.artworkSize,
    required this.preferStaticArtwork,
    required this.onArtistTap,
    required this.canAddToPlaylist,
    required this.onAddToPlaylist,
    required this.onAddToFavorites,
  });

  @override
  Widget build(BuildContext context) {
    final transitionDx = manager.trackTransitionDirection < 0 ? -0.03 : 0.03;
    final motionEnergy = _estimateTrackMotionEnergy(
      manager.trackTitle,
      manager.trackArtist,
    );
    return Column(
      key: key,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: _ArtworkSwipeNavigator(
            manager: manager,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 260),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, animation) {
                return FadeTransition(
                  opacity: animation,
                  child: ScaleTransition(
                    scale: Tween<double>(
                      begin: 0.985,
                      end: 1.0,
                    ).animate(animation),
                    child: child,
                  ),
                );
              },
              child: _ArtworkImage(
                key: ValueKey(
                  'hero-artwork-${manager.trackThumbnailUrl ?? ''}',
                ),
                url: manager.trackThumbnailUrl,
                size: artworkSize,
                animated: !preferStaticArtwork,
                isPlaying: manager.isPlaying,
                motionEnergy: motionEnergy,
              ),
            ),
          ),
        ),
        const SizedBox(height: 28),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          transitionBuilder: (child, animation) => FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: Offset(transitionDx, 0),
                end: Offset.zero,
              ).animate(animation),
              child: child,
            ),
          ),
          child: SizedBox(
            key: ValueKey('hero_title_${manager.currentVideoId ?? ''}'),
            width: double.infinity,
            child: _AutoScrollText(
              text: manager.trackTitle ?? 'Cargando canción...',
              style: CupertinoTheme.of(context).textTheme.navLargeTitleTextStyle
                  .copyWith(
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    color: CupertinoColors.white,
                  ),
            ),
          ),
        ),
        const SizedBox(height: 2),
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: onArtistTap,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 280),
                  switchInCurve: Curves.easeOutCubic,
                  switchOutCurve: Curves.easeInCubic,
                  layoutBuilder: (currentChild, previousChildren) {
                    return Stack(
                      alignment: Alignment.centerLeft,
                      children: <Widget>[
                        ...previousChildren,
                        if (currentChild != null) currentChild,
                      ],
                    );
                  },
                  transitionBuilder: (child, animation) => FadeTransition(
                    opacity: animation,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: Offset(transitionDx, 0),
                        end: Offset.zero,
                      ).animate(animation),
                      child: child,
                    ),
                  ),
                  child: KeyedSubtree(
                    key: ValueKey(
                      'hero_artist_${manager.currentVideoId ?? ''}',
                    ),
                    child: _AutoScrollText(
                      text: manager.trackArtist ?? 'Artista desconocido',
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            fontSize: 17,
                            color: CupertinoColors.white.withValues(
                              alpha: 0.78,
                            ),
                          ),
                    ),
                  ),
                ),
              ),
            ),
            if (canAddToPlaylist) ...[
              const SizedBox(width: 8),
              _InlineArtistActionButton(
                icon: CupertinoIcons.add,
                onPressed: onAddToPlaylist,
              ),
              const SizedBox(width: 6),
              _InlineArtistActionButton(
                icon: CupertinoIcons.star_fill,
                onPressed: onAddToFavorites,
              ),
            ],
          ],
        ),
      ],
    );
  }
}

class _EmbeddedNowPlayingVideoHero extends StatelessWidget {
  final VideoPlayerManager manager;
  final VideoPlayerController controller;
  final double artworkSize;
  final VoidCallback onToggleFullscreen;
  final VoidCallback onArtistTap;
  final bool canAddToPlaylist;
  final VoidCallback onAddToPlaylist;
  final VoidCallback onAddToFavorites;

  const _EmbeddedNowPlayingVideoHero({
    super.key,
    required this.manager,
    required this.controller,
    required this.artworkSize,
    required this.onToggleFullscreen,
    required this.onArtistTap,
    required this.canAddToPlaylist,
    required this.onAddToPlaylist,
    required this.onAddToFavorites,
  });

  @override
  Widget build(BuildContext context) {
    final transitionDx = manager.trackTransitionDirection < 0 ? -0.03 : 0.03;
    const ratio = 240 / 140;
    return Column(
      key: key,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Center(
          child: SizedBox(
            width: artworkSize,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Stack(
                alignment: Alignment.bottomRight,
                children: [
                  AspectRatio(
                    aspectRatio: ratio,
                    child: VideoPlayer(controller),
                  ),
                  SafeArea(
                    minimum: const EdgeInsets.all(8),
                    child: CupertinoButton(
                      minimumSize: Size.zero,
                      padding: const EdgeInsets.all(8),
                      onPressed: onToggleFullscreen,
                      child: const Icon(
                        CupertinoIcons.fullscreen,
                        size: 20,
                        color: CupertinoColors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 28),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          transitionBuilder: (child, animation) => FadeTransition(
            opacity: animation,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: Offset(transitionDx, 0),
                end: Offset.zero,
              ).animate(animation),
              child: child,
            ),
          ),
          child: SizedBox(
            key: ValueKey('video_hero_title_${manager.currentVideoId ?? ''}'),
            width: double.infinity,
            child: _AutoScrollText(
              text: manager.trackTitle ?? 'Cargando video...',
              style: CupertinoTheme.of(context).textTheme.navLargeTitleTextStyle
                  .copyWith(
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                    color: CupertinoColors.white,
                  ),
            ),
          ),
        ),
        const SizedBox(height: 2),
        Row(
          children: [
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: onArtistTap,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 280),
                  switchInCurve: Curves.easeOutCubic,
                  switchOutCurve: Curves.easeInCubic,
                  layoutBuilder: (currentChild, previousChildren) {
                    return Stack(
                      alignment: Alignment.centerLeft,
                      children: <Widget>[
                        ...previousChildren,
                        if (currentChild != null) currentChild,
                      ],
                    );
                  },
                  transitionBuilder: (child, animation) => FadeTransition(
                    opacity: animation,
                    child: SlideTransition(
                      position: Tween<Offset>(
                        begin: Offset(transitionDx, 0),
                        end: Offset.zero,
                      ).animate(animation),
                      child: child,
                    ),
                  ),
                  child: KeyedSubtree(
                    key: ValueKey(
                      'video_hero_artist_${manager.currentVideoId ?? ''}',
                    ),
                    child: _AutoScrollText(
                      text: manager.trackArtist ?? 'Artista desconocido',
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            fontSize: 17,
                            color: CupertinoColors.white.withValues(
                              alpha: 0.78,
                            ),
                          ),
                    ),
                  ),
                ),
              ),
            ),
            if (canAddToPlaylist) ...[
              const SizedBox(width: 8),
              _InlineArtistActionButton(
                icon: CupertinoIcons.add,
                onPressed: onAddToPlaylist,
              ),
              const SizedBox(width: 6),
              _InlineArtistActionButton(
                icon: CupertinoIcons.star_fill,
                onPressed: onAddToFavorites,
              ),
            ],
          ],
        ),
      ],
    );
  }
}

class _FullscreenVideoStage extends StatelessWidget {
  final VideoPlayerController controller;
  final VoidCallback onExitFullscreen;

  const _FullscreenVideoStage({
    required this.controller,
    required this.onExitFullscreen,
  });

  @override
  Widget build(BuildContext context) {
    final value = controller.value;
    final ratio = value.isInitialized && value.aspectRatio > 0
        ? value.aspectRatio
        : (16 / 9);
    return SizedBox.expand(
      child: ColoredBox(
        color: Colors.black,
        child: Stack(
          fit: StackFit.expand,
          children: [
            Center(
              child: AspectRatio(
                aspectRatio: ratio,
                child: VideoPlayer(controller),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topRight,
                child: Padding(
                  padding: const EdgeInsets.only(top: 8, right: 8),
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: CupertinoColors.black.withValues(alpha: 0.55),
                      borderRadius: BorderRadius.circular(999),
                    ),
                    child: CupertinoButton(
                      minimumSize: Size.zero,
                      padding: const EdgeInsets.all(10),
                      onPressed: onExitFullscreen,
                      child: const Icon(
                        CupertinoIcons.fullscreen_exit,
                        color: CupertinoColors.white,
                        size: 22,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

double _estimateTrackMotionEnergy(String? title, String? artist) {
  final text = '${title ?? ''} ${artist ?? ''}'.toLowerCase();
  var score = 1.0;

  const highEnergyHints = <String>[
    'remix',
    'live',
    'edm',
    'hardstyle',
    'phonk',
    'trap',
    'drill',
    'dnb',
    'techno',
    'house',
    'rock',
    'metal',
    'boosted',
    'nightcore',
    'sped up',
  ];
  const lowEnergyHints = <String>[
    'acoustic',
    'piano',
    'ballad',
    'slowed',
    'reverb',
    'instrumental',
    'lofi',
    'lo-fi',
    'ambient',
    'soft',
    'calm',
    'sleep',
  ];

  for (final hint in highEnergyHints) {
    if (text.contains(hint)) score += 0.06;
  }
  for (final hint in lowEnergyHints) {
    if (text.contains(hint)) score -= 0.07;
  }

  final exclamations = '!'.allMatches(text).length;
  if (exclamations > 0) score += (exclamations * 0.02).clamp(0, 0.08);
  if (text.contains('feat.') || text.contains(' ft ')) score += 0.03;

  return score.clamp(0.78, 1.32);
}

class _AutoScrollText extends StatefulWidget {
  final String text;
  final TextStyle style;

  const _AutoScrollText({required this.text, required this.style});

  @override
  State<_AutoScrollText> createState() => _AutoScrollTextState();
}

class _AutoScrollTextState extends State<_AutoScrollText>
    with TickerProviderStateMixin {
  AnimationController? _scrollController;
  AnimationController? _fadeController;
  double _overflow = 0;
  String _lastText = '';
  Duration _scrollDuration = const Duration(milliseconds: 4200);
  double _travel = 0;
  int _cycleEpoch = 0;
  bool _cycleRunning = false;

  @override
  void dispose() {
    _cycleEpoch++;
    _scrollController?.dispose();
    _fadeController?.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant _AutoScrollText oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.text != widget.text) {
      _lastText = '';
      _restartCycle();
    }
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxWidth = constraints.maxWidth;
        final painter = TextPainter(
          text: TextSpan(text: widget.text, style: widget.style),
          maxLines: 1,
          textDirection: Directionality.of(context),
        )..layout(minWidth: 0, maxWidth: double.infinity);

        final textWidth = painter.width;
        final textHeight = painter.height;
        _overflow = (textWidth - maxWidth).clamp(0.0, double.infinity);
        if (_overflow <= 1) {
          _cycleEpoch++;
          _cycleRunning = false;
          _scrollController?.stop();
          _fadeController?.stop();
          _scrollController?.value = 0;
          _fadeController?.value = 1;
          return Text(
            widget.text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.left,
            style: widget.style,
          );
        }

        _ensureControllers();

        final ms = ((_overflow / 26) * 1000).clamp(2200, 9000).round();
        final duration = Duration(milliseconds: ms);
        _travel = _overflow + 36.0;
        if (_scrollDuration != duration) {
          _scrollDuration = duration;
          _restartCycle();
        }
        if (_lastText != widget.text) {
          _lastText = widget.text;
          _restartCycle();
        }

        _startCycleIfNeeded();
        const gap = 36.0;
        return ClipRect(
          child: AnimatedBuilder(
            animation: Listenable.merge([_scrollController!, _fadeController!]),
            builder: (context, _) {
              final eased = Curves.easeInOutCubic.transform(
                _scrollController!.value,
              );
              return Transform.translate(
                offset: Offset(-_travel * eased, 0),
                child: SizedBox(
                  height: textHeight,
                  child: Opacity(
                    opacity: _fadeController!.value,
                    child: OverflowBox(
                      minHeight: textHeight,
                      maxHeight: textHeight,
                      maxWidth: double.infinity,
                      alignment: Alignment.centerLeft,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: textWidth,
                            child: Text(
                              widget.text,
                              maxLines: 1,
                              softWrap: false,
                              style: widget.style,
                              textAlign: TextAlign.left,
                            ),
                          ),
                          const SizedBox(width: gap),
                          SizedBox(
                            width: textWidth,
                            child: Text(
                              widget.text,
                              maxLines: 1,
                              softWrap: false,
                              style: widget.style,
                              textAlign: TextAlign.left,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  void _ensureControllers() {
    _scrollController ??= AnimationController(
      vsync: this,
      duration: _scrollDuration,
      value: 0,
    );
    _fadeController ??= AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
      value: 1,
    );
  }

  void _restartCycle() {
    _cycleEpoch++;
    _cycleRunning = false;
    _scrollController?.stop();
    _fadeController?.stop();
    _scrollController?.value = 0;
    _fadeController?.value = 1;
  }

  void _startCycleIfNeeded() {
    if (_cycleRunning) return;
    _cycleRunning = true;
    final token = _cycleEpoch;
    unawaited(_runCycle(token));
  }

  Future<void> _runCycle(int token) async {
    var firstPass = true;
    while (mounted && token == _cycleEpoch && _overflow > 1) {
      if (!firstPass) {
        await Future<void>.delayed(const Duration(seconds: 15));
        if (!mounted || token != _cycleEpoch || _overflow <= 1) return;
      }
      firstPass = false;

      try {
        await _scrollController!.animateTo(
          1,
          duration: _scrollDuration,
          curve: Curves.easeInOutCubic,
        );
      } catch (_) {
        return;
      }
      if (!mounted || token != _cycleEpoch) return;

      try {
        await _fadeController!.animateTo(
          0,
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
        );
      } catch (_) {
        return;
      }
      if (!mounted || token != _cycleEpoch) return;

      _scrollController!.value = 0;

      try {
        await _fadeController!.animateTo(
          1,
          duration: const Duration(milliseconds: 320),
          curve: Curves.easeInCubic,
        );
      } catch (_) {
        return;
      }
    }
    if (token == _cycleEpoch) {
      _cycleRunning = false;
    }
  }
}

class _CompactNowPlayingHeader extends StatelessWidget {
  final VideoPlayerManager manager;
  final bool preferStaticArtwork;
  final VoidCallback onArtworkTap;
  final VoidCallback onArtistTap;
  final bool canAddToPlaylist;
  final VoidCallback onAddToPlaylist;
  final VoidCallback onAddToFavorites;

  const _CompactNowPlayingHeader({
    super.key,
    required this.manager,
    required this.preferStaticArtwork,
    required this.onArtworkTap,
    required this.onArtistTap,
    required this.canAddToPlaylist,
    required this.onAddToPlaylist,
    required this.onAddToFavorites,
  });

  @override
  Widget build(BuildContext context) {
    final transitionDx = manager.trackTransitionDirection < 0 ? -0.04 : 0.04;
    final motionEnergy = _estimateTrackMotionEnergy(
      manager.trackTitle,
      manager.trackArtist,
    );
    return ClipRRect(
      key: key,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            _ArtworkSwipeNavigator(
              manager: manager,
              onTap: onArtworkTap,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 220),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: (child, animation) {
                  return FadeTransition(opacity: animation, child: child);
                },
                child: _ArtworkImage(
                  key: ValueKey(
                    'compact-artwork-${manager.trackThumbnailUrl ?? ''}',
                  ),
                  url: manager.trackThumbnailUrl,
                  size: 62,
                  animated: !preferStaticArtwork,
                  isPlaying: manager.isPlaying,
                  motionEnergy: motionEnergy,
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 280),
                reverseDuration: const Duration(milliseconds: 220),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                transitionBuilder: (child, animation) => FadeTransition(
                  opacity: animation,
                  child: SlideTransition(
                    position: Tween<Offset>(
                      begin: Offset(transitionDx, 0),
                      end: Offset.zero,
                    ).animate(animation),
                    child: child,
                  ),
                ),
                child: Column(
                  key: ValueKey('compact_meta_${manager.currentVideoId ?? ''}'),
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      manager.trackTitle ?? 'Cargando canción...',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            fontSize: 19,
                            fontWeight: FontWeight.w700,
                            color: CupertinoColors.white,
                          ),
                    ),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Expanded(
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: onArtistTap,
                            child: Text(
                              manager.trackArtist ?? 'Artista desconocido',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: CupertinoTheme.of(context)
                                  .textTheme
                                  .textStyle
                                  .copyWith(
                                    fontSize: 14,
                                    color: CupertinoColors.white.withValues(
                                      alpha: 0.78,
                                    ),
                                  ),
                            ),
                          ),
                        ),
                        if (canAddToPlaylist) ...[
                          const SizedBox(width: 8),
                          _InlineArtistActionButton(
                            icon: CupertinoIcons.add,
                            onPressed: onAddToPlaylist,
                            compact: true,
                          ),
                          const SizedBox(width: 6),
                          _InlineArtistActionButton(
                            icon: CupertinoIcons.star_fill,
                            onPressed: onAddToFavorites,
                            compact: true,
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _InlineArtistActionButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;
  final bool compact;

  const _InlineArtistActionButton({
    required this.icon,
    required this.onPressed,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final size = compact ? 26.0 : 30.0;
    final iconSize = compact ? 14.0 : 16.0;
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size(size, size),
      onPressed: onPressed,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.transparent,
          shape: BoxShape.circle,
          border: Border.all(
            color: CupertinoColors.white.withValues(alpha: 0.24),
            width: 0.6,
          ),
        ),
        child: Icon(
          icon,
          size: iconSize,
          color: CupertinoColors.white,
        ),
      ),
    );
  }
}

class _IosTopToast extends StatefulWidget {
  final String message;
  final IconData icon;
  final bool isDark;

  const _IosTopToast({
    required this.message,
    required this.icon,
    required this.isDark,
  });

  @override
  State<_IosTopToast> createState() => _IosTopToastState();
}

class _IosTopToastState extends State<_IosTopToast>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  late final Animation<Offset> _slide;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
      reverseDuration: const Duration(milliseconds: 240),
    );
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _slide = Tween<Offset>(
      begin: const Offset(0, -0.06),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic));
    _controller.forward();
    Timer(const Duration(milliseconds: 1400), () {
      if (mounted) {
        _controller.reverse();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _fade,
      child: SlideTransition(
        position: _slide,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: _PerformanceBackdrop(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              constraints: const BoxConstraints(maxWidth: 330),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: widget.isDark
                    ? const Color(0xFF0D0F13).withValues(alpha: 0.84)
                    : Colors.white.withValues(alpha: 0.86),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: widget.isDark
                      ? Colors.white.withValues(alpha: 0.14)
                      : Colors.black.withValues(alpha: 0.08),
                  width: 0.6,
                ),
              ),
              child: Text(
                widget.message,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: '.SF Pro Text',
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  color: widget.isDark ? Colors.white : Colors.black,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TopGlassIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;

  const _TopGlassIconButton({required this.icon, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: EdgeInsets.zero,
      onPressed: onPressed,
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: Colors.transparent,
          shape: BoxShape.circle,
          border: Border.all(
            color: CupertinoColors.white.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
        child: Icon(
          icon,
          size: 18,
          color: CupertinoColors.white,
        ),
      ),
    );
  }
}

class _GlassControlsGroup extends StatelessWidget {
  final Widget child;

  const _GlassControlsGroup({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(36),
        border: Border.all(
          color: CupertinoColors.white.withValues(alpha: 0.24),
          width: 0.6,
        ),
      ),
      child: child,
    );
  }
}

class _IosLoadingControls extends StatelessWidget {
  const _IosLoadingControls();

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: _PerformanceBackdrop(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          decoration: BoxDecoration(
            color: CupertinoColors.systemGrey6
                .resolveFrom(context)
                .withValues(alpha: 0.48),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: CupertinoColors.white.withValues(alpha: 0.22),
              width: 0.5,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CupertinoActivityIndicator(radius: 9),
              const SizedBox(width: 10),
              Text(
                'Cargando...',
                style: CupertinoTheme.of(context).textTheme.textStyle.copyWith(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: CupertinoColors.secondaryLabel.resolveFrom(context),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _QueueSection extends StatefulWidget {
  const _QueueSection();

  @override
  State<_QueueSection> createState() => _QueueSectionState();
}

class _QueueSectionState extends State<_QueueSection> {
  static const double _reorderHapticStepPx = 66;
  bool _isTrackingReorderDrag = false;
  double _dragAccumulatorPx = 0;
  VideoPlayerManager? _manager;

  VideoPlayerManager get manager => _manager!;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _manager ??= context.read<VideoPlayerManager>();
  }

  void _onReorderStart(int _) {
    _isTrackingReorderDrag = true;
    _dragAccumulatorPx = 0;
    unawaited(HapticFeedback.mediumImpact());
  }

  void _onReorderEnd(int _) {
    _isTrackingReorderDrag = false;
    _dragAccumulatorPx = 0;
    unawaited(HapticFeedback.selectionClick());
  }

  void _onReorder(int oldIndex, int newIndex) {
    manager.reorderPlaybackQueue(oldIndex, newIndex);
    unawaited(HapticFeedback.lightImpact());
  }

  void _onDragPointerMove(PointerMoveEvent event) {
    if (!_isTrackingReorderDrag) return;
    _dragAccumulatorPx += event.delta.dy;
    while (_dragAccumulatorPx.abs() >= _reorderHapticStepPx) {
      _dragAccumulatorPx += _dragAccumulatorPx > 0
          ? -_reorderHapticStepPx
          : _reorderHapticStepPx;
      unawaited(HapticFeedback.selectionClick());
    }
  }

  @override
  Widget build(BuildContext context) {
    final queueState = context
        .select<
          VideoPlayerManager,
          ({
            bool isQueueLoading,
            String queueTitle,
            List<PlaybackQueueItem> queue,
          })
        >(
          (manager) => (
            isQueueLoading: manager.isQueueLoading,
            queueTitle: manager.queueTitle,
            queue: manager.playbackQueue,
          ),
        );
    final queue = queueState.queue;
    final textTheme = CupertinoTheme.of(context).textTheme;
    final titleColor = CupertinoColors.label.resolveFrom(context);
    final subtitleColor = CupertinoColors.secondaryLabel.resolveFrom(context);

    if (queueState.isQueueLoading) {
      return _QueueShell(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Cola de reproducción',
              style: textTheme.textStyle.copyWith(
                fontSize: 18,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 10),
            const _IosLoadingControls(),
          ],
        ),
      );
    }

    if (queue.isEmpty) {
      return const SizedBox.shrink();
    }

    return _QueueShell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'A continuación',
                  style: textTheme.textStyle.copyWith(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: titleColor,
                  ),
                ),
              ),
              CupertinoButton(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 0),
                minimumSize: const Size(34, 34),
                onPressed: queue.length > 1
                    ? () {
                        unawaited(HapticFeedback.lightImpact());
                        manager.shufflePlaybackQueue();
                      }
                    : null,
                child: Icon(
                  CupertinoIcons.shuffle,
                  size: 18,
                  color: queue.length > 1
                      ? titleColor
                      : CupertinoColors.tertiaryLabel.resolveFrom(context),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            '${queueState.queueTitle} · ${queue.length} canciones',
            style: textTheme.textStyle.copyWith(
              fontSize: 13,
              color: subtitleColor,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Mantén y arrastra para reordenar.',
            style: textTheme.textStyle.copyWith(
              fontSize: 12,
              color: subtitleColor.withValues(alpha: 0.88),
            ),
          ),
          const SizedBox(height: 28),
          ReorderableListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: queue.length,
            buildDefaultDragHandles: false,
            proxyDecorator: (child, index, animation) {
              return FadeTransition(
                opacity: Tween<double>(begin: 0.96, end: 1).animate(animation),
                child: ScaleTransition(
                  scale: Tween<double>(begin: 0.992, end: 1).animate(animation),
                  child: child,
                ),
              );
            },
            onReorderStart: _onReorderStart,
            onReorderEnd: _onReorderEnd,
            onReorder: _onReorder,
            itemBuilder: (context, index) {
              final item = queue[index];
              return _QueueRow(
                key: ObjectKey(item),
                item: item,
                manager: manager,
                index: index,
                onDragPointerMove: _onDragPointerMove,
              );
            },
          ),
        ],
      ),
    );
  }
}

class _QueueRow extends StatelessWidget {
  final PlaybackQueueItem item;
  final VideoPlayerManager manager;
  final int index;
  final ValueChanged<PointerMoveEvent>? onDragPointerMove;

  const _QueueRow({
    super.key,
    required this.item,
    required this.manager,
    required this.index,
    this.onDragPointerMove,
  });

  @override
  Widget build(BuildContext context) {
    final titleColor = CupertinoColors.white.withValues(alpha: 0.96);
    final subtitleColor = CupertinoColors.white.withValues(alpha: 0.70);
    final rowBorder = CupertinoColors.white.withValues(alpha: 0.18);
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            color: Colors.transparent,
            border: Border.all(color: rowBorder, width: 0.65),
            borderRadius: BorderRadius.circular(16),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () {
              unawaited(HapticFeedback.selectionClick());
              unawaited(manager.playQueueItem(item));
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Row(
                children: [
                  Listener(
                    onPointerMove: onDragPointerMove,
                    child: ReorderableDelayedDragStartListener(
                      index: index,
                      child: Padding(
                        padding: const EdgeInsets.only(right: 8, left: 2),
                        child: Container(
                          width: 24,
                          height: 24,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: CupertinoColors.white.withValues(
                              alpha: 0.08,
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Icon(
                            CupertinoIcons.line_horizontal_3,
                            size: 15,
                            color: subtitleColor,
                          ),
                        ),
                      ),
                    ),
                  ),
                  item.thumbnailUrl.startsWith('/')
                      ? SquareThumbnail.file(
                          filePath: item.thumbnailUrl,
                          size: 56,
                          borderRadius: 10,
                          zoom: 1,
                          fallback: Container(
                            width: 56,
                            height: 56,
                            color: Theme.of(
                              context,
                            ).colorScheme.surfaceContainerHighest,
                            alignment: Alignment.center,
                            child: const Icon(Icons.music_note_rounded),
                          ),
                        )
                      : SquareThumbnail.network(
                          imageUrl: item.thumbnailUrl,
                          size: 56,
                          borderRadius: 10,
                          zoom: 1,
                          fallback: Container(
                            width: 56,
                            height: 56,
                            color: Theme.of(
                              context,
                            ).colorScheme.surfaceContainerHighest,
                            alignment: Alignment.center,
                            child: const Icon(Icons.music_note_rounded),
                          ),
                        ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        if (index == 0)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 3),
                            child: Text(
                              'Siguiente',
                              style: CupertinoTheme.of(context)
                                  .textTheme
                                  .textStyle
                                  .copyWith(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                    color: CupertinoColors.systemPink
                                        .resolveFrom(context),
                                  ),
                            ),
                          ),
                        Text(
                          item.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: CupertinoTheme.of(context).textTheme.textStyle
                              .copyWith(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: titleColor,
                              ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          item.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: CupertinoTheme.of(context).textTheme.textStyle
                              .copyWith(fontSize: 12, color: subtitleColor),
                        ),
                      ],
                    ),
                  ),
                  CupertinoButton(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 4,
                      vertical: 0,
                    ),
                    minimumSize: const Size(28, 28),
                    onPressed: () {
                      unawaited(HapticFeedback.lightImpact());
                      unawaited(_showActionsMenu(context));
                    },
                    child: Icon(
                      CupertinoIcons.ellipsis,
                      size: 18,
                      color: titleColor,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showActionsMenu(BuildContext context) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(26),
              child: _PerformanceBackdrop(
                filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
                child: Container(
                  decoration: BoxDecoration(
                    color: CupertinoColors.systemGrey6
                        .resolveFrom(sheetContext)
                        .withValues(alpha: 0.82),
                    borderRadius: BorderRadius.circular(26),
                    border: Border.all(
                      color: CupertinoColors.white.withValues(alpha: 0.24),
                      width: 0.7,
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SizedBox(height: 8),
                      Container(
                        width: 42,
                        height: 4,
                        decoration: BoxDecoration(
                          color: CupertinoColors.systemGrey3
                              .resolveFrom(sheetContext)
                              .withValues(alpha: 0.75),
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                item.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: CupertinoTheme.of(sheetContext)
                                    .textTheme
                                    .navTitleTextStyle
                                    .copyWith(fontWeight: FontWeight.w700),
                              ),
                            ),
                            const SizedBox(width: 8),
                            CupertinoButton(
                              padding: EdgeInsets.zero,
                              minimumSize: const Size(34, 34),
                              onPressed: () => Navigator.of(sheetContext).pop(),
                              child: Icon(
                                CupertinoIcons.xmark_circle_fill,
                                size: 24,
                                color: CupertinoColors.secondaryLabel
                                    .resolveFrom(sheetContext),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(10, 0, 10, 14),
                        child: Column(
                          children: [
                            _QueueGlassSheetActionRow(
                              icon: CupertinoIcons.play_fill,
                              label: 'Reproducir ahora',
                              onTap: () =>
                                  Navigator.of(sheetContext).pop('play'),
                            ),
                            const SizedBox(height: 8),
                            _QueueGlassSheetActionRow(
                              icon: CupertinoIcons.star_fill,
                              label: 'Añadir a Favoritos',
                              onTap: () =>
                                  Navigator.of(sheetContext).pop('favorites'),
                            ),
                            const SizedBox(height: 8),
                            _QueueGlassSheetActionRow(
                              icon: CupertinoIcons.music_note_list,
                              label: 'Añadir a playlist',
                              onTap: () =>
                                  Navigator.of(sheetContext).pop('playlist'),
                            ),
                            const SizedBox(height: 8),
                            _QueueGlassSheetActionRow(
                              icon: CupertinoIcons.minus_circle_fill,
                              label: 'Quitar de la cola',
                              isDestructive: true,
                              onTap: () =>
                                  Navigator.of(sheetContext).pop('remove'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
    if (!context.mounted || action == null) return;
    unawaited(HapticFeedback.selectionClick());
    switch (action) {
      case 'play':
        await manager.playQueueItem(item);
        return;
      case 'favorites':
        await _addItemToFavorites(context);
        return;
      case 'playlist':
        await _addItemToPlaylist(context);
        return;
      case 'remove':
        unawaited(HapticFeedback.mediumImpact());
        manager.removeQueueItem(item);
        _showQueueSnackBar(context, 'Quitada de la cola');
        return;
    }
  }

  Future<void> _addItemToFavorites(BuildContext context) async {
    final playlistService = context.read<PlaylistService>();
    final downloadService = context.read<DownloadService>();
    final videoManager = context.read<VideoPlayerManager>();
    final playlists = await playlistService.getPlaylists();
    final favorites = playlists.firstWhere(
      (playlist) => PlaylistService.isFavoritesPlaylistName(playlist.name),
      orElse: () =>
          app_models.Playlist(name: PlaylistService.favoritesPlaylistName),
    );
    final track = _toVideoHistory();
    await playlistService.addVideoToPlaylist(favorites.name, track);
    if (!item.isLocal) {
      await downloadService.autoDownloadIfEnabledUsingClone(
        favorites.name,
        track,
        videoManager: videoManager,
      );
    }
    if (!context.mounted) return;
    _showQueueSnackBar(context, 'Añadida a Favoritos');
  }

  Future<void> _addItemToPlaylist(BuildContext context) async {
    final playlistService = context.read<PlaylistService>();
    final downloadService = context.read<DownloadService>();
    final videoManager = context.read<VideoPlayerManager>();
    final playlists = await playlistService.getPlaylists();
    if (!context.mounted) return;
    if (playlists.isEmpty) {
      _showQueueSnackBar(context, 'No hay playlists disponibles.');
      return;
    }
    final selectedName = await showGlassPlaylistPickerSheet(
      context: context,
      playlists: playlists,
      subtitle: item.title,
    );
    if (!context.mounted || selectedName == null || selectedName.isEmpty) {
      return;
    }
    final track = _toVideoHistory();
    await playlistService.addVideoToPlaylist(selectedName, track);
    if (!item.isLocal) {
      await downloadService.autoDownloadIfEnabledUsingClone(
        selectedName,
        track,
        videoManager: videoManager,
      );
    }
    if (!context.mounted) return;
    _showQueueSnackBar(context, 'Añadida a $selectedName');
  }

  VideoHistory _toVideoHistory() {
    return VideoHistory(
      videoId: item.videoId,
      title: item.title,
      thumbnailUrl: item.thumbnailUrl,
      channelTitle: cleanArtistName(item.artist),
      watchedAt: DateTime.now(),
    );
  }

  void _showQueueSnackBar(BuildContext context, String message) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        elevation: 0,
        backgroundColor: Colors.transparent,
        margin: EdgeInsets.only(
          left: 14,
          right: 14,
          bottom: MediaQuery.of(context).padding.bottom + 102,
        ),
        content: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: _PerformanceBackdrop(
            filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: isDark
                    ? const Color(0xFF0D0F13).withValues(alpha: 0.84)
                    : Colors.white.withValues(alpha: 0.86),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isDark
                      ? Colors.white.withValues(alpha: 0.14)
                      : Colors.black.withValues(alpha: 0.08),
                  width: 0.6,
                ),
              ),
              child: Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontFamily: '.SF Pro Text',
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                  color: isDark ? Colors.white : Colors.black,
                  decoration: TextDecoration.none,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _QueueShell extends StatelessWidget {
  final Widget child;

  const _QueueShell({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      decoration: BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: CupertinoColors.white.withValues(alpha: 0.22),
          width: 0.75,
        ),
      ),
      child: child,
    );
  }
}

class _QueueGlassSheetActionRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDestructive;

  const _QueueGlassSheetActionRow({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final destructiveColor = CupertinoColors.destructiveRed.resolveFrom(
      context,
    );
    final iconColor = isDestructive
        ? destructiveColor
        : CupertinoColors.label.resolveFrom(context);
    final textColor = isDestructive
        ? destructiveColor
        : CupertinoColors.label.resolveFrom(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: _PerformanceBackdrop(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Material(
          color: Colors.white.withValues(alpha: 0.05),
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () {
              unawaited(HapticFeedback.selectionClick());
              onTap();
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: CupertinoColors.white.withValues(alpha: 0.18),
                  width: 0.6,
                ),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withValues(alpha: 0.08),
                    Colors.white.withValues(alpha: 0.02),
                  ],
                ),
              ),
              child: Row(
                children: [
                  Icon(icon, size: 18, color: iconColor),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      label,
                      style: TextStyle(
                        fontFamily: '.SF Pro Text',
                        fontWeight: FontWeight.w700,
                        fontSize: 15,
                        color: textColor,
                      ),
                    ),
                  ),
                  Icon(
                    CupertinoIcons.chevron_right,
                    size: 17,
                    color: CupertinoColors.secondaryLabel.resolveFrom(context),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NativeControlButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;

  const _NativeControlButton({required this.icon, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: EdgeInsets.zero,
      onPressed: onPressed,
      child: Container(
        width: 40,
        height: 40,
        alignment: Alignment.center,
        child: Icon(
          icon,
          size: 44,
          color: CupertinoColors.white,
        ),
      ),
    );
  }
}

class _NativePrimaryPlayButton extends StatelessWidget {
  final bool isPlaying;
  final VoidCallback onPressed;

  const _NativePrimaryPlayButton({
    required this.isPlaying,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size.zero,
      onPressed: onPressed,
      child: TweenAnimationBuilder<double>(
        tween: Tween<double>(begin: 0, end: isPlaying ? 1 : 0),
        duration: const Duration(milliseconds: 280),
        curve: Curves.easeInOutCubic,
        builder: (context, progress, _) {
          final playOpacity = 1 - Curves.easeOutCubic.transform(progress);
          final pauseOpacity = Curves.easeOutCubic.transform(progress);
          final playScale = 1 - (0.18 * progress);
          final pauseScale = 0.84 + (0.16 * progress);
          final playDx = -4.0 * progress;
          final pauseDx = 4.0 * (1 - progress);

          return SizedBox(
            width: 60,
            height: 60,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Transform.translate(
                  offset: Offset(playDx, 0),
                  child: Transform.scale(
                    scale: playScale,
                    child: Opacity(
                      opacity: playOpacity.clamp(0.0, 1.0),
                      child: const Icon(
                        CupertinoIcons.play_fill,
                        size: 55,
                        color: CupertinoColors.white,
                      ),
                    ),
                  ),
                ),
                Transform.translate(
                  offset: Offset(pauseDx, 0),
                  child: Transform.scale(
                    scale: pauseScale,
                    child: Opacity(
                      opacity: pauseOpacity.clamp(0.0, 1.0),
                      child: const Icon(
                        CupertinoIcons.pause_fill,
                        size: 53,
                        color: CupertinoColors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _ProgressSection extends StatelessWidget {
  const _ProgressSection();

  @override
  Widget build(BuildContext context) {
    final manager = context.read<VideoPlayerManager>();
    final progressState = context
        .select<
          VideoPlayerManager,
          ({Duration duration, Duration position, Duration bufferedPosition})
        >(
          (manager) => (
            duration: manager.trackDuration,
            position: manager.position,
            bufferedPosition: manager.bufferedPosition,
          ),
        );
    final totalMs = progressState.duration.inMilliseconds;
    final safeTotal = math.max(
      1,
      math.max(
        totalMs,
        math.max(
          progressState.position.inMilliseconds,
          progressState.bufferedPosition.inMilliseconds,
        ),
      ),
    );
    final positionMs = progressState.position.inMilliseconds.clamp(
      0,
      safeTotal,
    );
    final bufferedMs = progressState.bufferedPosition.inMilliseconds.clamp(
      positionMs,
      safeTotal,
    );
    final playedRatio = positionMs / safeTotal;
    final bufferedRatio = bufferedMs / safeTotal;

    return Column(
      children: [
        Align(
          alignment: Alignment.center,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 360),
            child: Column(
              children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final maxWidth = constraints.maxWidth;

                    void seekByDx(double localDx) {
                      if (safeTotal <= 1) return;
                      final ratio = (localDx / maxWidth).clamp(0.0, 1.0);
                      manager.seekTo(
                        Duration(milliseconds: (safeTotal * ratio).round()),
                      );
                    }

                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTapDown: (details) =>
                          seekByDx(details.localPosition.dx),
                      onHorizontalDragUpdate: (details) =>
                          seekByDx(details.localPosition.dx),
                      child: SizedBox(
                        height: 28,
                        child: Stack(
                          alignment: Alignment.centerLeft,
                          children: [
                            Container(
                              height: 7,
                              decoration: BoxDecoration(
                                color: CupertinoColors.systemGrey4
                                    .resolveFrom(context)
                                    .withValues(alpha: 0.52),
                                borderRadius: BorderRadius.circular(999),
                              ),
                            ),
                            FractionallySizedBox(
                              widthFactor: bufferedRatio,
                              child: Container(
                                height: 7,
                                decoration: BoxDecoration(
                                  color: CupertinoColors.systemGrey2
                                      .resolveFrom(context)
                                      .withValues(alpha: 0.62),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              ),
                            ),
                            FractionallySizedBox(
                              widthFactor: playedRatio,
                              child: Container(
                                height: 7,
                                decoration: BoxDecoration(
                                  color: CupertinoColors.white.withValues(
                                    alpha: 0.98,
                                  ),
                                  borderRadius: BorderRadius.circular(999),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _formatDuration(progressState.position),
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            fontSize: 13,
                            color: CupertinoColors.white.withValues(
                              alpha: 0.90,
                            ),
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                    ),
                    Text(
                      _formatDuration(Duration(milliseconds: safeTotal)),
                      style: CupertinoTheme.of(context).textTheme.textStyle
                          .copyWith(
                            fontSize: 13,
                            color: CupertinoColors.white.withValues(
                              alpha: 0.90,
                            ),
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = duration.inSeconds.remainder(60).toString().padLeft(2, '0');
    if (hours > 0) {
      return '$hours:$minutes:$seconds';
    }
    return '${duration.inMinutes}:$seconds';
  }
}

class _SystemVolumeSlider extends StatefulWidget {
  const _SystemVolumeSlider();

  @override
  State<_SystemVolumeSlider> createState() => _SystemVolumeSliderState();
}

class _SystemVolumeSliderState extends State<_SystemVolumeSlider> {
  double _volume = 0.5;
  bool _isLoaded = false;

  @override
  void initState() {
    super.initState();
    unawaited(_loadVolume());
  }

  Future<void> _loadVolume() async {
    try {
      final raw = await _systemVolumeChannel.invokeMethod<double>(
        'getSystemVolume',
      );
      if (!mounted || raw == null) return;
      setState(() {
        _volume = raw.clamp(0.0, 1.0);
        _isLoaded = true;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoaded = true;
      });
    }
  }

  Future<void> _setVolume(double value) async {
    final clamped = value.clamp(0.0, 1.0);
    setState(() {
      _volume = clamped;
    });
    try {
      await _systemVolumeChannel.invokeMethod<void>('setSystemVolume', {
        'value': clamped,
      });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!_isLoaded) {
      return const SizedBox(height: 28);
    }

    return Row(
      children: [
        Icon(
          CupertinoIcons.speaker_fill,
          size: 18,
          color: CupertinoColors.white.withValues(alpha: 0.90),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final maxWidth = constraints.maxWidth;

              void updateByDx(double localDx) {
                final ratio = (localDx / maxWidth).clamp(0.0, 1.0);
                unawaited(_setVolume(ratio));
              }

              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTapDown: (details) => updateByDx(details.localPosition.dx),
                onHorizontalDragUpdate: (details) =>
                    updateByDx(details.localPosition.dx),
                child: SizedBox(
                  height: 28,
                  child: Stack(
                    alignment: Alignment.centerLeft,
                    children: [
                      Container(
                        height: 7,
                        decoration: BoxDecoration(
                          color: CupertinoColors.systemGrey4
                              .resolveFrom(context)
                              .withValues(alpha: 0.52),
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                      FractionallySizedBox(
                        widthFactor: _volume,
                        child: Container(
                          height: 7,
                          decoration: BoxDecoration(
                            color: CupertinoColors.white.withValues(
                              alpha: 0.98,
                            ),
                            borderRadius: BorderRadius.circular(999),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(width: 12),
        Icon(
          CupertinoIcons.speaker_3_fill,
          size: 18,
          color: CupertinoColors.white.withValues(alpha: 0.90),
        ),
      ],
    );
  }
}

class _LyricsPanel extends StatefulWidget {
  final VideoPlayerManager manager;
  final bool immersiveMode;
  final VoidCallback? onInteraction;
  final VoidCallback? onRevealRequest;
  final VoidCallback? onImmersiveRequest;

  const _LyricsPanel({
    required this.manager,
    this.immersiveMode = false,
    this.onInteraction,
    this.onRevealRequest,
    this.onImmersiveRequest,
  });

  @override
  State<_LyricsPanel> createState() => _LyricsPanelState();
}

class _LyricsPanelState extends State<_LyricsPanel> {
  static const int _lyricsAccentCacheMaxEntries = 120;
  static final Map<String, Color> _lyricsAccentCache = <String, Color>{};
  static final Map<String, Future<Color?>> _lyricsAccentRequests =
      <String, Future<Color?>>{};
  final ScrollController _syncedScrollController = ScrollController();
  final Map<int, BuildContext> _syncedLineContexts = <int, BuildContext>{};
  int _lastSyncedIndex = -1;
  int _lastSyncedLength = 0;
  String? _lastVideoId;
  DateTime _lastFollowScrollAt = DateTime.fromMillisecondsSinceEpoch(0);
  String? _alignedTrackKey;
  List<LiveLyricWordTiming> _alignedWords = const [];
  static const Duration _lyricsAutoFollowResumeDelay = Duration(seconds: 3);
  static const double _revealPullThreshold = 28;
  static const double _immersivePullThreshold = 15;
  double _revealPullAccumulated = 0;
  bool _didRequestRevealInGesture = false;
  double _immersivePullAccumulated = 0;
  bool _didRequestImmersiveInGesture = false;
  Timer? _resumeAutoFollowTimer;
  Timer? _lyricsVisualTicker;
  bool _autoFollowCurrentLyric = true;
  int _latestResolvedCurrentIndex = -1;
  Duration _visualLyricsPosition = Duration.zero;
  DateTime _visualLyricsWallClock = DateTime.fromMillisecondsSinceEpoch(0);
  Duration _lastVisualClockManagerPosition = Duration.zero;
  static const Duration _lyricsVisualTickIntervalNormal = Duration(
    milliseconds: 110,
  );
  static const Duration _lyricsVisualTickIntervalLowPower = Duration(
    milliseconds: 190,
  );
  Duration? _activeLyricsVisualTickInterval;
  Color? _lyricsAccentColor;
  String? _lyricsAccentSource;

  Color _normalizedLyricsAccent(Color color) {
    final luminance = color.computeLuminance();
    if (luminance >= 0.44) return color;

    final hsl = HSLColor.fromColor(color);
    final boostedLightness = (hsl.lightness + (0.44 - luminance) * 0.95).clamp(
      0.56,
      0.78,
    );
    final boostedSaturation = (hsl.saturation * 0.90 + 0.08).clamp(0.20, 0.88);
    return hsl
        .withLightness(boostedLightness)
        .withSaturation(boostedSaturation)
        .toColor();
  }

  void _syncLyricsAccentColor(VideoPlayerManager manager) {
    final raw = manager.trackThumbnailUrl?.trim() ?? '';
    if (raw.isEmpty || raw == _lyricsAccentSource) return;
    _lyricsAccentSource = raw;

    final cached = _lyricsAccentCache[raw];
    if (cached != null) {
      _lyricsAccentColor = _normalizedLyricsAccent(cached);
      return;
    }

    final request =
        _lyricsAccentRequests[raw] ??
        () async {
          try {
            final ImageProvider provider = raw.startsWith('/')
                ? FileImage(File(raw))
                : NetworkImage(raw);
            final palette = await PaletteGenerator.fromImageProvider(
              provider,
              size: const Size(84, 84),
              maximumColorCount: 14,
            );
            return palette.vibrantColor?.color ??
                palette.lightVibrantColor?.color ??
                palette.dominantColor?.color ??
                palette.mutedColor?.color;
          } catch (_) {
            return null;
          }
        }();
    _lyricsAccentRequests[raw] = request;

    unawaited(
      request
          .then((color) {
            if (!mounted || _lyricsAccentSource != raw || color == null) return;
            final normalized = _normalizedLyricsAccent(color);
            _lyricsAccentCache[raw] = normalized;
            while (_lyricsAccentCache.length > _lyricsAccentCacheMaxEntries) {
              _lyricsAccentCache.remove(_lyricsAccentCache.keys.first);
            }
            setState(() {
              _lyricsAccentColor = normalized;
            });
          })
          .whenComplete(() {
            if (identical(_lyricsAccentRequests[raw], request)) {
              _lyricsAccentRequests.remove(raw);
            }
          }),
    );
  }

  void _pauseAutoFollowForManualScroll() {
    _resumeAutoFollowTimer?.cancel();
    if (_autoFollowCurrentLyric) {
      if (mounted) {
        setState(() {
          _autoFollowCurrentLyric = false;
        });
      } else {
        _autoFollowCurrentLyric = false;
      }
    }
    _resumeAutoFollowTimer = Timer(_lyricsAutoFollowResumeDelay, () {
      if (!mounted) return;
      if (!_autoFollowCurrentLyric) {
        setState(() {
          _autoFollowCurrentLyric = true;
        });
      }
      if (_latestResolvedCurrentIndex >= 0) {
        _scrollToCurrentLyric(_latestResolvedCurrentIndex, force: true);
      }
    });
  }

  Future<void> _seekToLyricLine({
    required int index,
    required Duration timestamp,
  }) async {
    final manager = widget.manager;
    final target = timestamp < Duration.zero ? Duration.zero : timestamp;
    _resumeAutoFollowTimer?.cancel();
    if (!_autoFollowCurrentLyric && mounted) {
      setState(() {
        _autoFollowCurrentLyric = true;
      });
    } else {
      _autoFollowCurrentLyric = true;
    }
    _latestResolvedCurrentIndex = index;
    _visualLyricsPosition = target;
    _visualLyricsWallClock = DateTime.now();
    _lastVisualClockManagerPosition = target;
    widget.onInteraction?.call();
    unawaited(HapticFeedback.selectionClick());
    await manager.seekTo(target);
    if (!mounted) return;
    _scrollToCurrentLyric(index, force: true);
  }

  bool _handleLyricsScrollNotification(ScrollNotification notification) {
    if (notification is ScrollStartNotification) {
      _revealPullAccumulated = 0;
      _didRequestRevealInGesture = false;
      _immersivePullAccumulated = 0;
      _didRequestImmersiveInGesture = false;
      if (notification.dragDetails != null) {
        _pauseAutoFollowForManualScroll();
      }
      widget.onInteraction?.call();
      return false;
    }

    if (notification is UserScrollNotification &&
        notification.direction != ScrollDirection.idle) {
      _pauseAutoFollowForManualScroll();
      widget.onInteraction?.call();
      return false;
    }

    if (notification is ScrollUpdateNotification) {
      final dragDy = notification.dragDetails?.delta.dy;
      if (dragDy != null) {
        _pauseAutoFollowForManualScroll();
        widget.onInteraction?.call();
        if (!widget.immersiveMode && !_didRequestImmersiveInGesture) {
          if (dragDy < 0) {
            _immersivePullAccumulated += -dragDy;
            if (_immersivePullAccumulated >= _immersivePullThreshold) {
              _didRequestImmersiveInGesture = true;
              _immersivePullAccumulated = 0;
              widget.onImmersiveRequest?.call();
            }
          } else {
            _immersivePullAccumulated = 0;
          }
        } else if (dragDy > 0) {
          _immersivePullAccumulated = 0;
        }
        if (widget.immersiveMode && !_didRequestRevealInGesture) {
          if (dragDy > 0) {
            _revealPullAccumulated += dragDy;
            if (_revealPullAccumulated >= _revealPullThreshold) {
              _didRequestRevealInGesture = true;
              _revealPullAccumulated = 0;
              widget.onRevealRequest?.call();
            }
          } else {
            _revealPullAccumulated = 0;
          }
        } else if (dragDy < 0) {
          _revealPullAccumulated = 0;
        }
      }
      return false;
    }

    if (notification is OverscrollNotification) {
      final dragDy = notification.dragDetails?.delta.dy;
      if (dragDy != null) {
        _pauseAutoFollowForManualScroll();
        widget.onInteraction?.call();
        if (!widget.immersiveMode && !_didRequestImmersiveInGesture) {
          if (dragDy < 0) {
            _immersivePullAccumulated += -dragDy;
            if (_immersivePullAccumulated >= _immersivePullThreshold) {
              _didRequestImmersiveInGesture = true;
              _immersivePullAccumulated = 0;
              widget.onImmersiveRequest?.call();
            }
          } else {
            _immersivePullAccumulated = 0;
          }
        } else if (dragDy > 0) {
          _immersivePullAccumulated = 0;
        }
        if (widget.immersiveMode && !_didRequestRevealInGesture) {
          if (dragDy > 0) {
            _revealPullAccumulated += dragDy;
            if (_revealPullAccumulated >= _revealPullThreshold) {
              _didRequestRevealInGesture = true;
              _revealPullAccumulated = 0;
              widget.onRevealRequest?.call();
            }
          } else {
            _revealPullAccumulated = 0;
          }
        } else if (dragDy < 0) {
          _revealPullAccumulated = 0;
        }
      }
      return false;
    }

    if (notification is ScrollEndNotification) {
      _revealPullAccumulated = 0;
      _didRequestRevealInGesture = false;
      _immersivePullAccumulated = 0;
      _didRequestImmersiveInGesture = false;
    }
    return false;
  }

  @override
  void dispose() {
    _lyricsVisualTicker?.cancel();
    _resumeAutoFollowTimer?.cancel();
    _syncedScrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final manager = widget.manager;
    final settings = context.watch<AppSettingsService?>();
    final liveLyricsEnabled = settings?.liveLyrics ?? true;
    const lyricsFontFamily = '.SF Pro Text';
    const inactiveLyricsColor = Color(0x8CFFFFFF);
    final isImmersive = widget.immersiveMode;
    final baseFontSize = isImmersive ? 22.0 : 20.0;
    final activeFontSize = isImmersive ? 28.0 : 26.0;
    _syncLyricsAccentColor(manager);
    final activeLyricsColor =
        _lyricsAccentColor ?? CupertinoColors.white;
    unawaited(
      _syncIosWordAlignment(
        manager: manager,
        liveLyricsEnabled: liveLyricsEnabled,
      ),
    );
    _syncVisualLyricsClock(
      manager: manager,
      liveLyricsEnabled: liveLyricsEnabled,
    );
    if (_lastVideoId != manager.currentVideoId) {
      _lastVideoId = manager.currentVideoId;
      _lastSyncedIndex = -1;
      _lastSyncedLength = 0;
      _syncedLineContexts.clear();
      _latestResolvedCurrentIndex = -1;
      _autoFollowCurrentLyric = true;
      _resumeAutoFollowTimer?.cancel();
      _visualLyricsPosition = manager.position;
      _visualLyricsWallClock = DateTime.now();
      _lastVisualClockManagerPosition = manager.position;
    }
    final textStyle = CupertinoTheme.of(context)
        .textTheme
        .navLargeTitleTextStyle
        .copyWith(
          fontFamily: lyricsFontFamily,
          fontSize: baseFontSize,
          height: 1.25,
          color: CupertinoColors.label.resolveFrom(context),
          fontWeight: FontWeight.w600,
        );

    Widget content;
    if (manager.isLyricsLoading) {
      _latestResolvedCurrentIndex = -1;
      content = const Padding(
        padding: EdgeInsets.symmetric(vertical: 28),
        child: Center(child: CupertinoActivityIndicator(radius: 11)),
      );
    } else if (manager.lyricsError != null) {
      _latestResolvedCurrentIndex = -1;
      content = Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          manager.lyricsError!,
          textAlign: TextAlign.left,
          style: textStyle.copyWith(
            color: CupertinoColors.secondaryLabel.resolveFrom(context),
          ),
        ),
      );
    } else if (manager.hasSyncedLyrics) {
      final syncedLyrics = List.of(manager.syncedLyrics);
      if (syncedLyrics.isEmpty) {
        _latestResolvedCurrentIndex = -1;
        content = Text(manager.lyricsText ?? '', style: textStyle);
      } else {
        final lyricsNow = _effectiveLyricsNow(manager);
        if (_lastSyncedLength != syncedLyrics.length) {
          _lastSyncedLength = syncedLyrics.length;
          _syncedLineContexts.clear();
        }
        final rawCurrentIndex = manager.currentSyncedLyricIndex;
        final currentIndex = _resolveDisplayedCurrentIndex(
          baseIndex: rawCurrentIndex.clamp(-1, syncedLyrics.length - 1),
          lyrics: syncedLyrics,
          now: lyricsNow,
          trackDuration: manager.trackDuration,
          liveLyricsEnabled: liveLyricsEnabled,
        );
        _latestResolvedCurrentIndex = currentIndex;
        if (_autoFollowCurrentLyric) {
          _scrollToCurrentLyric(currentIndex);
        }
        content = ListView.builder(
          controller: _syncedScrollController,
          physics: const BouncingScrollPhysics(),
          itemCount: syncedLyrics.length,
          itemBuilder: (context, index) {
            final line = syncedLyrics[index];
            final isActive = index == currentIndex;
            double liveProgress = 0.0;
            if (isActive) {
              final lineStart = line.timestamp;
              final lineEnd = _resolveLineEnd(
                index: index,
                lyrics: syncedLyrics,
                trackDuration: manager.trackDuration,
              );
              final temporalProgress = _temporalProgressForLine(
                lineStart: lineStart,
                lineEnd: lineEnd,
                now: lyricsNow,
              );
              liveProgress = temporalProgress;
              if (liveLyricsEnabled) {
                final wordBased = _wordProgressForLine(
                  lineText: line.text,
                  lineStart: lineStart,
                  lineEnd: lineEnd,
                  now: lyricsNow,
                  fallbackProgress: temporalProgress,
                );
                if (wordBased != null) {
                  // Priorizamos progreso por palabra cuando la señal es confiable.
                  liveProgress = wordBased;
                }
              }
            }
            return Builder(
              key: ValueKey('lyric_line_${manager.currentVideoId}_$index'),
              builder: (lineContext) {
                _syncedLineContexts[index] = lineContext;
                return GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => unawaited(
                    _seekToLyricLine(index: index, timestamp: line.timestamp),
                  ),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 320),
                    curve: Curves.easeInOutCubic,
                    padding: const EdgeInsets.symmetric(
                      vertical: 6,
                      horizontal: 4,
                    ),
                    child: AnimatedOpacity(
                      duration: const Duration(milliseconds: 300),
                      curve: Curves.easeInOut,
                      opacity: isActive ? 1.0 : 0.36,
                      child: AnimatedDefaultTextStyle(
                        duration: const Duration(milliseconds: 320),
                        curve: Curves.easeInOutCubic,
                        style: textStyle.copyWith(
                          fontSize: isActive ? activeFontSize : baseFontSize,
                          fontWeight: isActive
                              ? FontWeight.w700
                              : FontWeight.w600,
                          color: isActive
                              ? activeLyricsColor
                              : inactiveLyricsColor,
                        ),
                        child: isActive && liveLyricsEnabled
                            ? _LiveLyricSweepText(
                                key: ValueKey(
                                  'live_${manager.currentVideoId}_$index',
                                ),
                                text: line.text,
                                progress: liveProgress,
                                baseStyle: textStyle.copyWith(
                                  fontSize: activeFontSize,
                                  fontWeight: FontWeight.w700,
                                  color: inactiveLyricsColor,
                                ),
                                activeStyle: textStyle.copyWith(
                                  fontSize: activeFontSize,
                                  fontWeight: FontWeight.w700,
                                  color: activeLyricsColor,
                                ),
                              )
                            : Text(
                                line.text,
                                textAlign: TextAlign.left,
                                softWrap: true,
                              ),
                      ),
                    ),
                  ),
                );
              },
            );
          },
        );
      }
    } else {
      _latestResolvedCurrentIndex = -1;
      content = Text(manager.lyricsText ?? '', style: textStyle);
    }

    return NotificationListener<ScrollNotification>(
      onNotification: _handleLyricsScrollNotification,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTapDown: (_) => widget.onInteraction?.call(),
        child: SizedBox(
          width: double.infinity,
          child: ConstrainedBox(
            constraints: isImmersive
                ? const BoxConstraints(minHeight: 260)
                : const BoxConstraints(minHeight: 210, maxHeight: 390),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Stack(
                children: [
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.only(
                        bottom: manager.isKaraokeSupported ? 36 : 0,
                      ),
                      child: AnimatedSwitcher(
                        duration: const Duration(milliseconds: 220),
                        child: ShaderMask(
                          shaderCallback: (rect) => LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: const [
                              Colors.transparent,
                              Colors.black,
                              Colors.black,
                              Colors.transparent,
                            ],
                            stops: const [0.0, 0.06, 0.94, 1.0],
                          ).createShader(rect),
                          blendMode: BlendMode.dstIn,
                          child: manager.hasSyncedLyrics
                              ? content
                              : SingleChildScrollView(
                                  key: ValueKey(
                                    '${manager.isLyricsLoading}-${manager.lyricsError}-${manager.lyricsText}',
                                  ),
                                  physics: const BouncingScrollPhysics(),
                                  child: content,
                                ),
                        ),
                      ),
                    ),
                  ),
                  if (manager.isKaraokeSupported)
                    Positioned(
                      right: 2,
                      bottom: 2,
                      child: _LyricsKaraokeButton(
                        isActive: manager.karaokeModeEnabled,
                        isLoading: manager.isAiStemsLoading,
                        onPressed: manager.toggleKaraokeMode,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Duration _effectiveLyricsNow(VideoPlayerManager manager) {
    if (_lyricsVisualTicker == null) {
      return manager.position;
    }
    final duration = manager.trackDuration;
    if (duration > Duration.zero && _visualLyricsPosition > duration) {
      return duration;
    }
    return _visualLyricsPosition;
  }

  bool _isVisualLyricsClockActive({
    required VideoPlayerManager manager,
    required bool liveLyricsEnabled,
  }) {
    return liveLyricsEnabled &&
        manager.hasSyncedLyrics &&
        manager.isLyricsLayout &&
        manager.isPlaying &&
        manager.isAppInForeground &&
        !manager.isMinimized;
  }

  void _syncVisualLyricsClock({
    required VideoPlayerManager manager,
    required bool liveLyricsEnabled,
  }) {
    final targetTickInterval = manager.shouldUseLightweightPlayerUi
        ? _lyricsVisualTickIntervalLowPower
        : _lyricsVisualTickIntervalNormal;
    final shouldRun = _isVisualLyricsClockActive(
      manager: manager,
      liveLyricsEnabled: liveLyricsEnabled,
    );
    if (!shouldRun) {
      _lyricsVisualTicker?.cancel();
      _lyricsVisualTicker = null;
      _activeLyricsVisualTickInterval = null;
      _visualLyricsPosition = manager.position;
      _visualLyricsWallClock = DateTime.now();
      _lastVisualClockManagerPosition = manager.position;
      return;
    }

    if (_lyricsVisualTicker != null &&
        _activeLyricsVisualTickInterval != targetTickInterval) {
      _lyricsVisualTicker?.cancel();
      _lyricsVisualTicker = null;
    }

    if (_lyricsVisualTicker == null) {
      _visualLyricsPosition = manager.position;
      _visualLyricsWallClock = DateTime.now();
      _lastVisualClockManagerPosition = manager.position;
    }

    final managerAdvance =
        (manager.position - _lastVisualClockManagerPosition).inMilliseconds;
    if (managerAdvance.abs() >= 40) {
      _lastVisualClockManagerPosition = manager.position;
      if ((_visualLyricsPosition - manager.position).abs() >
          const Duration(milliseconds: 520)) {
        _visualLyricsPosition = manager.position;
        _visualLyricsWallClock = DateTime.now();
      }
    }

    _lyricsVisualTicker ??= Timer.periodic(targetTickInterval, (_) {
      if (!mounted) return;
      final m = widget.manager;
      if (!_isVisualLyricsClockActive(manager: m, liveLyricsEnabled: true)) {
        _lyricsVisualTicker?.cancel();
        _lyricsVisualTicker = null;
        _activeLyricsVisualTickInterval = null;
        _visualLyricsPosition = m.position;
        _visualLyricsWallClock = DateTime.now();
        _lastVisualClockManagerPosition = m.position;
        return;
      }
      final now = DateTime.now();
      final elapsed = now.difference(_visualLyricsWallClock);
      _visualLyricsWallClock = now;
      if (elapsed <= Duration.zero) return;
      var next = _visualLyricsPosition + elapsed;
      final duration = m.trackDuration;
      if (duration > Duration.zero && next > duration) {
        next = duration;
      }
      if ((next - _visualLyricsPosition).abs() <
          const Duration(milliseconds: 35)) {
        return;
      }
      _visualLyricsPosition = next;
      setState(() {});
    });
    _activeLyricsVisualTickInterval = targetTickInterval;
  }

  Duration _resolveLineEnd({
    required int index,
    required List<SyncedLyricLine> lyrics,
    required Duration trackDuration,
  }) {
    final lineStart = lyrics[index].timestamp;
    final nominalEnd = _resolveNominalLineEnd(
      index: index,
      lyrics: lyrics,
      trackDuration: trackDuration,
    );
    final voiceAwareEnd = _resolveVoiceAlignedLineEnd(
      lineText: lyrics[index].text,
      lineStart: lineStart,
      nominalLineEnd: nominalEnd,
    );
    final activityAwareEnd = _resolveVoiceActivityLineEnd(
      lineStart: lineStart,
      nominalLineEnd: nominalEnd,
    );
    Duration resolved = nominalEnd;
    if (voiceAwareEnd != null && voiceAwareEnd > lineStart) {
      resolved = voiceAwareEnd < resolved ? voiceAwareEnd : resolved;
    }
    if (activityAwareEnd != null && activityAwareEnd > lineStart) {
      resolved = activityAwareEnd < resolved ? activityAwareEnd : resolved;
    }
    return resolved;
  }

  Duration _resolveNominalLineEnd({
    required int index,
    required List<SyncedLyricLine> lyrics,
    required Duration trackDuration,
  }) {
    final lineStart = lyrics[index].timestamp;
    for (var i = index + 1; i < lyrics.length; i++) {
      final nextTs = lyrics[i].timestamp;
      if (nextTs > lineStart + const Duration(milliseconds: 120)) {
        return nextTs;
      }
    }
    if (trackDuration > lineStart) return trackDuration;
    return lineStart + const Duration(seconds: 3);
  }

  Duration? _resolveVoiceAlignedLineEnd({
    required String lineText,
    required Duration lineStart,
    required Duration nominalLineEnd,
  }) {
    if (_alignedWords.isEmpty) return null;
    final lineWords = _normalizeWord(
      lineText,
    ).split(' ').where((w) => w.isNotEmpty).toList(growable: false);
    if (lineWords.isEmpty) return null;

    final windowStart = lineStart - const Duration(milliseconds: 700);
    final safeWindowStart = windowStart > Duration.zero
        ? windowStart
        : Duration.zero;
    final windowEnd = nominalLineEnd + const Duration(milliseconds: 350);
    final candidateWords = _alignedWords
        .where(
          (w) =>
              w.end >= safeWindowStart &&
              w.start <= windowEnd &&
              w.confidence >= 0.22,
        )
        .toList(growable: false);
    if (candidateWords.isEmpty) return null;

    final candidateNormalized = candidateWords
        .map((w) => _normalizeWord(w.word))
        .toList(growable: false);
    final matches = _alignLyricWordsToCandidates(
      lineWords: lineWords,
      candidateWords: candidateNormalized,
      candidateSegments: candidateWords,
    );

    var matchedCount = 0;
    var matchedSimilarity = 0.0;
    Duration? lastMatchedEnd;
    for (var i = 0; i < lineWords.length; i++) {
      final mapped = matches[i];
      if (mapped < 0 || mapped >= candidateWords.length) continue;
      final similarity = _wordSimilarity(
        lineWords[i],
        candidateNormalized[mapped],
      );
      if (similarity < 0.54) continue;
      matchedCount++;
      matchedSimilarity += similarity;
      final end = candidateWords[mapped].end;
      if (lastMatchedEnd == null || end > lastMatchedEnd) {
        lastMatchedEnd = end;
      }
    }
    if (matchedCount == 0 || lastMatchedEnd == null) return null;

    final coverage = matchedCount / lineWords.length;
    final avgSimilarity = matchedSimilarity / matchedCount;
    if (coverage < 0.34 && avgSimilarity < 0.68) return null;

    // Ajuste para que la línea termine cuando acaba la última palabra cantada,
    // sin arrastrar silencios hasta el siguiente timestamp.
    final voiceEnd = lastMatchedEnd + const Duration(milliseconds: 95);
    final minValidEnd = lineStart + const Duration(milliseconds: 220);
    if (voiceEnd < minValidEnd) return null;
    if (voiceEnd < nominalLineEnd) {
      return voiceEnd;
    }
    return nominalLineEnd;
  }

  Duration? _resolveVoiceActivityLineEnd({
    required Duration lineStart,
    required Duration nominalLineEnd,
  }) {
    if (_alignedWords.isEmpty) return null;
    final windowStart = lineStart - const Duration(milliseconds: 160);
    final safeWindowStart = windowStart > Duration.zero
        ? windowStart
        : Duration.zero;
    final candidates = _alignedWords
        .where(
          (w) =>
              w.end >= safeWindowStart &&
              w.start <= nominalLineEnd &&
              w.confidence >= 0.16,
        )
        .toList(growable: false);
    if (candidates.isEmpty) return null;

    Duration? lastSpeechEnd;
    for (final w in candidates) {
      final end = w.end <= nominalLineEnd ? w.end : nominalLineEnd;
      if (end < lineStart + const Duration(milliseconds: 140)) continue;
      if (lastSpeechEnd == null || end > lastSpeechEnd) {
        lastSpeechEnd = end;
      }
    }
    if (lastSpeechEnd == null) return null;

    final trailingGap = nominalLineEnd - lastSpeechEnd;
    // Si al final de la línea hay hueco largo sin voz, terminamos antes
    // aunque siga instrumental/fondo.
    if (trailingGap >= const Duration(milliseconds: 520)) {
      final clamped = lastSpeechEnd + const Duration(milliseconds: 85);
      final minValid = lineStart + const Duration(milliseconds: 220);
      if (clamped > minValid) return clamped;
    }
    return null;
  }

  double _temporalProgressForLine({
    required Duration lineStart,
    required Duration lineEnd,
    required Duration now,
  }) {
    final spanMs = (lineEnd - lineStart).inMilliseconds;
    if (spanMs <= 0) return 1.0;
    final elapsedMs = (now - lineStart).inMilliseconds;
    return (elapsedMs / spanMs).clamp(0.0, 1.0);
  }

  int _resolveDisplayedCurrentIndex({
    required int baseIndex,
    required List<SyncedLyricLine> lyrics,
    required Duration now,
    required Duration trackDuration,
    required bool liveLyricsEnabled,
  }) {
    if (lyrics.isEmpty) return -1;
    if (!liveLyricsEnabled || _alignedWords.isEmpty) return baseIndex;

    // Antes del primer timestamp: si ya detectamos la primera línea en voz,
    // activamos de inmediato para evitar que el barrido entre tarde.
    if (baseIndex < 0) {
      final firstEnd = _resolveLineEnd(
        index: 0,
        lyrics: lyrics,
        trackDuration: trackDuration,
      );
      final firstProgress = _wordProgressForLine(
        lineText: lyrics.first.text,
        lineStart: lyrics.first.timestamp,
        lineEnd: firstEnd,
        now: now,
        fallbackProgress: 0.0,
      );
      if ((firstProgress ?? 0.0) >= 0.06) return 0;
      return -1;
    }

    if (baseIndex >= lyrics.length - 1) return baseIndex;
    final currentLine = lyrics[baseIndex];
    final nextLine = lyrics[baseIndex + 1];
    final currentEnd = _resolveLineEnd(
      index: baseIndex,
      lyrics: lyrics,
      trackDuration: trackDuration,
    );
    final nextEnd = _resolveLineEnd(
      index: baseIndex + 1,
      lyrics: lyrics,
      trackDuration: trackDuration,
    );
    final currentTemporal = _temporalProgressForLine(
      lineStart: currentLine.timestamp,
      lineEnd: currentEnd,
      now: now,
    );
    final nextTemporal = _temporalProgressForLine(
      lineStart: nextLine.timestamp,
      lineEnd: nextEnd,
      now: now,
    );
    final currentWord =
        _wordProgressForLine(
          lineText: currentLine.text,
          lineStart: currentLine.timestamp,
          lineEnd: currentEnd,
          now: now,
          fallbackProgress: currentTemporal,
        ) ??
        currentTemporal;
    final nextWord = _wordProgressForLine(
      lineText: nextLine.text,
      lineStart: nextLine.timestamp,
      lineEnd: nextEnd,
      now: now,
      fallbackProgress: nextTemporal,
    );

    final remainingToCurrentEnd = currentEnd - now;
    final remainingToNext = nextLine.timestamp - now;
    final nearTransition =
        remainingToCurrentEnd <= const Duration(milliseconds: 1400);
    final currentDone = currentWord >= 0.93 || currentTemporal >= 0.985;
    final nextHasLead = (nextWord ?? 0.0) >= 0.08;

    if (now >= currentEnd + const Duration(milliseconds: 110)) {
      return baseIndex + 1;
    }
    if (nearTransition && currentDone && nextHasLead) {
      return baseIndex + 1;
    }
    if (currentWord >= 0.985 &&
        remainingToNext > Duration.zero &&
        remainingToNext <= const Duration(milliseconds: 900)) {
      return baseIndex + 1;
    }
    return baseIndex;
  }

  void _scrollToCurrentLyric(int currentIndex, {bool force = false}) {
    if (currentIndex < 0) return;
    final now = DateTime.now();
    final sameIndex = currentIndex == _lastSyncedIndex;
    final canResolveTargetNow = _canResolveLyricTarget(currentIndex);
    final minFollowGap = canResolveTargetNow
        ? const Duration(milliseconds: 650)
        : const Duration(milliseconds: 180);
    if (!force &&
        sameIndex &&
        now.difference(_lastFollowScrollAt) < minFollowGap) {
      return;
    }
    _lastSyncedIndex = currentIndex;
    _lastFollowScrollAt = now;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (!_syncedScrollController.hasClients) return;
      final targetContext = _syncedLineContexts[currentIndex];
      final targetRenderObject = targetContext?.findRenderObject();
      if (targetRenderObject != null) {
        try {
          _syncedScrollController.position.ensureVisible(
            targetRenderObject,
            alignment: 0.35,
            duration: const Duration(milliseconds: 420),
            curve: Curves.easeInOutCubicEmphasized,
          );
          return;
        } catch (_) {
          // Intentamos fallback por offset aproximado.
        }
      }
      _scrollTowardsCurrentLyricFallback(currentIndex);
    });
  }

  bool _canResolveLyricTarget(int index) {
    final ctx = _syncedLineContexts[index];
    if (ctx == null) return false;
    if (!ctx.mounted) {
      _syncedLineContexts.remove(index);
      return false;
    }
    return ctx.findRenderObject() != null;
  }

  void _scrollTowardsCurrentLyricFallback(int currentIndex) {
    if (!_syncedScrollController.hasClients) return;
    final position = _syncedScrollController.position;
    if (!position.hasContentDimensions) return;

    const estimatedLineExtent = 44.0;
    const desiredAlignment = 0.35;
    final viewport = position.viewportDimension;
    final estimatedOffset =
        (currentIndex * estimatedLineExtent) - (viewport * desiredAlignment);
    final targetOffset = estimatedOffset.clamp(0.0, position.maxScrollExtent);
    final currentOffset = _syncedScrollController.offset;
    if ((targetOffset - currentOffset).abs() < 6) return;

    _syncedScrollController.animateTo(
      targetOffset,
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOutCubic,
    );
  }

  Future<void> _syncIosWordAlignment({
    required VideoPlayerManager manager,
    required bool liveLyricsEnabled,
  }) async {
    if (!liveLyricsEnabled || !manager.hasSyncedLyrics) {
      if (_alignedTrackKey == null && _alignedWords.isEmpty) return;
      _alignedTrackKey = null;
      _alignedWords = const [];
      if (mounted) setState(() {});
      return;
    }
    if (_alignedTrackKey == null && _alignedWords.isEmpty) return;
    _alignedTrackKey = null;
    _alignedWords = const [];
    if (mounted) setState(() {});
  }

  String _normalizeWord(String value) {
    return _stripDiacritics(value.toLowerCase())
        .toLowerCase()
        .replaceAll(RegExp(r"[^\p{L}\p{N}\s]", unicode: true), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  String _stripDiacritics(String value) {
    return value
        .replaceAll(RegExp(r'[àáâãäåāăą]'), 'a')
        .replaceAll(RegExp(r'[èéêëēĕėęě]'), 'e')
        .replaceAll(RegExp(r'[ìíîïĩīĭįı]'), 'i')
        .replaceAll(RegExp(r'[òóôõöøōŏő]'), 'o')
        .replaceAll(RegExp(r'[ùúûüũūŭůűų]'), 'u')
        .replaceAll(RegExp(r'[ýÿŷ]'), 'y')
        .replaceAll(RegExp(r'[ñ]'), 'n')
        .replaceAll(RegExp(r'[ç]'), 'c');
  }

  double _wordSimilarity(String a, String b) {
    if (a == b) return 1.0;
    if (a.isEmpty || b.isEmpty) return 0.0;
    if (a.length >= 4 &&
        b.length >= 4 &&
        (a.startsWith(b) || b.startsWith(a))) {
      return 0.92;
    }
    final distance = _levenshteinDistance(a, b);
    final longest = math.max(a.length, b.length);
    if (longest == 0) return 0.0;
    return (1.0 - (distance / longest)).clamp(0.0, 1.0);
  }

  int _levenshteinDistance(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;
    final prev = List<int>.generate(b.length + 1, (j) => j);
    final curr = List<int>.filled(b.length + 1, 0);
    for (var i = 1; i <= a.length; i++) {
      curr[0] = i;
      for (var j = 1; j <= b.length; j++) {
        final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
        curr[j] = math.min(
          math.min(curr[j - 1] + 1, prev[j] + 1),
          prev[j - 1] + cost,
        );
      }
      for (var j = 0; j <= b.length; j++) {
        prev[j] = curr[j];
      }
    }
    return prev[b.length];
  }

  List<int> _alignLyricWordsToCandidates({
    required List<String> lineWords,
    required List<String> candidateWords,
    required List<LiveLyricWordTiming> candidateSegments,
  }) {
    final n = lineWords.length;
    final m = candidateWords.length;
    if (n == 0 || m == 0) return List<int>.filled(n, -1);

    const skipLyricPenalty = -0.30;
    const skipCandidatePenalty = -0.18;
    const minMatchScore = 0.46;
    const lowMatchPenalty = -0.50;

    final dp = List<List<double>>.generate(
      n + 1,
      (_) => List<double>.filled(m + 1, 0.0),
    );
    final backtrack = List<List<int>>.generate(
      n + 1,
      (_) => List<int>.filled(m + 1, 0),
    );

    for (var i = 1; i <= n; i++) {
      dp[i][0] = i * skipLyricPenalty;
      backtrack[i][0] = 2;
    }
    for (var j = 1; j <= m; j++) {
      dp[0][j] = j * skipCandidatePenalty;
      backtrack[0][j] = 3;
    }

    for (var i = 1; i <= n; i++) {
      for (var j = 1; j <= m; j++) {
        final similarity = _wordSimilarity(
          lineWords[i - 1],
          candidateWords[j - 1],
        );
        final confidence = candidateSegments[j - 1].confidence;
        final matchBonus = similarity >= minMatchScore
            ? similarity * (0.78 + (confidence * 0.35))
            : lowMatchPenalty;
        final diag = dp[i - 1][j - 1] + matchBonus;
        final up = dp[i - 1][j] + skipLyricPenalty;
        final left = dp[i][j - 1] + skipCandidatePenalty;

        if (diag >= up && diag >= left) {
          dp[i][j] = diag;
          backtrack[i][j] = 1;
        } else if (up >= left) {
          dp[i][j] = up;
          backtrack[i][j] = 2;
        } else {
          dp[i][j] = left;
          backtrack[i][j] = 3;
        }
      }
    }

    final matches = List<int>.filled(n, -1);
    var i = n;
    var j = m;
    while (i > 0 || j > 0) {
      final action = backtrack[i][j];
      if (action == 1 && i > 0 && j > 0) {
        final similarity = _wordSimilarity(
          lineWords[i - 1],
          candidateWords[j - 1],
        );
        if (similarity >= minMatchScore) {
          matches[i - 1] = j - 1;
        }
        i--;
        j--;
      } else if (action == 2 && i > 0) {
        i--;
      } else if (action == 3 && j > 0) {
        j--;
      } else {
        break;
      }
    }
    return matches;
  }

  double? _wordProgressForLine({
    required String lineText,
    required Duration lineStart,
    required Duration lineEnd,
    required Duration now,
    required double fallbackProgress,
  }) {
    if (_alignedWords.isEmpty) return null;
    final windowStart = lineStart - const Duration(milliseconds: 700);
    final safeWindowStart = windowStart > Duration.zero
        ? windowStart
        : Duration.zero;
    final windowEnd = lineEnd + const Duration(milliseconds: 550);
    final candidateWords = _alignedWords
        .where(
          (w) =>
              w.end >= safeWindowStart &&
              w.start <= windowEnd &&
              w.confidence >= 0.26,
        )
        .toList(growable: false);
    if (candidateWords.isEmpty) return null;

    final lineWords = _normalizeWord(
      lineText,
    ).split(' ').where((w) => w.isNotEmpty).toList(growable: false);
    if (lineWords.isEmpty) return null;

    final candidateNormalized = candidateWords
        .map((w) => _normalizeWord(w.word))
        .toList(growable: false);
    final matches = _alignLyricWordsToCandidates(
      lineWords: lineWords,
      candidateWords: candidateNormalized,
      candidateSegments: candidateWords,
    );

    final lineSpanMs = math.max(850, (lineEnd - lineStart).inMilliseconds);
    final lineStartMs = lineStart.inMilliseconds;
    final wordCount = lineWords.length;

    var weightedProgress = 0.0;
    var totalWeight = 0.0;
    var matchedTotal = 0;
    var matchedSimilarity = 0.0;

    for (var idx = 0; idx < wordCount; idx++) {
      final matchedIndex = matches[idx];
      double partialProgress;
      double weight;

      if (matchedIndex >= 0 && matchedIndex < candidateWords.length) {
        final segment = candidateWords[matchedIndex];
        final spanMs = math.max(
          90,
          (segment.end - segment.start).inMilliseconds,
        );
        final elapsedMs = (now - segment.start).inMilliseconds;
        partialProgress = (elapsedMs / spanMs).clamp(0.0, 1.0);
        final similarity = _wordSimilarity(
          lineWords[idx],
          candidateNormalized[matchedIndex],
        );
        matchedSimilarity += similarity;
        matchedTotal++;
        final confidenceWeight =
            0.72 + (segment.confidence.clamp(0.0, 1.0) * 0.38);
        final similarityWeight = 0.65 + (similarity * 0.45);
        weight = confidenceWeight * similarityWeight;
      } else {
        final startMs = lineStartMs + ((lineSpanMs * idx) ~/ wordCount);
        final endMs = lineStartMs + ((lineSpanMs * (idx + 1)) ~/ wordCount);
        final spanMs = math.max(90, endMs - startMs);
        final elapsedMs = now.inMilliseconds - startMs;
        partialProgress = (elapsedMs / spanMs).clamp(0.0, 1.0);
        weight = 0.52;
      }

      weightedProgress += partialProgress * weight;
      totalWeight += weight;
    }

    if (matchedTotal == 0 || totalWeight <= 0.0) return null;
    final coverage = matchedTotal / wordCount;
    final avgSimilarity = matchedSimilarity / matchedTotal;
    if (coverage < 0.20 && avgSimilarity < 0.58) return null;

    final wordProgress = (weightedProgress / totalWeight).clamp(0.0, 1.0);
    final trust = ((coverage * 0.72) + (avgSimilarity * 0.28)).clamp(0.0, 1.0);
    final fallbackWeight = (0.58 - (trust * 0.46)).clamp(0.14, 0.58);
    final blended =
        (wordProgress * (1 - fallbackWeight)) +
        (fallbackProgress * fallbackWeight);
    final maxAhead = (fallbackProgress + 0.12 + (trust * 0.16)).clamp(0.0, 1.0);
    final minBehind = (fallbackProgress - 0.28).clamp(0.0, 1.0);
    return blended.clamp(minBehind, maxAhead);
  }
}

class _LyricsKaraokeButton extends StatefulWidget {
  final bool isActive;
  final bool isLoading;
  final VoidCallback onPressed;

  const _LyricsKaraokeButton({
    required this.isActive,
    required this.isLoading,
    required this.onPressed,
  });

  @override
  State<_LyricsKaraokeButton> createState() => _LyricsKaraokeButtonState();
}

class _LyricsKaraokeButtonState extends State<_LyricsKaraokeButton>
    with TickerProviderStateMixin {
  AnimationController? _ringController;

  @override
  void initState() {
    super.initState();
    _ensureController();
  }

  @override
  void didUpdateWidget(covariant _LyricsKaraokeButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    _ensureController();
    if (oldWidget.isActive == widget.isActive) return;
    _ringController!.duration = widget.isActive
        ? const Duration(milliseconds: 1200)
        : const Duration(milliseconds: 2300);
    _ringController!
      ..reset()
      ..repeat();
  }

  @override
  void dispose() {
    _ringController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _ensureController();
    return AnimatedBuilder(
      animation: _ringController!,
      builder: (context, _) {
        final borderRadius = BorderRadius.circular(16);
        const activeColor = Color(0xFFFF4778);
        const activeSecondary = Color(0xFFFF9B54);
        return CupertinoButton(
          padding: EdgeInsets.zero,
          minimumSize: Size.zero,
          onPressed: widget.onPressed,
          child: Container(
            padding: const EdgeInsets.all(1.35),
            decoration: BoxDecoration(
              borderRadius: borderRadius,
              gradient: SweepGradient(
                transform: GradientRotation(_ringController!.value * 6.2831853),
                colors: const [
                  Color(0xFFFF4778),
                  Color(0xFFFF6B4A),
                  Color(0xFFFFA43D),
                  Color(0xFFFF4778),
                ],
              ),
              boxShadow: [
                BoxShadow(
                  color: activeColor.withValues(
                    alpha: widget.isActive ? 0.36 : 0.16,
                  ),
                  blurRadius: widget.isActive ? 16 : 9,
                  spreadRadius: widget.isActive ? 0.8 : 0.0,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: borderRadius,
              child: _PerformanceBackdrop(
                filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: widget.isActive
                        ? activeColor.withValues(alpha: 0.24)
                        : CupertinoColors.systemGrey6
                              .resolveFrom(context)
                              .withValues(alpha: 0.52),
                    borderRadius: borderRadius,
                  ),
                  child: widget.isLoading
                      ? CupertinoActivityIndicator(
                          radius: 8,
                          color: widget.isActive
                              ? activeSecondary
                              : CupertinoColors.label.resolveFrom(context),
                        )
                      : Icon(
                          CupertinoIcons.music_mic,
                          size: 18,
                          color: widget.isActive
                              ? activeSecondary
                              : CupertinoColors.label.resolveFrom(context),
                        ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  void _ensureController() {
    if (_ringController != null) return;
    _ringController = AnimationController(
      vsync: this,
      duration: widget.isActive
          ? const Duration(milliseconds: 1200)
          : const Duration(milliseconds: 2300),
    )..repeat();
  }
}

class _LiveLyricSweepText extends StatelessWidget {
  final String text;
  final double progress;
  final TextStyle baseStyle;
  final TextStyle activeStyle;

  const _LiveLyricSweepText({
    super.key,
    required this.text,
    required this.progress,
    required this.baseStyle,
    required this.activeStyle,
  });

  static const Duration _sweepAnimationDuration = Duration(milliseconds: 280);
  static const double _sweepFeather = 0.11;
  static const int _lineWrapCacheMaxEntries = 260;
  static final Map<String, List<String>> _lineWrapCache =
      <String, List<String>>{};
  static final List<String> _lineWrapCacheOrder = <String>[];

  @override
  Widget build(BuildContext context) {
    final targetProgress = progress.clamp(0.0, 1.0);
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(end: targetProgress),
      duration: _sweepAnimationDuration,
      curve: Curves.easeOutCubic,
      builder: (context, animatedProgress, _) {
        final p = animatedProgress.clamp(0.0, 1.0);
        return LayoutBuilder(
          builder: (context, constraints) {
            final maxWidth = constraints.maxWidth.isFinite
                ? constraints.maxWidth
                : MediaQuery.sizeOf(context).width;

            final lines = _wrapIntoLines(
              text: text,
              style: activeStyle,
              maxWidth: maxWidth,
              textDirection: Directionality.of(context),
            );
            if (lines.isEmpty) {
              return Text(
                text,
                textAlign: TextAlign.left,
                softWrap: true,
                style: baseStyle,
              );
            }

            final weights = lines
                .map((line) => math.max(1, line.trim().runes.length))
                .toList(growable: false);
            final totalWeight = weights.fold<int>(0, (sum, w) => sum + w);

            return Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (var i = 0; i < lines.length; i++)
                  _buildSweepLine(
                    line: lines[i],
                    globalProgress: p,
                    lineWeight: weights[i],
                    cumulativeWeightBefore: weights
                        .take(i)
                        .fold<int>(0, (sum, w) => sum + w),
                    totalWeight: totalWeight,
                  ),
              ],
            );
          },
        );
      },
    );
  }

  List<String> _wrapIntoLines({
    required String text,
    required TextStyle style,
    required double maxWidth,
    required TextDirection textDirection,
  }) {
    final normalized = text.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (normalized.isEmpty) return const [];
    final cacheKey = _lineWrapCacheKey(
      text: normalized,
      style: style,
      maxWidth: maxWidth,
      textDirection: textDirection,
    );
    final cached = _lineWrapCache[cacheKey];
    if (cached != null) {
      return cached;
    }
    final words = normalized.split(' ').where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return const [];

    double widthFor(String value) {
      final painter = TextPainter(
        text: TextSpan(text: value, style: style),
        textDirection: textDirection,
        maxLines: 1,
      )..layout(maxWidth: double.infinity);
      return painter.width;
    }

    final lines = <String>[];
    var current = '';
    var index = 0;
    while (index < words.length) {
      final word = words[index];
      final candidate = current.isEmpty ? word : '$current $word';
      final fits = widthFor(candidate) <= maxWidth || current.isEmpty;

      if (fits) {
        current = candidate;
        index++;
        continue;
      }

      lines.add(current);
      current = '';
    }

    if (current.isNotEmpty) {
      lines.add(current);
    }
    _storeLineWrapCache(cacheKey, lines);
    return lines;
  }

  String _lineWrapCacheKey({
    required String text,
    required TextStyle style,
    required double maxWidth,
    required TextDirection textDirection,
  }) {
    final widthKey = maxWidth.round();
    final fontSize = (style.fontSize ?? 0).toStringAsFixed(2);
    final weight = style.fontWeight?.index ?? -1;
    final letterSpacing = (style.letterSpacing ?? 0).toStringAsFixed(2);
    final family = style.fontFamily ?? '';
    return '$textDirection|$widthKey|$fontSize|$weight|$letterSpacing|$family|$text';
  }

  void _storeLineWrapCache(String key, List<String> lines) {
    final stored = List<String>.unmodifiable(lines);
    if (_lineWrapCache.containsKey(key)) {
      _lineWrapCache[key] = stored;
      _lineWrapCacheOrder.remove(key);
      _lineWrapCacheOrder.add(key);
      return;
    }
    _lineWrapCache[key] = stored;
    _lineWrapCacheOrder.add(key);
    if (_lineWrapCacheOrder.length <= _lineWrapCacheMaxEntries) return;
    final oldest = _lineWrapCacheOrder.removeAt(0);
    _lineWrapCache.remove(oldest);
  }

  Widget _buildSweepLine({
    required String line,
    required double globalProgress,
    required int lineWeight,
    required int cumulativeWeightBefore,
    required int totalWeight,
  }) {
    final startShare = cumulativeWeightBefore / totalWeight;
    final endShare = (cumulativeWeightBefore + lineWeight) / totalWeight;
    final span = math.max(0.0001, endShare - startShare);
    final localProgress = ((globalProgress - startShare) / span).clamp(
      0.0,
      1.0,
    );
    final easedProgress = Curves.easeInOutCubic.transform(localProgress);

    final softFeather = (_sweepFeather + ((1 - easedProgress) * 0.03)).clamp(
      0.09,
      0.15,
    );
    final softStart = (easedProgress - softFeather).clamp(0.0, 1.0);
    final softMidLeft = (easedProgress - (softFeather * 0.42)).clamp(0.0, 1.0);
    final softMidRight = (easedProgress + (softFeather * 0.42)).clamp(0.0, 1.0);
    final softEdge = (easedProgress + softFeather).clamp(0.0, 1.0);

    final glowHalf = (0.075 + ((1 - easedProgress) * 0.02)).clamp(0.06, 0.11);
    final glowStart = (easedProgress - glowHalf).clamp(0.0, 1.0);
    final glowInnerStart = (easedProgress - (glowHalf * 0.4)).clamp(0.0, 1.0);
    final glowInnerEnd = (easedProgress + (glowHalf * 0.4)).clamp(0.0, 1.0);
    final glowEnd = (easedProgress + glowHalf).clamp(0.0, 1.0);
    final baseActiveColor = activeStyle.color ?? const Color(0xFFFFFFFF);

    return Padding(
      padding: const EdgeInsets.only(bottom: 1),
      child: Stack(
        children: [
          Text(
            line,
            textAlign: TextAlign.left,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: baseStyle,
          ),
          ShaderMask(
            blendMode: BlendMode.dstIn,
            shaderCallback: (rect) {
              return LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: const [
                  Color(0xFFFFFFFF),
                  Color(0xFFFFFFFF),
                  Color(0xF3FFFFFF),
                  Color(0xD6FFFFFF),
                  Color(0x8AFFFFFF),
                  Color(0x00000000),
                  Color(0x00000000),
                ],
                stops: [
                  0.0,
                  softStart,
                  softMidLeft,
                  easedProgress,
                  softMidRight,
                  softEdge,
                  1.0,
                ],
              ).createShader(rect);
            },
            child: Text(
              line,
              textAlign: TextAlign.left,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: activeStyle,
            ),
          ),
          // Banda de brillo sutil en el frente del barrido.
          ShaderMask(
            blendMode: BlendMode.dstIn,
            shaderCallback: (rect) {
              return LinearGradient(
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
                colors: const [
                  Color(0x00000000),
                  Color(0x33FFFFFF),
                  Color(0xE0FFFFFF),
                  Color(0x33FFFFFF),
                  Color(0x00000000),
                ],
                stops: [
                  glowStart,
                  glowInnerStart,
                  easedProgress,
                  glowInnerEnd,
                  glowEnd,
                ],
              ).createShader(rect);
            },
            child: Text(
              line,
              textAlign: TextAlign.left,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: activeStyle.copyWith(
                color: Colors.white.withValues(alpha: 0.90),
                shadows: [
                  Shadow(
                    color: baseActiveColor.withValues(alpha: 0.40),
                    blurRadius: 14,
                  ),
                  Shadow(
                    color: Colors.white.withValues(alpha: 0.22),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ArtworkImage extends StatefulWidget {
  final String? url;
  final double size;
  final bool animated;
  final bool isPlaying;
  final double motionEnergy;
  final double borderRadius;

  const _ArtworkImage({
    super.key,
    required this.url,
    required this.size,
    this.animated = false,
    this.isPlaying = false,
    this.motionEnergy = 1.0,
    this.borderRadius = 20,
  });

  @override
  State<_ArtworkImage> createState() => _ArtworkImageState();
}

class _SubjectMotionProfile {
  final Alignment alignment;
  final double moveScale;
  final double tiltScale;
  final double zoomBoost;
  final int styleVariant;

  const _SubjectMotionProfile({
    required this.alignment,
    required this.moveScale,
    required this.tiltScale,
    required this.zoomBoost,
    required this.styleVariant,
  });
}

class _FocusObjectLayer {
  final Uint8List bytes;
  final Alignment alignment;
  final double areaRatio;

  const _FocusObjectLayer({
    required this.bytes,
    required this.alignment,
    required this.areaRatio,
  });
}

class _ArtworkImageState extends State<_ArtworkImage>
    with TickerProviderStateMixin {
  AnimationController? _motionController;
  AnimationController? _pulseController;
  // Mantener escala estable del sujeto para evitar saltos visuales de tamaño.
  static const double _subjectSizeMultiplier = 0.82;
  // La capa de foco puede variar mucho de tamaño según el recorte detectado.
  // La desactivamos para priorizar consistencia visual del sujeto completo.
  static const bool _enableFocusObjectLayer = false;
  static const int _maxArtworkCacheEntries = 120;
  static final Map<String, Uint8List?> _subjectCutoutCache =
      <String, Uint8List?>{};
  static final Map<String, Future<Uint8List?>> _subjectCutoutRequests =
      <String, Future<Uint8List?>>{};
  static final Map<String, Uint8List?> _imageBytesCache =
      <String, Uint8List?>{};
  static final Map<String, Future<Uint8List?>> _imageBytesRequests =
      <String, Future<Uint8List?>>{};
  static final Map<String, _SubjectMotionProfile?> _subjectProfileCache =
      <String, _SubjectMotionProfile?>{};
  static final Map<String, Future<_SubjectMotionProfile?>>
  _subjectProfileRequests = <String, Future<_SubjectMotionProfile?>>{};
  static final Map<String, _FocusObjectLayer?> _focusObjectCache =
      <String, _FocusObjectLayer?>{};
  static final Map<String, Future<_FocusObjectLayer?>> _focusObjectRequests =
      <String, Future<_FocusObjectLayer?>>{};
  Uint8List? _subjectCutoutBytes;
  String? _lastSubjectUrl;
  _SubjectMotionProfile? _subjectMotionProfile;
  String? _lastSubjectProfileUrl;
  _FocusObjectLayer? _focusObjectLayer;
  String? _lastFocusObjectUrl;
  String? _aiAnimatedCoverUrl;
  String? _lastAiCoverSource;
  bool _didCleanupAiPipeline = false;
  VideoPlayerController? _aiVideoControllerA;
  VideoPlayerController? _aiVideoControllerB;
  VideoPlayerController? _aiActiveVideoController;
  VideoPlayerController? _aiStandbyVideoController;
  AnimationController? _aiLoopBlendController;
  Timer? _aiLoopSwapTimer;
  int _aiLoopToken = 0;
  static const Duration _aiLoopCrossfadeDuration = Duration(milliseconds: 280);
  static const Duration _aiLoopSwapLeadTime = Duration(milliseconds: 360);
  String? _aiVideoSource;
  bool _aiVideoReady = false;
  bool _heavyArtworkEffectsSuspended = false;

  @override
  void initState() {
    super.initState();
    _syncAnimationControllers(initial: true);
    if (widget.animated) {
      unawaited(_resolveSubjectCutout());
    }
  }

  @override
  void didUpdateWidget(covariant _ArtworkImage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.animated != widget.animated ||
        oldWidget.isPlaying != widget.isPlaying) {
      _syncAnimationControllers();
    }
    if (oldWidget.url != widget.url) {
      if (widget.animated) {
        unawaited(_resolveSubjectCutout());
      } else {
        _aiAnimatedCoverUrl = null;
        _lastAiCoverSource = null;
        _aiVideoReady = false;
        _aiVideoSource = null;
        _aiLoopToken++;
        unawaited(_disposeAiVideoControllers());
        _lastSubjectUrl = null;
        _lastSubjectProfileUrl = null;
        _subjectMotionProfile = null;
        _lastFocusObjectUrl = null;
        _focusObjectLayer = null;
        if (_subjectCutoutBytes != null && mounted) {
          setState(() {
            _subjectCutoutBytes = null;
          });
        } else {
          _subjectCutoutBytes = null;
        }
      }
    } else if (oldWidget.animated && !widget.animated) {
      _aiVideoReady = false;
      _aiVideoSource = null;
      _aiLoopToken++;
      unawaited(_disposeAiVideoControllers());
    }
  }

  @override
  void dispose() {
    _motionController?.dispose();
    _pulseController?.dispose();
    _aiLoopToken++;
    _aiLoopSwapTimer?.cancel();
    _aiLoopBlendController?.dispose();
    unawaited(_disposeAiVideoControllers());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettingsService?>();
    final dataSaverMode = settings?.dataSaverMode ?? false;
    final playerUiState = context
        .select<
          VideoPlayerManager,
          ({
            bool isLowPowerModeEnabled,
            bool isAppInForeground,
            bool isMinimized,
          })
        >(
          (manager) => (
            isLowPowerModeEnabled: manager.isLowPowerModeEnabled,
            isAppInForeground: manager.isAppInForeground,
            isMinimized: manager.isMinimized,
          ),
        );
    final lowPowerMode = playerUiState.isLowPowerModeEnabled;
    final appInForeground = playerUiState.isAppInForeground;
    final shouldForceStaticArtwork =
        playerUiState.isMinimized || !appInForeground;
    final canRunHeavyArtworkEffects =
        widget.animated &&
        !dataSaverMode &&
        appInForeground &&
        !lowPowerMode &&
        !playerUiState.isMinimized;
    if (shouldForceStaticArtwork) {
      _syncHeavyArtworkEffectsBudget(enabled: false);
      final staticSource = _displayArtworkSourceUrl();
      final hasStaticImage = staticSource.isNotEmpty;
      return _buildStaticArtworkFrame(
        context,
        imageSource: staticSource,
        hasImage: hasStaticImage,
        preferLowResolution: dataSaverMode,
      );
    }
    _syncHeavyArtworkEffectsBudget(enabled: canRunHeavyArtworkEffects);
    if (canRunHeavyArtworkEffects) {
      _maybeResolveAiAnimatedCover();
    }
    final displayImageSource = _displayArtworkSourceUrl();
    final hasImage = displayImageSource.isNotEmpty;
    final useAiVideoArtwork =
        _aiVideoReady && (_aiAnimatedCoverUrl?.trim().isNotEmpty ?? false);
    final isAiVideoSource =
        useAiVideoArtwork && _looksLikeVideoSource(displayImageSource);
    final fallbackStillSource = widget.url?.trim() ?? '';
    if (canRunHeavyArtworkEffects && useAiVideoArtwork) {
      _syncAiVideoControllerForSource(displayImageSource);
    }
    final animatedCutoutEnabled = settings?.animatedCutoutCovers ?? true;
    const hasAiAnimatedCandidate = false;
    // Cuando ya existe resultado IA, evitamos el parallax manual para no
    // enmascarar la animación generativa de objetos/personas.
    final enableMotion =
        canRunHeavyArtworkEffects &&
        hasImage &&
        animatedCutoutEnabled &&
        !hasAiAnimatedCandidate;
    final enableObjectMotion =
        canRunHeavyArtworkEffects && hasImage && animatedCutoutEnabled;

    if (!canRunHeavyArtworkEffects) {
      return _buildStaticArtworkFrame(
        context,
        imageSource: displayImageSource,
        hasImage: hasImage,
        preferLowResolution: dataSaverMode,
      );
    }
    final motionController = _motionController;
    final pulseController = _pulseController;
    if (motionController == null || pulseController == null) {
      return _buildStaticArtworkFrame(
        context,
        imageSource: displayImageSource,
        hasImage: hasImage,
        preferLowResolution: dataSaverMode,
      );
    }

    final artworkChild = hasImage
        ? (isAiVideoSource && _aiVideoReady && _aiActiveVideoController != null
              ? _buildAnimatedVideoCover()
              : _buildArtworkImage(
                  context,
                  imageSource: isAiVideoSource
                      ? (fallbackStillSource.isNotEmpty
                            ? fallbackStillSource
                            : displayImageSource)
                      : displayImageSource,
                  preferLowResolution: dataSaverMode,
                ))
        : Icon(
            Icons.music_note_rounded,
            size: widget.size * 0.4,
            color: Theme.of(context).colorScheme.primary,
          );
    if (animatedCutoutEnabled &&
        canRunHeavyArtworkEffects &&
        hasImage &&
        _subjectCutoutBytes == null) {
      unawaited(_resolveSubjectCutout());
    }

    return SizedBox.square(
      dimension: widget.size,
      child: AnimatedBuilder(
        animation: Listenable.merge([motionController, pulseController]),
        child: artworkChild,
        builder: (context, child) {
          final turn = motionController.value * math.pi * 2;
          final playFactor = widget.isPlaying ? 1.0 : 0.38;
          final energy = widget.motionEnergy.clamp(0.78, 1.32);
          final motionGain = playFactor * energy;
          final profile = _subjectMotionProfile;
          final subjectMoveScale = profile?.moveScale ?? 1.0;
          final subjectTiltScale = profile?.tiltScale ?? 1.0;
          final subjectZoomBoost = profile?.zoomBoost ?? 0.0;
          final subjectStyle =
              profile?.styleVariant ?? _subjectMotionStyleForUrl(widget.url);
          final motionSeedX = _stableNoiseFromString(widget.url, salt: 1);
          final motionSeedY = _stableNoiseFromString(widget.url, salt: 2);
          final phaseA = motionSeedX * math.pi * 2;
          final phaseB = motionSeedY * math.pi * 2;

          final dx = enableMotion
              ? ((math.sin(turn * 0.86 + phaseA) * widget.size * 0.0096) +
                        (math.sin(turn * 1.73 + phaseB) *
                            widget.size *
                            0.0038)) *
                    motionGain *
                    subjectMoveScale
              : 0.0;
          final dy = enableMotion
              ? ((math.cos(turn * 0.92 + phaseB) * widget.size * 0.0084) +
                        (math.cos(turn * 1.61 + phaseA) *
                            widget.size *
                            0.0035)) *
                    motionGain *
                    subjectMoveScale
              : 0.0;
          // Overscan base para evitar huecos en bordes al aplicar translate/tilt.
          final baseArtworkScale = enableMotion
              ? (1.10 + ((energy - 0.78) * 0.03)).clamp(1.10, 1.16)
              : 1.0;
          final zoom = enableMotion
              ? baseArtworkScale +
                    (math.sin(turn * 0.94 + phaseA) * 0.020 * motionGain) +
                    (subjectZoomBoost * 0.018)
              : 1.0;
          final tilt = enableMotion
              ? math.sin(turn * 1.92 + phaseB) *
                    0.012 *
                    motionGain *
                    subjectTiltScale
              : 0.0;
          final warpX = enableMotion
              ? math.sin(turn * 2.84 + phaseA) *
                    0.018 *
                    motionGain *
                    subjectTiltScale
              : 0.0;
          final warpY = enableMotion
              ? math.cos(turn * 1.76 + phaseB) *
                    0.015 *
                    motionGain *
                    subjectTiltScale
              : 0.0;
          final baseAlignment = profile?.alignment ?? Alignment.center;
          final focusAlignment = Alignment(
            (baseAlignment.x * 0.40) +
                (enableMotion
                    ? math.sin(turn * 0.78 + phaseA) * 0.16 * motionGain
                    : 0),
            (baseAlignment.y * 0.34) +
                (enableMotion
                    ? math.cos(turn * 0.74 + phaseB) * 0.13 * motionGain
                    : 0),
          );
          final focusObjectLayer = _focusObjectLayer;
          final hasFocusObjectLayer =
              _enableFocusObjectLayer &&
              enableObjectMotion &&
              focusObjectLayer != null;
          final hasSubjectLayer =
              enableMotion &&
              _subjectCutoutBytes != null &&
              !hasFocusObjectLayer;

          var subjectRotXFreq = 2.0;
          var subjectRotYFreq = 3.0;
          var subjectRotXAmp = 0.022;
          var subjectRotYAmp = 0.024;
          var subjectMoveXFreq = 2.0;
          var subjectMoveYFreq = 1.0;
          var subjectMoveXAmp = widget.size * 0.014;
          var subjectMoveYAmp = widget.size * 0.010;
          var subjectAlignment = focusAlignment;

          switch (subjectStyle) {
            case 0:
              // Orbit suave.
              subjectRotXFreq = 1.0;
              subjectRotYFreq = 2.0;
              subjectMoveXFreq = 1.0;
              subjectMoveYFreq = 2.0;
              subjectMoveXAmp = widget.size * 0.016;
              subjectMoveYAmp = widget.size * 0.012;
              break;
            case 1:
              // Flotación vertical.
              subjectRotXFreq = 2.0;
              subjectRotYFreq = 1.0;
              subjectMoveXFreq = 3.0;
              subjectMoveYFreq = 1.0;
              subjectMoveXAmp = widget.size * 0.010;
              subjectMoveYAmp = widget.size * 0.018;
              break;
            case 2:
              // Drift lateral.
              subjectRotXFreq = 1.0;
              subjectRotYFreq = 1.0;
              subjectMoveXFreq = 1.0;
              subjectMoveYFreq = 4.0;
              subjectMoveXAmp = widget.size * 0.020;
              subjectMoveYAmp = widget.size * 0.006;
              subjectAlignment = Alignment(
                focusAlignment.x * 0.7,
                focusAlignment.y * 0.5,
              );
              break;
            case 3:
              // Pulso frontal.
              subjectRotXFreq = 3.0;
              subjectRotYFreq = 2.0;
              subjectMoveXFreq = 2.0;
              subjectMoveYFreq = 2.0;
              subjectMoveXAmp = widget.size * 0.009;
              subjectMoveYAmp = widget.size * 0.009;
              break;
            case 4:
              // Swing diagonal.
              subjectRotXFreq = 2.0;
              subjectRotYFreq = 4.0;
              subjectMoveXFreq = 4.0;
              subjectMoveYFreq = 1.0;
              subjectMoveXAmp = widget.size * 0.017;
              subjectMoveYAmp = widget.size * 0.014;
              subjectAlignment = Alignment(
                (focusAlignment.x * 0.8) + 0.05,
                focusAlignment.y * 0.8,
              );
              break;
          }

          final objectGain = (widget.isPlaying ? 1.0 : 0.44) * energy;
          final focusAreaRatio = focusObjectLayer?.areaRatio ?? 0.0;
          final areaBoost = (1.0 - focusAreaRatio).clamp(0.22, 1.0);
          final objectDepthScale = (1.01 + ((1.0 - focusAreaRatio) * 0.06))
              .clamp(1.0, 1.08);
          final objectDriftX =
              ((math.sin(turn * 1.34 + phaseB) * 0.008) +
                  (math.sin(turn * 2.38 + phaseA) * 0.004)) *
              widget.size *
              objectGain *
              areaBoost;
          final objectDriftY =
              ((math.cos(turn * 1.18 + phaseA) * 0.006) +
                  (math.cos(turn * 2.04 + phaseB) * 0.003)) *
              widget.size *
              objectGain *
              areaBoost;
          final objectRotX =
              math.sin(turn * 1.22 + phaseA) * 0.034 * objectGain * areaBoost;
          final objectRotY =
              math.cos(turn * 1.51 + phaseB) * 0.031 * objectGain * areaBoost;
          final objectRotZ =
              math.sin(turn * 0.82 + phaseB) * 0.020 * objectGain * areaBoost;

          return Stack(
            clipBehavior: Clip.none,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(widget.borderRadius),
                child: ColoredBox(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  child: hasImage
                      ? Stack(
                          fit: StackFit.expand,
                          children: [
                            Transform(
                              alignment: focusAlignment,
                              transform: Matrix4.identity()
                                ..setEntry(3, 2, 0.00115)
                                ..rotateX(warpY)
                                ..rotateY(warpX)
                                ..rotateZ(tilt),
                              child: Transform.translate(
                                offset: Offset(dx, dy),
                                child: Transform.scale(
                                  scale: zoom,
                                  child: Align(
                                    alignment: focusAlignment,
                                    child: child,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        )
                      : child,
                ),
              ),
              if (enableMotion)
                Positioned(
                  top: -widget.size * 0.26 * _subjectSizeMultiplier,
                  left: -widget.size * 0.20 * _subjectSizeMultiplier,
                  right: -widget.size * 0.20 * _subjectSizeMultiplier,
                  bottom: -widget.size * 0.28 * _subjectSizeMultiplier,
                  child: IgnorePointer(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 280),
                      switchInCurve: Curves.easeOutCubic,
                      switchOutCurve: Curves.easeInCubic,
                      transitionBuilder: (child, animation) {
                        return FadeTransition(opacity: animation, child: child);
                      },
                      child: hasSubjectLayer
                          ? Opacity(
                              key: const ValueKey('subject-layer-on'),
                              opacity: 0.94 * (widget.isPlaying ? 1.0 : 0.76),
                              child: Transform(
                                alignment: subjectAlignment,
                                transform: Matrix4.identity()
                                  ..setEntry(3, 2, 0.0018)
                                  ..rotateX(
                                    math.sin(turn * subjectRotXFreq) *
                                        subjectRotXAmp *
                                        motionGain,
                                  )
                                  ..rotateY(
                                    math.cos(turn * subjectRotYFreq) *
                                        subjectRotYAmp *
                                        motionGain,
                                  ),
                                child: Transform.translate(
                                  offset: Offset(
                                    math.sin(turn * subjectMoveXFreq) *
                                        subjectMoveXAmp *
                                        motionGain,
                                    math.cos(turn * subjectMoveYFreq) *
                                        subjectMoveYAmp *
                                        motionGain,
                                  ),
                                  child: Transform.scale(
                                    scale: _subjectSizeMultiplier,
                                    child: ClipRect(
                                      child: Align(
                                        alignment: Alignment.center,
                                        widthFactor: 0.93,
                                        child: Image.memory(
                                          _subjectCutoutBytes!,
                                          fit: BoxFit.contain,
                                          filterQuality: FilterQuality.low,
                                          gaplessPlayback: true,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          : const SizedBox(key: ValueKey('subject-layer-off')),
                    ),
                  ),
                ),
              if (hasFocusObjectLayer)
                Positioned.fill(
                  child: IgnorePointer(
                    child: Opacity(
                      opacity: 0.96 * (widget.isPlaying ? 1.0 : 0.78),
                      child: Transform(
                        alignment: focusObjectLayer.alignment,
                        transform: Matrix4.identity()
                          ..setEntry(3, 2, 0.0016)
                          ..rotateX(objectRotX)
                          ..rotateY(objectRotY)
                          ..rotateZ(objectRotZ),
                        child: Transform.translate(
                          offset: Offset(objectDriftX, objectDriftY),
                          child: Transform.scale(
                            alignment: focusObjectLayer.alignment,
                            scale: objectDepthScale,
                            child: Image.memory(
                              focusObjectLayer.bytes,
                              fit: BoxFit.contain,
                              filterQuality: FilterQuality.low,
                              gaplessPlayback: true,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  String _displayArtworkSourceUrl() {
    return widget.url?.trim() ?? '';
  }

  void _maybeResolveAiAnimatedCover() {
    // Flujo liviano: desactivamos permanentemente portada IA/video y limpiamos
    // una sola vez para no gastar trabajo en cada build.
    if (_didCleanupAiPipeline) return;
    _didCleanupAiPipeline = true;
    if (_aiAnimatedCoverUrl != null || _lastAiCoverSource != null) {
      _aiAnimatedCoverUrl = null;
      _lastAiCoverSource = null;
    }
    if (_aiActiveVideoController != null ||
        _aiStandbyVideoController != null ||
        _aiVideoControllerA != null ||
        _aiVideoControllerB != null ||
        _aiVideoReady ||
        _aiVideoSource != null) {
      _aiLoopToken++;
      _aiVideoReady = false;
      _aiVideoSource = null;
      unawaited(_disposeAiVideoControllers());
    }
  }

  bool _looksLikeVideoSource(String source) {
    final value = source.trim().toLowerCase();
    if (value.isEmpty) return false;
    if (RegExp(r'\.(mp4|mov|m3u8|webm|m4v|mkv)(\?|#|$)').hasMatch(value) ||
        value.contains('/video/') ||
        value.contains('/videos/') ||
        value.contains('/gradio_api/file=') ||
        value.contains('/file=')) {
      return true;
    }
    return false;
  }

  void _syncAiVideoControllerForSource(String source) {
    final aiUrl = _aiAnimatedCoverUrl?.trim() ?? '';
    final shouldTryAsVideo =
        _looksLikeVideoSource(source) ||
        (aiUrl.isNotEmpty &&
            source == aiUrl &&
            (source.startsWith('http://') || source.startsWith('https://')));
    if (!shouldTryAsVideo) {
      if (_aiActiveVideoController != null ||
          _aiVideoReady ||
          _aiVideoSource != null) {
        _aiLoopToken++;
        _aiVideoReady = false;
        _aiVideoSource = null;
        unawaited(_disposeAiVideoControllers());
      }
      return;
    }
    if (source == _aiVideoSource && _aiVideoReady) return;
    _aiVideoSource = source;
    _aiVideoReady = false;
    _aiLoopToken++;
    unawaited(_prepareAiVideoController(source));
  }

  Future<void> _prepareAiVideoController(String source) async {
    final token = _aiLoopToken;
    await _disposeAiVideoControllers();
    _ensureAiLoopBlendController();
    _aiLoopBlendController?.value = 0;
    final controllerA = VideoPlayerController.networkUrl(Uri.parse(source));
    final controllerB = VideoPlayerController.networkUrl(Uri.parse(source));
    _aiVideoControllerA = controllerA;
    _aiVideoControllerB = controllerB;
    try {
      await controllerA.initialize();
      await controllerB.initialize();
      await controllerA.setLooping(false);
      await controllerB.setLooping(false);
      await controllerA.setVolume(0);
      await controllerB.setVolume(0);
      await controllerB.seekTo(Duration.zero);
      await controllerB.pause();
      await controllerA.play();

      if (!mounted || _aiVideoSource != source || token != _aiLoopToken) {
        await _disposeVideoControllerSafe(controllerA);
        await _disposeVideoControllerSafe(controllerB);
        return;
      }

      _aiActiveVideoController = controllerA;
      _aiStandbyVideoController = controllerB;
      setState(() {
        _aiVideoReady = true;
      });
      _scheduleAiLoopSwap(source: source, token: token);
    } catch (_) {
      await _disposeVideoControllerSafe(controllerA);
      await _disposeVideoControllerSafe(controllerB);
      if (!mounted || _aiVideoSource != source || token != _aiLoopToken) return;
      await _prepareSingleAiVideoController(source, token: token);
    }
  }

  Future<void> _prepareSingleAiVideoController(
    String source, {
    required int token,
  }) async {
    final controller = VideoPlayerController.networkUrl(Uri.parse(source));
    _aiVideoControllerA = controller;
    try {
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
      if (!mounted || _aiVideoSource != source || token != _aiLoopToken) {
        await _disposeVideoControllerSafe(controller);
        return;
      }
      _aiActiveVideoController = controller;
      _aiStandbyVideoController = null;
      setState(() {
        _aiVideoReady = true;
      });
    } catch (_) {
      await _disposeVideoControllerSafe(controller);
      if (!mounted || _aiVideoSource != source || token != _aiLoopToken) return;
      setState(() {
        _aiVideoReady = false;
      });
    }
  }

  void _ensureAiLoopBlendController() {
    if (_aiLoopBlendController != null) return;
    _aiLoopBlendController =
        AnimationController(
          vsync: this,
          duration: _aiLoopCrossfadeDuration,
          value: 0,
        )..addListener(() {
          if (!mounted) return;
          setState(() {});
        });
  }

  void _scheduleAiLoopSwap({required String source, required int token}) {
    _aiLoopSwapTimer?.cancel();
    final active = _aiActiveVideoController;
    if (active == null || !active.value.isInitialized) return;
    final duration = active.value.duration;
    if (duration <= Duration.zero) return;
    var delay = duration - _aiLoopSwapLeadTime;
    if (delay < const Duration(milliseconds: 180)) {
      delay = Duration(
        milliseconds: math.max(120, duration.inMilliseconds ~/ 2),
      );
    }
    _aiLoopSwapTimer = Timer(
      delay,
      () => unawaited(_performAiLoopSwap(source: source, token: token)),
    );
  }

  Future<void> _performAiLoopSwap({
    required String source,
    required int token,
  }) async {
    if (!mounted || token != _aiLoopToken || _aiVideoSource != source) return;
    final active = _aiActiveVideoController;
    final standby = _aiStandbyVideoController;
    final blend = _aiLoopBlendController;
    if (active == null || standby == null || blend == null) return;

    try {
      await standby.seekTo(Duration.zero);
      await standby.setVolume(0);
      await standby.play();
      if (!mounted || token != _aiLoopToken || _aiVideoSource != source) return;

      blend
        ..stop()
        ..value = 0;
      await blend.forward();
      if (!mounted || token != _aiLoopToken || _aiVideoSource != source) return;

      await active.pause();
      await active.seekTo(Duration.zero);
      _aiActiveVideoController = standby;
      _aiStandbyVideoController = active;
      blend.value = 0;
      _scheduleAiLoopSwap(source: source, token: token);
    } catch (_) {
      // Si falla el crossfade, mantenemos loop normal del activo.
      try {
        await active.setLooping(true);
      } catch (_) {}
    }
  }

  Future<void> _disposeAiVideoControllers() async {
    _aiLoopSwapTimer?.cancel();
    _aiLoopSwapTimer = null;
    _aiLoopBlendController?.stop();
    _aiLoopBlendController?.value = 0;

    final controllers = <VideoPlayerController>{
      if (_aiVideoControllerA != null) _aiVideoControllerA!,
      if (_aiVideoControllerB != null) _aiVideoControllerB!,
      if (_aiActiveVideoController != null) _aiActiveVideoController!,
      if (_aiStandbyVideoController != null) _aiStandbyVideoController!,
    };
    _aiVideoControllerA = null;
    _aiVideoControllerB = null;
    _aiActiveVideoController = null;
    _aiStandbyVideoController = null;

    for (final controller in controllers) {
      await _disposeVideoControllerSafe(controller);
    }
  }

  Future<void> _disposeVideoControllerSafe(
    VideoPlayerController controller,
  ) async {
    try {
      await controller.pause();
    } catch (_) {}
    try {
      await controller.dispose();
    } catch (_) {}
  }

  Widget _buildAnimatedVideoCover() {
    final active = _aiActiveVideoController;
    if (active == null || !active.value.isInitialized) {
      return const SizedBox.expand();
    }
    final standby = _aiStandbyVideoController;
    final blend = (_aiLoopBlendController?.value ?? 0.0).clamp(0.0, 1.0);
    final showStandby =
        standby != null && standby.value.isInitialized && blend > 0.001;
    return Stack(
      fit: StackFit.expand,
      children: [
        _buildVideoCoverLayer(
          active,
          opacity: showStandby ? (1.0 - blend) : 1.0,
        ),
        if (showStandby) _buildVideoCoverLayer(standby, opacity: blend),
      ],
    );
  }

  Widget _buildVideoCoverLayer(
    VideoPlayerController controller, {
    required double opacity,
  }) {
    final value = controller.value;
    if (!value.isInitialized) return const SizedBox.expand();
    final videoAspect = value.aspectRatio > 0 ? value.aspectRatio : 1.0;
    return Opacity(
      opacity: opacity.clamp(0.0, 1.0),
      child: SizedBox.expand(
        child: FittedBox(
          fit: BoxFit.cover,
          clipBehavior: Clip.hardEdge,
          child: SizedBox(
            width: widget.size * videoAspect,
            height: widget.size,
            child: VideoPlayer(controller),
          ),
        ),
      ),
    );
  }

  Future<void> _resolveSubjectCutout() async {
    if (!widget.animated) return;
    final settings = context.read<AppSettingsService?>();
    if (settings != null && !settings.animatedCutoutCovers) {
      if (mounted && _subjectCutoutBytes != null) {
        setState(() {
          _subjectCutoutBytes = null;
          _lastSubjectUrl = null;
          _subjectMotionProfile = null;
          _lastSubjectProfileUrl = null;
          _focusObjectLayer = null;
          _lastFocusObjectUrl = null;
        });
      } else {
        _lastSubjectUrl = null;
        _subjectMotionProfile = null;
        _lastSubjectProfileUrl = null;
        _focusObjectLayer = null;
        _lastFocusObjectUrl = null;
      }
      return;
    }
    final resolved = _processingArtworkSourceUrl();
    if (kDebugMode) {
      debugPrint('[cutout] resolve start url=$resolved');
    }
    if (resolved == null || resolved.isEmpty) {
      if (mounted && _subjectCutoutBytes != null) {
        setState(() {
          _subjectCutoutBytes = null;
          _lastSubjectUrl = null;
          _subjectMotionProfile = null;
          _lastSubjectProfileUrl = null;
          _focusObjectLayer = null;
          _lastFocusObjectUrl = null;
        });
      }
      if (kDebugMode) {
        debugPrint('[cutout] resolve abort empty url');
      }
      return;
    }
    if (resolved == _lastSubjectUrl) return;
    _lastSubjectUrl = resolved;
    final dataSaverMode = settings?.dataSaverMode ?? false;

    if (_subjectCutoutCache.containsKey(resolved)) {
      final cached = _subjectCutoutCache[resolved];
      if (!mounted || _lastSubjectUrl != resolved) return;
      setState(() {
        _subjectCutoutBytes = cached;
      });
      unawaited(_resolveSubjectMotionProfile(resolved, cached));
      unawaited(_resolveFocusObjectLayer(resolved, cached));
      return;
    }

    Future<Uint8List?> request =
        _subjectCutoutRequests[resolved] ??
        () async {
          try {
            final bytes = await _loadImageBytes(resolved);
            if (kDebugMode) {
              debugPrint(
                '[cutout] source bytes loaded url=$resolved bytes=${bytes?.length ?? 0}',
              );
            }
            if (bytes == null || bytes.isEmpty) return null;
            final preparedBytes = await compute<Uint8List, Uint8List?>(
              _prepareArtworkForCutoutWorker,
              bytes,
            );
            if (preparedBytes == null || preparedBytes.isEmpty) return null;
            final cutout = await ArtworkSubjectCutoutService.buildCutout(
              cacheKey: 'v14:$resolved:player-cropped',
              sourceBytes: preparedBytes,
              viewportZoom: 1.0,
              usePersistentCache: true,
              persistResult: !dataSaverMode,
            );
            _rememberSubjectCutout(resolved, cutout);
            return cutout;
          } catch (_) {
            _rememberSubjectCutout(resolved, null);
            return null;
          }
        }();
    _subjectCutoutRequests[resolved] = request;

    try {
      final cutout = await request;
      if (!mounted || _lastSubjectUrl != resolved) return;
      setState(() {
        _subjectCutoutBytes = cutout;
      });
      unawaited(_resolveSubjectMotionProfile(resolved, cutout));
      unawaited(_resolveFocusObjectLayer(resolved, cutout));
      if (kDebugMode) {
        debugPrint(
          '[cutout] resolve done url=$resolved outBytes=${cutout?.length ?? 0}',
        );
      }
    } catch (_) {
      if (!mounted || _lastSubjectUrl != resolved) return;
      setState(() {
        _subjectCutoutBytes = null;
        _subjectMotionProfile = null;
        _lastSubjectProfileUrl = null;
        _focusObjectLayer = null;
        _lastFocusObjectUrl = null;
      });
      if (kDebugMode) {
        debugPrint('[cutout] resolve failed url=$resolved');
      }
    } finally {
      if (identical(_subjectCutoutRequests[resolved], request)) {
        _subjectCutoutRequests.remove(resolved);
      }
    }
  }

  Future<void> _resolveSubjectMotionProfile(
    String sourceKey,
    Uint8List? cutoutBytes,
  ) async {
    if (cutoutBytes == null || cutoutBytes.isEmpty) {
      if (!mounted) return;
      setState(() {
        _subjectMotionProfile = null;
        _lastSubjectProfileUrl = sourceKey;
      });
      return;
    }
    _lastSubjectProfileUrl = sourceKey;
    final cached = _subjectProfileCache[sourceKey];
    if (cached != null || _subjectProfileCache.containsKey(sourceKey)) {
      if (!mounted || _lastSubjectProfileUrl != sourceKey) return;
      setState(() {
        _subjectMotionProfile = cached;
      });
      return;
    }

    final request =
        _subjectProfileRequests[sourceKey] ??
        compute<Uint8List, Map<String, num>?>(
          _buildSubjectMotionProfileWorker,
          cutoutBytes,
        ).then((raw) {
          if (raw == null) return null;
          return _SubjectMotionProfile(
            alignment: Alignment(
              ((raw['alignmentX']?.toDouble() ?? 0.0).clamp(-0.55, 0.55)),
              ((raw['alignmentY']?.toDouble() ?? 0.0).clamp(-0.55, 0.55)),
            ),
            moveScale: (raw['moveScale']?.toDouble() ?? 1.0).clamp(0.85, 1.42),
            tiltScale: (raw['tiltScale']?.toDouble() ?? 1.0).clamp(0.82, 1.30),
            zoomBoost: (raw['zoomBoost']?.toDouble() ?? 0.0).clamp(0.0, 0.26),
            styleVariant: ((raw['style']?.toInt() ?? 0) % 5).clamp(0, 4),
          );
        });

    _subjectProfileRequests[sourceKey] = request;
    try {
      final profile = await request;
      _subjectProfileCache[sourceKey] = profile;
      if (!mounted || _lastSubjectProfileUrl != sourceKey) return;
      setState(() {
        _subjectMotionProfile = profile;
      });
    } catch (_) {
      _subjectProfileCache[sourceKey] = null;
      if (!mounted || _lastSubjectProfileUrl != sourceKey) return;
      setState(() {
        _subjectMotionProfile = null;
      });
    } finally {
      if (identical(_subjectProfileRequests[sourceKey], request)) {
        _subjectProfileRequests.remove(sourceKey);
      }
    }
  }

  Future<void> _resolveFocusObjectLayer(
    String sourceKey,
    Uint8List? cutoutBytes,
  ) async {
    if (cutoutBytes == null || cutoutBytes.isEmpty) {
      if (!mounted) return;
      setState(() {
        _focusObjectLayer = null;
        _lastFocusObjectUrl = sourceKey;
      });
      return;
    }
    _lastFocusObjectUrl = sourceKey;
    final cached = _focusObjectCache[sourceKey];
    if (cached != null || _focusObjectCache.containsKey(sourceKey)) {
      if (!mounted || _lastFocusObjectUrl != sourceKey) return;
      setState(() {
        _focusObjectLayer = cached;
      });
      return;
    }

    final request =
        _focusObjectRequests[sourceKey] ??
        compute<Uint8List, Map<String, Object?>?>(
          _buildFocusObjectLayerWorker,
          cutoutBytes,
        ).then((raw) {
          if (raw == null) return null;
          final bytes = raw['bytes'];
          if (bytes is! Uint8List || bytes.isEmpty) return null;
          final alignmentX = ((raw['alignmentX'] as num?)?.toDouble() ?? 0.0)
              .clamp(-0.95, 0.95);
          final alignmentY = ((raw['alignmentY'] as num?)?.toDouble() ?? 0.0)
              .clamp(-0.95, 0.95);
          final areaRatio = ((raw['areaRatio'] as num?)?.toDouble() ?? 0.0)
              .clamp(0.0, 1.0);
          return _FocusObjectLayer(
            bytes: bytes,
            alignment: Alignment(alignmentX, alignmentY),
            areaRatio: areaRatio,
          );
        });
    _focusObjectRequests[sourceKey] = request;

    try {
      final layer = await request;
      _rememberFocusObjectLayer(sourceKey, layer);
      if (!mounted || _lastFocusObjectUrl != sourceKey) return;
      setState(() {
        _focusObjectLayer = layer;
      });
    } catch (_) {
      _rememberFocusObjectLayer(sourceKey, null);
      if (!mounted || _lastFocusObjectUrl != sourceKey) return;
      setState(() {
        _focusObjectLayer = null;
      });
    } finally {
      if (identical(_focusObjectRequests[sourceKey], request)) {
        _focusObjectRequests.remove(sourceKey);
      }
    }
  }

  Future<Uint8List?> _loadImageBytes(String raw) async {
    if (_imageBytesCache.containsKey(raw)) {
      return _imageBytesCache[raw];
    }
    final inFlight = _imageBytesRequests[raw];
    if (inFlight != null) {
      return inFlight;
    }
    final request = _readImageBytes(raw);
    _imageBytesRequests[raw] = request;
    try {
      final bytes = await request;
      _rememberImageBytes(raw, bytes);
      return bytes;
    } finally {
      if (identical(_imageBytesRequests[raw], request)) {
        _imageBytesRequests.remove(raw);
      }
    }
  }

  Future<Uint8List?> _readImageBytes(String raw) async {
    if (raw.startsWith('/')) {
      final file = File(raw);
      if (!await file.exists()) {
        if (kDebugMode) {
          debugPrint('[cutout] local file not found path=$raw');
        }
        return null;
      }
      return file.readAsBytes();
    }
    final client = HttpClient();
    try {
      final uri = Uri.parse(raw);
      final req = await client.getUrl(uri);
      req.headers.set(HttpHeaders.userAgentHeader, 'VMMusic/1.0 (Flutter)');
      final res = await req.close();
      if (res.statusCode < 200 || res.statusCode >= 300) {
        if (kDebugMode) {
          debugPrint('[cutout] http image status=${res.statusCode} url=$raw');
        }
        return null;
      }
      final chunks = <int>[];
      await for (final c in res) {
        chunks.addAll(c);
      }
      return Uint8List.fromList(chunks);
    } catch (_) {
      if (kDebugMode) {
        debugPrint('[cutout] http image load exception url=$raw');
      }
      return null;
    } finally {
      client.close(force: true);
    }
  }

  Widget _buildStaticArtworkFrame(
    BuildContext context, {
    required String imageSource,
    required bool hasImage,
    required bool preferLowResolution,
  }) {
    return SizedBox.square(
      dimension: widget.size,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(widget.borderRadius),
        child: ColoredBox(
          color: Theme.of(context).colorScheme.surfaceContainerHighest,
          child: hasImage
              ? _buildArtworkImage(
                  context,
                  imageSource: imageSource,
                  preferLowResolution: preferLowResolution,
                )
              : Icon(
                  Icons.music_note_rounded,
                  size: widget.size * 0.4,
                  color: Theme.of(context).colorScheme.primary,
                ),
        ),
      ),
    );
  }

  void _syncAnimationControllers({bool initial = false}) {
    if (!widget.animated) {
      _motionController?.stop();
      _pulseController?.stop();
      return;
    }

    _motionController ??= AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 11500),
    );

    _pulseController ??= AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    );

    final motion = _motionController!;
    if (widget.isPlaying) {
      if (!motion.isAnimating) {
        motion.repeat(reverse: true);
      }
    } else {
      motion.stop(canceled: false);
      motion.value = 0.5;
    }

    final pulse = _pulseController!;
    if (widget.isPlaying) {
      if (!pulse.isAnimating) {
        pulse.repeat(reverse: true);
      }
      return;
    }

    pulse.stop();
    if (initial) {
      pulse.value = 0.35;
      return;
    }
    pulse.animateTo(
      0.35,
      duration: const Duration(milliseconds: 280),
      curve: Curves.easeOutCubic,
    );
  }

  void _syncHeavyArtworkEffectsBudget({required bool enabled}) {
    if (enabled) {
      if (!_heavyArtworkEffectsSuspended) return;
      _heavyArtworkEffectsSuspended = false;
      _syncAnimationControllers();
      return;
    }

    if (_heavyArtworkEffectsSuspended) return;
    _heavyArtworkEffectsSuspended = true;
    _motionController?.stop(canceled: false);
    _pulseController?.stop(canceled: false);
    _aiLoopToken++;
    _aiLoopSwapTimer?.cancel();
    _aiLoopSwapTimer = null;
    _aiLoopBlendController
      ?..stop(canceled: false)
      ..value = 0;
    _aiVideoReady = false;
    _aiVideoSource = null;
    unawaited(_disposeAiVideoControllers());
  }

  void _rememberSubjectCutout(String key, Uint8List? value) {
    _subjectCutoutCache[key] = value;
    while (_subjectCutoutCache.length > _maxArtworkCacheEntries) {
      _subjectCutoutCache.remove(_subjectCutoutCache.keys.first);
    }
  }

  void _rememberImageBytes(String key, Uint8List? value) {
    _imageBytesCache[key] = value;
    while (_imageBytesCache.length > _maxArtworkCacheEntries) {
      _imageBytesCache.remove(_imageBytesCache.keys.first);
    }
  }

  void _rememberFocusObjectLayer(String key, _FocusObjectLayer? value) {
    _focusObjectCache[key] = value;
    while (_focusObjectCache.length > _maxArtworkCacheEntries) {
      _focusObjectCache.remove(_focusObjectCache.keys.first);
    }
  }

  int _subjectMotionStyleForUrl(String? raw) {
    final s = raw?.trim();
    if (s == null || s.isEmpty) return 0;
    var hash = 0;
    for (var i = 0; i < s.length; i++) {
      hash = ((hash * 31) + s.codeUnitAt(i)) & 0x7fffffff;
    }
    return hash % 5;
  }

  double _stableNoiseFromString(String? raw, {int salt = 0}) {
    final text = raw?.trim() ?? '';
    if (text.isEmpty) return 0.0;
    var hash = 17 + (salt * 131);
    for (var i = 0; i < text.length; i++) {
      hash = (hash * 37 + text.codeUnitAt(i)) & 0x7fffffff;
    }
    return (hash % 10000) / 10000.0;
  }

  String? _preferredArtworkSourceUrl({required bool preferLowResolution}) {
    final raw = widget.url?.trim();
    if (raw == null || raw.isEmpty || raw.startsWith('/')) {
      return raw;
    }
    final candidates = buildThumbnailCandidates(
      thumbnailUrl: raw,
      preferLowResolution: preferLowResolution,
    );
    if (candidates.isNotEmpty) return candidates.first;
    return optimizeYoutubeThumbnailUrl(
      raw,
      preferLowResolution: preferLowResolution,
    );
  }

  String? _processingArtworkSourceUrl() {
    // Usamos una fuente consistente y de buena definición para que el recorte
    // no cambie de tamaño/calidad entre canciones o cachés previos.
    return _preferredArtworkSourceUrl(preferLowResolution: false);
  }

  Widget _buildArtworkImage(
    BuildContext context, {
    required String imageSource,
    required bool preferLowResolution,
  }) {
    final trimmed = imageSource.trim();
    final isYoutubeThumb =
        trimmed.contains('ytimg.com') || trimmed.contains('youtube.com');
    final raw = isYoutubeThumb
        ? optimizeYoutubeThumbnailUrl(
            trimmed,
            preferLowResolution: preferLowResolution,
          )
        : trimmed;
    final looksLikeLocalPath = raw.startsWith('/');
    final fallback = Icon(
      Icons.music_note_rounded,
      size: widget.size * 0.4,
      color: Theme.of(context).colorScheme.primary,
    );
    if (looksLikeLocalPath) {
      return Transform.scale(
        scale: 1.0,
        child: SquareThumbnail.file(
          filePath: raw,
          size: widget.size,
          borderRadius: 0,
          zoom: 1.0,
          fallback: fallback,
        ),
      );
    }
    return Transform.scale(
      scale: 1.0,
      child: SquareThumbnail.network(
        imageUrl: raw,
        size: widget.size,
        borderRadius: 0,
        zoom: 1.0,
        fallback: fallback,
      ),
    );
  }
}

Map<String, num>? _buildSubjectMotionProfileWorker(Uint8List cutoutBytes) {
  final image = img.decodeImage(cutoutBytes);
  if (image == null) return null;
  final w = image.width;
  final h = image.height;
  if (w <= 8 || h <= 8) return null;
  final total = w * h;

  var count = 0;
  var weightedX = 0.0;
  var weightedY = 0.0;
  var minX = w;
  var minY = h;
  var maxX = -1;
  var maxY = -1;

  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final alpha = image.getPixel(x, y).a;
      if (alpha <= 22) continue;
      count++;
      final weight = alpha / 255.0;
      weightedX += x * weight;
      weightedY += y * weight;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
    }
  }

  if (count < total * 0.008 || maxX < minX || maxY < minY) {
    return null;
  }

  final coverage = count / total;
  final denom = count.toDouble();
  final centerX = weightedX / denom;
  final centerY = weightedY / denom;
  final alignX = ((centerX / (w - 1)) * 2.0 - 1.0).clamp(-1.0, 1.0);
  final alignY = ((centerY / (h - 1)) * 2.0 - 1.0).clamp(-1.0, 1.0);
  final bboxW = ((maxX - minX + 1) / w).clamp(0.01, 1.0);
  final bboxH = ((maxY - minY + 1) / h).clamp(0.01, 1.0);

  final compactness = (coverage / (bboxW * bboxH)).clamp(0.05, 1.0);
  final moveScale =
      (1.10 + (1.0 - coverage) * 0.38 + (1.0 - compactness) * 0.14).clamp(
        0.86,
        1.42,
      );
  final tiltScale = (0.90 + (bboxW * 0.32) + ((1.0 - bboxH) * 0.24)).clamp(
    0.82,
    1.30,
  );
  final zoomBoost = (0.06 + (1.0 - coverage) * 0.26).clamp(0.0, 0.26);

  var seed = 97;
  seed += (alignX * 1000).round();
  seed += (alignY * 1400).round();
  seed += (coverage * 10000).round();
  seed += ((bboxW + bboxH) * 1300).round();
  final style = seed.abs() % 5;

  return <String, num>{
    'alignmentX': alignX,
    'alignmentY': alignY,
    'moveScale': moveScale,
    'tiltScale': tiltScale,
    'zoomBoost': zoomBoost,
    'style': style,
  };
}

Uint8List? _prepareArtworkForCutoutWorker(Uint8List sourceBytes) {
  final decoded = img.decodeImage(sourceBytes);
  if (decoded == null) return null;

  final side = math.min(decoded.width, decoded.height);
  if (side <= 0) return null;
  final cropX = ((decoded.width - side) / 2).round();
  final cropY = ((decoded.height - side) / 2).round();
  final square = img.copyCrop(
    decoded,
    x: cropX,
    y: cropY,
    width: side,
    height: side,
  );

  // Alineamos resolución para mantener consistencia entre fuentes de portada.
  const targetSide = 1024;
  final prepared = side > targetSide
      ? img.copyResize(
          square,
          width: targetSide,
          height: targetSide,
          interpolation: img.Interpolation.cubic,
        )
      : square;

  return Uint8List.fromList(img.encodePng(prepared, level: 6));
}

Map<String, Object?>? _buildFocusObjectLayerWorker(Uint8List cutoutBytes) {
  final image = img.decodeImage(cutoutBytes);
  if (image == null) return null;
  final w = image.width;
  final h = image.height;
  if (w <= 16 || h <= 16) return null;
  final total = w * h;

  final alphaMask = Uint8List(total);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      final alpha = image.getPixel(x, y).a;
      if (alpha > 26) {
        alphaMask[y * w + x] = 1;
      }
    }
  }

  final visited = Uint8List(total);
  final queue = List<int>.filled(total, 0, growable: false);
  _FocusComponent? best;
  var bestScore = -1.0;

  for (var i = 0; i < total; i++) {
    if (alphaMask[i] == 0 || visited[i] == 1) continue;

    var head = 0;
    var tail = 0;
    queue[tail++] = i;
    visited[i] = 1;

    final pixels = <int>[];
    var minX = w;
    var minY = h;
    var maxX = 0;
    var maxY = 0;
    var sumX = 0.0;
    var sumY = 0.0;

    while (head < tail) {
      final idx = queue[head++];
      pixels.add(idx);
      final x = idx % w;
      final y = idx ~/ w;
      sumX += x;
      sumY += y;
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;

      void push(int nx, int ny) {
        if (nx < 0 || ny < 0 || nx >= w || ny >= h) return;
        final n = ny * w + nx;
        if (visited[n] == 1 || alphaMask[n] == 0) return;
        visited[n] = 1;
        queue[tail++] = n;
      }

      push(x - 1, y);
      push(x + 1, y);
      push(x, y - 1);
      push(x, y + 1);
    }

    final area = pixels.length;
    if (area < math.max(18, (total * 0.0018).round())) continue;
    final areaRatio = area / total;
    final bboxW = (maxX - minX + 1).toDouble();
    final bboxH = (maxY - minY + 1).toDouble();
    final bboxArea = bboxW * bboxH;
    if (bboxArea <= 0) continue;
    final compactness = (area / bboxArea).clamp(0.05, 1.0);
    final aspect = (bboxW / bboxH).clamp(0.2, 5.0);
    final circularity = (1.0 - ((aspect - 1.0).abs() / 1.2)).clamp(0.0, 1.0);

    final cx = sumX / area;
    final cy = sumY / area;
    final nx = ((cx / (w - 1)) * 2.0 - 1.0).clamp(-1.0, 1.0);
    final ny = ((cy / (h - 1)) * 2.0 - 1.0).clamp(-1.0, 1.0);
    final centerDist = math.sqrt(nx * nx + ny * ny).clamp(0.0, 1.8);
    final centerScore = (1.0 - (centerDist / 1.8)).clamp(0.0, 1.0);

    // Priorizamos objetos medianos/compactos (pelotas, elementos sueltos)
    // en vez del sujeto completo.
    final areaPref = (1.0 - ((areaRatio - 0.045).abs() / 0.060)).clamp(
      0.0,
      1.0,
    );
    final score =
        areaPref * 0.38 +
        circularity * 0.30 +
        compactness * 0.22 +
        centerScore * 0.10;

    if (score > bestScore) {
      bestScore = score;
      best = _FocusComponent(
        pixels: pixels,
        centerX: cx,
        centerY: cy,
        areaRatio: areaRatio,
      );
    }
  }

  if (best == null || bestScore < 0.24) return null;
  final out = img.Image(width: w, height: h, numChannels: 4);
  for (final idx in best.pixels) {
    final x = idx % w;
    final y = idx ~/ w;
    final p = image.getPixel(x, y);
    out.setPixelRgba(x, y, p.r, p.g, p.b, p.a);
  }
  img.gaussianBlur(out, radius: 1);
  final encoded = Uint8List.fromList(img.encodePng(out, level: 5));
  final alignmentX = ((best.centerX / (w - 1)) * 2.0 - 1.0).clamp(-1.0, 1.0);
  final alignmentY = ((best.centerY / (h - 1)) * 2.0 - 1.0).clamp(-1.0, 1.0);
  return <String, Object?>{
    'bytes': encoded,
    'alignmentX': alignmentX,
    'alignmentY': alignmentY,
    'areaRatio': best.areaRatio,
  };
}

class _FocusComponent {
  final List<int> pixels;
  final double centerX;
  final double centerY;
  final double areaRatio;

  const _FocusComponent({
    required this.pixels,
    required this.centerX,
    required this.centerY,
    required this.areaRatio,
  });
}

class _DownloadButton extends StatelessWidget {
  final String videoId;
  final String title;
  final String thumbnailUrl;
  final String channelTitle;
  final String? sourceUrl;
  final bool isVideoSource;
  final DownloadService downloadService;

  const _DownloadButton({
    required this.videoId,
    required this.title,
    required this.thumbnailUrl,
    required this.channelTitle,
    required this.sourceUrl,
    required this.isVideoSource,
    required this.downloadService,
  });

  @override
  Widget build(BuildContext context) {
    final status = downloadService.getDownloadStatus(videoId);
    final hasSource = sourceUrl != null && sourceUrl!.isNotEmpty;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 220),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      transitionBuilder: (child, animation) {
        return FadeTransition(
          opacity: animation,
          child: ScaleTransition(scale: animation, child: child),
        );
      },
      child: switch (status) {
        DownloadStatus.downloading => _buildCupertinoStatusButton(
          key: const ValueKey('download_loading'),
          context: context,
          child: const CupertinoActivityIndicator(radius: 9),
          onPressed: null,
        ),
        DownloadStatus.downloaded => _buildCupertinoStatusButton(
          key: const ValueKey('download_done'),
          context: context,
          child: Icon(
            CupertinoIcons.check_mark_circled_solid,
            color: CupertinoColors.systemGreen.resolveFrom(context),
            size: 20,
          ),
          onPressed: null,
        ),
        DownloadStatus.error => _buildCupertinoStatusButton(
          key: const ValueKey('download_error'),
          context: context,
          child: Icon(
            CupertinoIcons.exclamationmark_circle_fill,
            color: CupertinoColors.systemRed.resolveFrom(context),
            size: 20,
          ),
          onPressed: () => _showDownloadErrorDialog(context),
        ),
        DownloadStatus.notDownloaded => _buildCupertinoStatusButton(
          key: const ValueKey('download_idle'),
          context: context,
          child: Icon(
            CupertinoIcons.arrow_down_circle,
            color: hasSource
                ? CupertinoColors.white
                : CupertinoColors.white.withValues(alpha: 0.42),
            size: 20,
          ),
          onPressed: hasSource ? _triggerDownload : null,
        ),
      },
    );
  }

  void _triggerDownload() {
    final url = sourceUrl;
    if (url == null || url.isEmpty) return;
    downloadService.downloadFromPlaybackSource(
      videoId: videoId,
      title: title,
      thumbnailUrl: thumbnailUrl,
      channelTitle: channelTitle,
      sourceUrl: url,
      isVideoSource: isVideoSource,
    );
  }

  Widget _buildCupertinoStatusButton({
    required Key key,
    required BuildContext context,
    required Widget child,
    required VoidCallback? onPressed,
  }) {
    return CupertinoButton(
      key: key,
      padding: EdgeInsets.zero,
      minimumSize: const Size(34, 34),
      onPressed: onPressed,
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: Colors.transparent,
          shape: BoxShape.circle,
          border: Border.all(
            color: CupertinoColors.white.withValues(alpha: 0.2),
            width: 0.5,
          ),
        ),
        alignment: Alignment.center,
        child: child,
      ),
    );
  }

  void _showDownloadErrorDialog(BuildContext context) {
    final detail =
        downloadService.getDownloadError(videoId) ??
        'No se registró detalle del error.';
    showCupertinoDialog<void>(
      context: context,
      builder: (dialogContext) {
        return CupertinoAlertDialog(
          title: const Text('Error de descarga'),
          content: Text(detail),
          actions: [
            CupertinoDialogAction(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Cerrar'),
            ),
            CupertinoDialogAction(
              isDefaultAction: true,
              onPressed: () {
                Navigator.of(dialogContext).pop();
                _triggerDownload();
              },
              child: const Text('Reintentar'),
            ),
          ],
        );
      },
    );
  }
}
